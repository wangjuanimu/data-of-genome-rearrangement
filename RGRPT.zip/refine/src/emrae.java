//package emrae;

import java.io.*;
import java.lang.*;

public class emrae {
    public final static int BIG = 1000000;
    public static void main(String[] args) throws Exception {

        try {
        	Input data = new Input();
            /*read permuations of the genomes*/
        	String fileName ="E:/Java/MyEclipse/refine/test/toy_perm.txt";
            data.generateGenomeList(fileName);
            
        	String pathName="E:/Java/MyEclipse/refine/test/r.txt";
            File result = new File(pathName);
            FileWriter fw = new FileWriter(result);
            PrintWriter pw = new PrintWriter(fw);

            /*generate the  list of the leave edges*/
            data.generateLeafList();

            // get all the valid pairs(adjacencies) of all the chroms
            data.getAllValidPairs();
        	
            //index[i][j] = k means that the ajacency j in genome Gi is on its k-th chrom.
            int[][] index = new int[data.genomeList.size()][data.Pairs.size()];
            //this array indicates the pairs each adj has.
            int[][] a = data.generateMatrix(data.genomeList, data.Pairs, index);
            String tree_file="E:/Java/MyEclipse/refine/test/toy_tree.txt";
            data.processRealTrees(tree_file, a, index, pw);
            pw.close();
            fw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(0);
        }
    }


}
