//package emrae;

import java.io.*;
import java.util.*;
import java.lang.*;

public class Edge {
    //The two nodes of one edge
    /*Note: For a edge e = (nodeOne,nodeTwo), if e is a leaf edge,
      then ALWAYS keep nodeOne denoting the leaf.*/

    Vector leftSub1;
    Vector rightSub1;
    Vector leftSub2;
    Vector rightSub2;
    //the transpositions mgr predicted.
    Vector mgrTran;


    Vector rAdjOne;
    Vector rAdjTwo;

    Node nodeOne;
    Node nodeTwo;
    int from;
    int to; // from and to remember the orientation that reversals happens.

    //each edge cut the node set of the tree into setOne and setTwo
    Vector setOne;
    Vector setTwo;

    //Each edge corrsponds to two ajacencies cutting the node set
    Vector adjOne;
    Vector adjTwo;
    Vector commonNodes;

    //to contain relaxed version adjs
    Vector relaxAdjOne;
    Vector relaxAdjTwo;
    Vector finalAdjOne;
    Vector finalAdjTwo;
    Vector finalOverlap;
    //label all mgr true inversions as used.then infer transpositions.
    boolean mgrInvUsed[];
    Vector mgrInvs;

    boolean mgrTlcUsed[];
    Vector mgrTlcs;
    Vector mgrFis;
    Vector mgrFus;

    Vector tlcs;
    Vector invs;
    Vector trans;
    Vector fus;
    Vector fis;

    Vector cInvs;
    Vector cTlcs;
    Vector cFis;
    Vector cFus;

//    Edge(int a, int b, Vector nodeList) {
//        this.nodeOne = (Node) (nodeList.elementAt(a));
//        this.nodeTwo = (Node) (nodeList.elementAt(b));
//        if (nodeOne.nodeID < emrae.genomeNUM || nodeTwo.nodeID < emrae.genomeNUM) {
//            this.isInternalEdge = false;
//        } else {
//            this.isInternalEdge = true;
//        }
//    }

    //indicate if the edge is internal
    boolean isInternalEdge;
    //to indicate if the adjs are moved already.
    boolean done;

    Edge() {
        //mgrInvUsed = new boolean[mgrInvs.size()];
        //mgrTlcUsed = new boolean[mgrTlcs.size()];
        leftSub1 = new Vector();
        rightSub1 = new Vector();
        leftSub2 = new Vector();
        rightSub2 = new Vector();

        tlcs = new Vector();
        invs = new Vector();
        trans = new Vector();
        fus = new Vector();
        fis = new Vector();

        mgrTran = new Vector();

        nodeOne = new Node();
        nodeTwo = new Node();

        setOne = new Vector();
        setTwo = new Vector();

        adjOne = new Vector();
        adjTwo = new Vector();

        commonNodes = new Vector();
        relaxAdjOne = new Vector();
        relaxAdjTwo = new Vector();

        finalAdjOne = new Vector();
        finalAdjTwo = new Vector();
        finalOverlap = new Vector();

        mgrInvs = new Vector();
        mgrTlcs = new Vector();
        mgrFis = new Vector();
        mgrFus = new Vector();

        cInvs = new Vector();
        cTlcs = new Vector();
        cFis = new Vector();
        cFus = new Vector();
        isInternalEdge = false;
        done = false;

        rAdjOne = new Vector();
        rAdjTwo = new Vector();

        from = -1;
        to = -1;
    }

//*************
     void getSetOne(int[] a) {
         for (int i = 0; i < a.length; i++) {
             this.setOne.addElement(new Integer(a[i]));
         }
     }

    void getSetTwo(int[] a) {
        for (int i = 0; i < a.length; i++) {
            this.setTwo.addElement(new Integer(a[i]));
        }
    }


    /***********************************************************/
    void setNodeOne(Node A) {
        nodeOne = A;
    }

    /***********************************************************/
    void setNodeTwo(Node A) {
        nodeTwo = A;
    }

    //**************************************
     void setEdgeInternalOrNot() {
         if ((nodeOne.isLeaf == false) && (nodeTwo.isLeaf == false)) {
             isInternalEdge = true;
         } else {
             isInternalEdge = false;
         }
     }

    //*****************************************

     void intersect() {
         int s1 = this.adjOne.size();
         int s2 = this.adjTwo.size();
         for (int i = 0; i < s1; i++) {
             int p1 = ((pair) (this.adjOne.elementAt(i))).geneOne;
             int p2 = ((pair) (this.adjOne.elementAt(i))).geneTwo;
             for (int j = 0; j < s2; j++) {
                 int t1 = ((pair) (this.adjTwo.elementAt(i))).geneOne;
                 int t2 = ((pair) (this.adjTwo.elementAt(i))).geneTwo;

                 if ((p1 == t1) || (p1 == t2)) {
                     this.commonNodes.addElement(new Integer(p1));
                 }
                 if ((p2 == t1) || (p2 == t2)) {
                     this.commonNodes.addElement(new Integer(p2));
                 }

             }
         }

         int s = this.commonNodes.size();
         for (int i = 0; i < s; i++) {
             int k1 = ((Integer) (commonNodes.elementAt(i))).intValue();
             for (int j = i; j < s; j++) {
                 int k2 = ((Integer) (commonNodes.elementAt(j))).intValue();
                 if ((k1 == k2)) {
                     this.commonNodes.setElementAt(new Integer( -emrae.BIG), j);
                 }
             }
         }
     }

    //**********************************
     boolean samePair(pair p1, pair p2) {
         boolean same = false;
         if ((p1.geneOne == p2.geneOne) && (p1.geneTwo == p2.geneTwo)) {
             same = true;
         } else if ((p1.geneOne == -(p2.geneTwo)) &&
                    (p1.geneTwo == -(p2.geneOne))) {
             same = true;
         }
         return same;
     }

//********************************************************
     void labelPairs(pair p1, pair p2, pair p3, pair p4) {
         p1.geneOne = emrae.BIG;
         p2.geneOne = emrae.BIG;
         p3.geneOne = emrae.BIG;
         p4.geneOne = emrae.BIG;
     }

    void labelPairs(pair p1, pair p2, pair p3, pair q1, pair q2, pair q3) {
        p1.geneOne = emrae.BIG;
        p2.geneOne = emrae.BIG;
        p3.geneOne = emrae.BIG;
        q1.geneOne = emrae.BIG;
        q2.geneOne = emrae.BIG;
        q3.geneOne = emrae.BIG;
    }

    //**************
     boolean overlap(pair p1, pair p2) {
         if (Math.abs(p1.geneOne) == Math.abs(p2.geneOne)) {
             return true;
         } else if (Math.abs(p1.geneOne) == Math.abs(p2.geneTwo)) {
             return true;
         } else if (Math.abs(p1.geneTwo) == Math.abs(p2.geneTwo)) {
             return true;
         } else if (Math.abs(p1.geneTwo) == Math.abs(p2.geneOne)) {
             return true;
         } else {
             return false;
         }
     }

//***********************************************************
     void computeFinal(PrintWriter p, int[][] index, int[][] m, Vector genomes) {
         System.out.println("computing final..");
         Vector Vfrom;
         Vector Vto;
         Vfrom = this.finalAdjOne;
         Vto = this.finalAdjTwo;

         Vector Sfrom;
         Vector Sto;

         int size1;
         int size2;

         Sfrom = this.setOne;
         Sto = this.setTwo;

         size1 = Sfrom.size();
         size2 = Sto.size();

         //part one. Recover translocations and reversals.
         for (int i1 = 0; i1 < Vfrom.size(); i1++) {
             pair m1 = (pair) (Vfrom.elementAt(i1));
             for (int i2 = i1 + 1; i2 < Vfrom.size(); i2++) {
                 if (m1.geneOne == emrae.BIG) {
                     break;
                 }
                 pair m2 = (pair) (Vfrom.elementAt(i2));
                 for (int j1 = 0; j1 < Vto.size(); j1++) {
                     if (m2.geneOne == emrae.BIG) {
                         break;
                     }
                     pair n1 = (pair) (Vto.elementAt(j1));
                     for (int j2 = j1 + 1; j2 < Vto.size(); j2++) {
                         if (n1.geneOne == emrae.BIG) {
                             break;
                         }
                         pair n2 = (pair) (Vto.elementAt(j2));
                         if (n2.geneOne != emrae.BIG) {
                             if (isInv(m1, m2, n1, n2)) {

                                 int c1 = 0;
                                 int c_1 = 0;
                                 int c2 = 0;
                                 int c_2 = 0;

                                 //count c1 for m1 and m2;
                                 for (int i = 0; i < size1; i++) {
                                     int rk = ((Integer) (Sfrom.elementAt(i))).
                                              intValue();
                                     if ((index[rk][m1.index] ==
                                          index[rk][m2.index]) &&
                                         (index[rk][m1.index] != -1)) {
                                         c1++;
                                     }
                                     if ((index[rk][m1.index] !=
                                          index[rk][m2.index]) &&
                                         (index[rk][m1.index] != -1) &&
                                         (index[rk][m2.index] != -1)) {
                                         c_1++;
                                     }
                                 }
                                 //count c2 for n1 and n2;
                                 for (int i = 0; i < size2; i++) {
                                     int rk = ((Integer) (Sto.elementAt(i))).
                                              intValue();
                                     if ((index[rk][n1.index] ==
                                          index[rk][n2.index]) &&
                                         (index[rk][n1.index] != -1)) {
                                         c2++;
                                     }
                                     if ((index[rk][n1.index] !=
                                          index[rk][n2.index]) &&
                                         (index[rk][n1.index] != -1) &&
                                         (index[rk][n2.index] != -1)) {
                                         c_2++;
                                     }
                                 }
                                 //inf indicates if m1, m2, n1, n2 recover an event.
                                 if (c1 > 0 && c2 > 0) {
                                     inversion inv = new inversion();
                                     inv.p1 = new pair(m1.geneOne, m1.geneTwo);
                                     inv.p2 = new pair(m2.geneOne, m2.geneTwo);
                                     inv.q1 = new pair(n1.geneOne, n1.geneTwo);
                                     inv.q2 = new pair(n2.geneOne, n2.geneTwo);
                                     this.invs.addElement(inv);
                                     p.println("A reversal:");
                                     printFP(p, m1, m2, n1, n2);
                                     labelPairs(m1, m2, n1, n2);
                                 } else if (c_1 > 0 && c_2 > 0 &&
                                            (c1 == 0 || c2 == 0)) {
                                     p.println("A translocation:");
                                     tlc t = new tlc(m1, m2, n1, n2);
                                     this.tlcs.addElement(t);
                                     printFP(p, m1, m2, n1, n2);
                                     labelPairs(m1, m2, n1, n2);
                                 }
                                 //ambiguous conditions
                                 else if (((c1 == 0 && c_1 > 0) &&
                                           (c2 > 0 && c_2 == 0)) ||
                                          ((c1 > 0 && c_1 == 0) &&
                                           (c2 == 0 && c_2 > 0))) {
                                     inversion inv = new inversion();
                                     inv.p1 = new pair(m1.geneOne, m1.geneTwo);
                                     inv.p2 = new pair(m2.geneOne, m2.geneTwo);
                                     inv.q1 = new pair(n1.geneOne, n1.geneTwo);
                                     inv.q2 = new pair(n2.geneOne, n2.geneTwo);
                                     this.invs.addElement(inv);
                                     p.println("A reversal:");
                                     printFP(p, m1, m2, n1, n2);
                                     labelPairs(m1, m2, n1, n2);
                                 } else if ((c1 > 0 && c2 == 0 &&
                                             c_2 == 0) ||
                                            (c1 == 0 && c_1 == 0 && c2 > 0)) {
                                     inversion inv = new inversion();
                                     inv.p1 = new pair(m1.geneOne, m1.geneTwo);
                                     inv.p2 = new pair(m2.geneOne, m2.geneTwo);
                                     inv.q1 = new pair(n1.geneOne, n1.geneTwo);
                                     inv.q2 = new pair(n2.geneOne, n2.geneTwo);
                                     this.invs.addElement(inv);
                                     p.println("A reversal:");
                                     printFP(p, m1, m2, n1, n2);
                                     labelPairs(m1, m2, n1, n2);
                                 } else if ((c1 == 0 && c_1 > 0 && c2 == 0 &&
                                             c_2 == 0) ||
                                            (c1 == 0 && c_1 == 0 && c_2 > 0 &&
                                             c2 == 0)) {
                                     tlc t = new tlc(m1, m2, n1, n2);
                                     this.tlcs.addElement(t);
                                     p.println("A tranlocation:");
                                     printFP(p, m1, m2, n1, n2);
                                     labelPairs(m1, m2, n1, n2);
                                 } else {
                                     inversion inv = new inversion();
                                     inv.p1 = new pair(m1.geneOne, m1.geneTwo);
                                     inv.p2 = new pair(m2.geneOne, m2.geneTwo);
                                     inv.q1 = new pair(n1.geneOne, n1.geneTwo);
                                     inv.q2 = new pair(n2.geneOne, n2.geneTwo);
                                     this.invs.addElement(inv);
                                     p.println("A reversal:");
                                     printFP(p, m1, m2, n1, n2);
                                     labelPairs(m1, m2, n1, n2);
                                 }

                             }
                         }
                     }
                 }
             }
         }
         //System.out.println("translocations and reversals done.");
         System.out.println("translocations = " + this.tlcs.size() +
                            ", reversals = " + this.invs.size());
     }

//********************************************************
     void computeRealFinal(PrintWriter p, int[][] matrix) {
         Vector Vfrom;
         Vector Vto;
         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.rAdjOne;
             Vto = this.rAdjTwo;
         } else {
             Vfrom = this.rAdjTwo;
             Vto = this.rAdjOne;
         }

         for (int i1 = 0; i1 < Vfrom.size(); i1++) {
             pair m1 = (pair) (Vfrom.elementAt(i1));
             for (int i2 = i1 + 1; i2 < Vfrom.size(); i2++) {
                 if (m1.geneOne == emrae.BIG) {
                     break;
                 }
                 pair m2 = (pair) (Vfrom.elementAt(i2));
                 for (int j1 = 0; j1 < Vto.size(); j1++) {
                     if (m2.geneOne == emrae.BIG) {
                         break;
                     }
                     pair n1 = (pair) (Vto.elementAt(j1));
                     for (int j2 = j1 + 1; j2 < Vto.size(); j2++) {
                         if (n1.geneOne == emrae.BIG) {
                             break;
                         }
                         pair n2 = (pair) (Vto.elementAt(j2));
                         if (n2.geneOne != emrae.BIG) {
                             if (isInv(m1, m2, n1, n2)) {
                                 labelPairs(m1, m2, n1, n2);
                                 break;
                             }
                         }
                     }
                 }
             }
         }
     }

    //**************************************
     void computeRealFinalOriginal(PrintWriter p, int[][] index) {
         Vector Vfrom;
         Vector Vto;
         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.rAdjOne;
             Vto = this.rAdjTwo;
         } else {
             Vfrom = this.rAdjTwo;
             Vto = this.rAdjOne;
         }

         Vector Sfrom;
         Vector Sto;
         int size1;
         int size2;

         if (this.from == this.nodeOne.nodeID) {
             Sfrom = this.setOne;
             Sto = this.setTwo;
         } else {
             Sfrom = this.setTwo;
             Sto = this.setOne;
         }
         size1 = Sfrom.size();
         size2 = Sto.size();

         for (int i1 = 0; i1 < Vfrom.size(); i1++) {
             pair m1 = (pair) (Vfrom.elementAt(i1));
             for (int i2 = i1 + 1; i2 < Vfrom.size(); i2++) {
                 if (m1.geneOne == emrae.BIG) {
                     break;
                 }
                 pair m2 = (pair) (Vfrom.elementAt(i2));
                 for (int j1 = 0; j1 < Vto.size(); j1++) {
                     if (m2.geneOne == emrae.BIG) {
                         break;
                     }
                     pair n1 = (pair) (Vto.elementAt(j1));
                     for (int j2 = j1 + 1; j2 < Vto.size(); j2++) {
                         if (n1.geneOne == emrae.BIG) {
                             break;
                         }
                         pair n2 = (pair) (Vto.elementAt(j2));
                         if (n2.geneOne != emrae.BIG) {
                             //test if it is a reversal that flips a single gene
                             if (isSingleRev(m1, m2, n1, n2)) {
                                 boolean B = false;
                                 for (int i = 0; i < this.invs.size(); i++) {
                                     inversion IN = (inversion) (this.invs.
                                             elementAt(i));
                                     pair p1 = IN.p1;
                                     pair p2 = IN.p2;
                                     pair q1 = IN.q1;
                                     pair q2 = IN.q2;
                                     int s1 = 0;
                                     int s2 = 0;
                                     if ((samePair(m1, p1) &&
                                          (samePair(m2, p2))) ||
                                         (samePair(m2, p1) &&
                                          (samePair(m1, p2)))) {
                                         s1++;
                                     }
                                     if ((samePair(n1, q1) &&
                                          (samePair(n2, q2))) ||
                                         (samePair(n2, q1) &&
                                          (samePair(n1, q2)))) {
                                         s2++;
                                     }
                                     if (s1 == 1 && s2 == 1) {
                                         B = true;
                                         labelPairs(m1, m2, n1, n2);
                                         break;
                                     }
                                 }
                                 if (!B) {
                                     labelPairs(m1, m2, n1, n2);
                                 }
                             } else if (!isSingleRev(m1, m2, n1, n2) &&
                                        isInv(m1, m2, n1, n2)) {
                                 int c1 = 0;
                                 int c_1 = 0;
                                 int c2 = 0;
                                 int c_2 = 0;

                                 //count c1 for m1 and m2;
                                 for (int i = 0; i < size1; i++) {
                                     int rk = ((Integer) (Sfrom.elementAt(i))).
                                              intValue();
                                     if ((index[rk][m1.index] ==
                                          index[rk][m2.index]) &&
                                         (index[rk][m1.index] != -1)) {
                                         c1++;
                                     }
                                     if ((index[rk][m1.index] !=
                                          index[rk][m2.index]) &&
                                         (index[rk][m1.index] != -1) &&
                                         (index[rk][m2.index] != -1)) {
                                         c_1++;
                                     }
                                 }
                                 //count c2 for n1 and n2;
                                 for (int i = 0; i < size2; i++) {
                                     int rk = ((Integer) (Sto.elementAt(i))).
                                              intValue();
                                     if ((index[rk][n1.index] ==
                                          index[rk][n2.index]) &&
                                         (index[rk][n1.index] != -1)) {
                                         c2++;
                                     }
                                     if ((index[rk][n1.index] !=
                                          index[rk][n2.index]) &&
                                         (index[rk][n1.index] != -1) &&
                                         (index[rk][n2.index] != -1)) {
                                         c_2++;
                                     }
                                 }
                                 //inf indicates if m1, m2, n1, n2 recover an event.
                                 if (c1 > 0 && c2 > 0) {
                                     boolean B = false;
                                     for (int i = 0; i < this.invs.size(); i++) {
                                         inversion IN = (inversion) (this.invs.
                                                 elementAt(i));
                                         pair p1 = IN.p1;
                                         pair p2 = IN.p2;
                                         pair q1 = IN.q1;
                                         pair q2 = IN.q2;
                                         int s1 = 0;
                                         int s2 = 0;
                                         if ((samePair(m1, p1) &&
                                              (samePair(m2, p2))) ||
                                             (samePair(m2, p1) &&
                                              (samePair(m1, p2)))) {
                                             s1++;
                                         }
                                         if ((samePair(n1, q1) &&
                                              (samePair(n2, q2))) ||
                                             (samePair(n2, q1) &&
                                              (samePair(n1, q2)))) {
                                             s2++;
                                         }
                                         if (s1 == 1 && s2 == 1) {
                                             B = true;
                                             //this.finalInv++;
                                             //p.println(
                                             //"An inversion is recovered:");
                                             //printFP(p, m1, m2, n1, n2);
                                             labelPairs(m1, m2, n1, n2);
                                             break;
                                         }
                                     }
                                     if (!B) {
                                         //this.finalInvFP++;
                                         //p.println("A false inversion:");
                                         //printFP(p, m1, m2, n1, n2);
                                         labelPairs(m1, m2, n1, n2);
                                     }
                                 } else if (c_1 > 0 && c_2 > 0 &&
                                            (c1 == 0 || c2 == 0)) {

                                     boolean B = false;
                                     for (int i = 0; i < this.tlcs.size(); i++) {
                                         int s1 = 0;
                                         int s2 = 0;
                                         tlc t = (tlc) (this.tlcs.elementAt(i));
                                         inversion IN = t.inv;
                                         pair p1 = IN.p1;
                                         pair p2 = IN.p2;
                                         pair q1 = IN.q1;
                                         pair q2 = IN.q2;
                                         if ((samePair(m1, p1) &&
                                              (samePair(m2, p2))) ||
                                             (samePair(m2, p1) &&
                                              (samePair(m1, p2)))) {
                                             s1++;
                                         }
                                         if ((samePair(n1, q1) &&
                                              (samePair(n2, q2))) ||
                                             (samePair(n2, q1) &&
                                              (samePair(n1, q2)))) {
                                             s2++;
                                         }
                                         if (s1 == 1 && s2 == 1) {
                                             B = true;
                                             //this.finalTlc++;
                                             //p.println("A tlc is recovered:");
                                             //printFP(p, m1, m2, n1, n2);
                                             labelPairs(m1, m2, n1, n2);
                                             break;
                                         }

                                     }
                                     if (!B) {
                                         //this.finalTlcFP++;
                                         //p.println("A false tlc:");
                                         //printFP(p, m1, m2, n1, n2);
                                         labelPairs(m1, m2, n1, n2);
                                     }
                                 }
                                 //ambiguous conditions
                                 else if (((c1 == 0 && c_1 > 0) &&
                                           (c2 > 0 && c_2 == 0)) ||
                                          ((c1 > 0 && c_1 == 0) &&
                                           (c2 == 0 && c_2 > 0))) {
                                     //case 1. possible reversals.
                                     boolean B = false;
                                     for (int i = 0; i < this.invs.size(); i++) {
                                         int s1 = 0;
                                         int s2 = 0;
                                         inversion IN = (inversion) (this.invs.
                                                 elementAt(i));
                                         pair p1 = IN.p1;
                                         pair p2 = IN.p2;
                                         pair q1 = IN.q1;
                                         pair q2 = IN.q2;
                                         if ((samePair(m1, p1) &&
                                              (samePair(m2, p2))) ||
                                             (samePair(m2, p1) &&
                                              (samePair(m1, p2)))) {
                                             s1++;
                                         }
                                         if ((samePair(n1, q1) &&
                                              (samePair(n2, q2))) ||
                                             (samePair(n2, q1) &&
                                              (samePair(n1, q2)))) {
                                             s2++;
                                         }
                                         if (s1 == 1 && s2 == 1) {
                                             B = true;
                                             //this.finalInv++;
                                             //p.println("A ambiguous inversion:");
                                             //printFP(p, m1, m2, n1, n2);
                                             labelPairs(m1, m2, n1, n2);
                                             break;
                                         }
                                     }
                                     if (!B) {
                                         //this.finalInvFP++;
                                         //p.println(
                                         //"A false ambigous inversion:");
                                         //printFP(p, m1, m2, n1, n2);
                                         labelPairs(m1, m2, n1, n2);
                                     }

                                 } else if ((c1 > 0 && c2 == 0 &&
                                             c_2 == 0) ||
                                            (c1 == 0 && c_1 == 0 && c2 > 0)) {
                                     boolean B = false;
                                     for (int i = 0; i < this.invs.size(); i++) {
                                         int s1 = 0;
                                         int s2 = 0;
                                         inversion IN = (inversion) (this.invs.
                                                 elementAt(i));
                                         pair p1 = IN.p1;
                                         pair p2 = IN.p2;
                                         pair q1 = IN.q1;
                                         pair q2 = IN.q2;
                                         if ((samePair(m1, p1) &&
                                              (samePair(m2, p2))) ||
                                             (samePair(m2, p1) &&
                                              (samePair(m1, p2)))) {
                                             s1++;
                                         }
                                         if ((samePair(n1, q1) &&
                                              (samePair(n2, q2))) ||
                                             (samePair(n2, q1) &&
                                              (samePair(n1, q2)))) {
                                             s2++;
                                         }
                                         if (s1 == 1 && s2 == 1) {
                                             B = true;
                                             //this.finalInv++;
                                             //p.println(
                                             //"A very ambiguous inversion:");
                                             //printFP(p, m1, m2, n1, n2);
                                             labelPairs(m1, m2, n1, n2);
                                             break;
                                         }

                                     }
                                     //p.println("s1=" + s1 + ",s2=" + s2);
                                     if (!B) {
                                         //this.finalInvFP++;
                                         //p.println(
                                         //"A very ambiguous false inversion:");
                                         //printFP(p, m1, m2, n1, n2);
                                         labelPairs(m1, m2, n1, n2);
                                     }
                                 } else if ((c1 == 0 && c_1 > 0 && c2 == 0 &&
                                             c_2 == 0) ||
                                            (c1 == 0 && c_1 == 0 && c_2 > 0 &&
                                             c2 == 0)) {
                                     boolean B = false;
                                     for (int i = 0; i < this.tlcs.size(); i++) {
                                         int s1 = 0;
                                         int s2 = 0;
                                         tlc t = (tlc) (this.tlcs.elementAt(i));
                                         inversion IN = t.inv;
                                         pair p1 = IN.p1;
                                         pair p2 = IN.p2;
                                         pair q1 = IN.q1;
                                         pair q2 = IN.q2;
                                         if ((samePair(m1, p1) &&
                                              (samePair(m2, p2))) ||
                                             (samePair(m2, p1) &&
                                              (samePair(m1, p2)))) {
                                             s1++;
                                         }
                                         if ((samePair(n1, q1) &&
                                              (samePair(n2, q2))) ||
                                             (samePair(n2, q1) &&
                                              (samePair(n1, q2)))) {
                                             s2++;
                                         }
                                         if (s1 == 1 && s2 == 1) {
                                             B = true;
                                             //this.finalTlc++;
                                             //p.println("A very ambiguous tlc:");
                                             //printFP(p, m1, m2, n1, n2);
                                             labelPairs(m1, m2, n1, n2);
                                             break;
                                         }

                                     }

                                     //p.println("s1=" + s1 + ",s2=" + s2);
                                     if (!B) {
                                         //this.finalTlcFP++;
                                         //p.println(
                                         // "A false tlc:");
                                         //printFP(p, m1, m2, n1, n2);
                                         labelPairs(m1, m2, n1, n2);
                                     }
                                 } else {

                                 }
                             }
                         }
                     }
                 }
             }
         }
     }

    //**********************************************************************
     void inferTranFinal(PrintWriter p, int[][] m) {
         Vector Vfrom;
         Vector Vto;
         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.finalAdjOne;
             Vto = this.finalAdjTwo;
         } else {
             Vfrom = this.finalAdjTwo;
             Vto = this.finalAdjOne;
         }

         for (int i = 0; i < Vfrom.size(); i++) {
             pair p1 = (pair) (Vfrom.elementAt(i));
             for (int j = i + 1; j < Vfrom.size(); j++) {
                 if (p1.geneOne == emrae.BIG) {
                     break;
                 }
                 pair p2 = (pair) (Vfrom.elementAt(j));
                 for (int j1 = j + 1; j1 < Vfrom.size(); j1++) {
                     if (p2.geneOne == emrae.BIG) {
                         break;
                     }
                     pair p3 = (pair) (Vfrom.elementAt(j1));
                     if (p3.geneOne != emrae.BIG) {
                         for (int k1 = 0; k1 < Vto.size(); k1++) {
                             pair p_1 = (pair) (Vto.elementAt(k1));
                             for (int k2 = k1 + 1; k2 < Vto.size(); k2++) {
                                 if (p_1.geneOne == emrae.BIG) {
                                     break;
                                 }

                                 pair p_2 = (pair) (Vto.elementAt(k2));
                                 for (int k3 = k2 + 1; k3 < Vto.size();
                                               k3++) {
                                     if (p_2.geneOne == emrae.BIG) {
                                         break;
                                     }

                                     pair p_3 = (pair) (Vto.elementAt(
                                             k3));
                                     if (p_3.geneOne != emrae.BIG) {
                                         if (isTransp(p1, p2, p3, p_1, p_2, p_3)) {
                                             transp t = new transp(p1, p2, p3,
                                                     p_1, p_2, p_3);
                                             p.println("A transpotition:");
                                             printTran(p, t, m);
                                             labelPairs(p1, p2, p3, p_1, p_2,
                                                     p_3);
                                         }
                                     }
                                 }
                             }
                         }
                     }
                 }
             }
         }
     }

    //***************
     boolean isSingleRev(pair p1, pair p2, pair p3, pair p4) {
         boolean B = false;
         int k1 = p1.geneOne;
         int k2 = p1.geneTwo;
         int k3 = p2.geneOne;
         int k4 = p2.geneTwo;
         int[] t1 = {Math.abs(k1), Math.abs(k2), Math.abs(k3), Math.abs(k4)};
         int[] t2 = {Math.abs(p3.geneOne), Math.abs(p3.geneTwo),
                    Math.abs(p4.geneOne), Math.abs(p4.geneTwo)};

         Arrays.sort(t1);
         Arrays.sort(t2);

         if (!Arrays.equals(t1, t2)) {
             return B;
         } else {
             if ((t1[0] == t1[1]) || (t1[1] == t1[2]) || (t1[2] == t1[3])) {
                 if (isInv(p1, p2, p3, p4)) {
                     B = true;
                 }
             }
         }
         return B;
     }

//**********
     boolean isInv(pair p1, pair p2, pair p3, pair p4) {
         boolean B = false;
         int k1 = p1.geneOne;
         int k2 = p1.geneTwo;
         int k3 = p2.geneOne;
         int k4 = p2.geneTwo;
         int[] t1 = {Math.abs(k1), Math.abs(k2), Math.abs(k3), Math.abs(k4)};
         int[] t2 = {Math.abs(p3.geneOne), Math.abs(p3.geneTwo),
                    Math.abs(p4.geneOne), Math.abs(p4.geneTwo)};

         Arrays.sort(t1);
         Arrays.sort(t2);
         
         if (!Arrays.equals(t1, t2)) { //same gene content?
             return B;
         } else {
             //CASE 1. p1p2 (k1 k2 k3 k4)
             //perform the reversal;
             boolean b1 = false;
             boolean b2 = false;
             pair tem1 = new pair(k1, -k3);
             pair tem2 = new pair( -k2, k4);
             if (samePair(tem1, p3) &&
                 (Math.abs(k1) != Math.abs(k4))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p4)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }
             b1 = false;
             b2 = false;
             if (samePair(tem1, p4) &&
                 (Math.abs(k1) != Math.abs(k4))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p3)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }
             //CASE 2. p1-p2(k1 k2 -k4 -k3)
             //perform the reversal;
             b1 = false;
             b2 = false;
             tem1 = new pair(k1, k4);
             tem2 = new pair( -k2, -k3);
             if (samePair(tem1, p3) &&
                 (Math.abs(k1) != Math.abs(k3))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p4)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }

             b1 = false;
             b2 = false;
             if (samePair(tem1, p4) &&
                 (Math.abs(k1) != Math.abs(k3))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p3)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }

             //CASE 3. -p1-p2 (-k2 -k1 -k4 -k3)
             //perform the reversal;
             b1 = false;
             b2 = false;
             tem1 = new pair( -k2, k4);
             tem2 = new pair(k1, -k3);
             if (samePair(tem1, p3) &&
                 (Math.abs(k2) != Math.abs(k3))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p4)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }

             b1 = false;
             b2 = false;
             if (samePair(tem1, p4) &&
                 (Math.abs(k2) != Math.abs(k3))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p3)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }

             //CASE 4. -p1p2 (-k2 -k1 k3 k4)
             //perform the reversal;
             b1 = false;
             b2 = false;
             tem1 = new pair( -k2, -k3);
             tem2 = new pair(k1, k4);
             if (samePair(tem1, p3) &&
                 (Math.abs(k2) != Math.abs(k4))) { //avoid 1,2,3,1->1,-2,-3,1
                 b1 = true;
             }
             if (samePair(tem2, p4)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }

             b1 = false;
             b2 = false;
             if (samePair(tem1, p4) &&
                 (Math.abs(k2) != Math.abs(k4))) { //avoid 1,2,3,1->1,-3,-2,1
                 b1 = true;
             }
             if (samePair(tem2, p3)) {
                 b2 = true;
             }
             if (b1 && b2) {
                 B = true;
                 return B;
             }
         }
         return B;
     }

    //***************************************
     void effInferTranFinal(PrintWriter p, int[][] index, int[][] m) {
         Vector Vfrom;
         Vector Vto;

         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.finalAdjOne;
             Vto = this.finalAdjTwo;
         } else {
             Vfrom = this.finalAdjTwo;
             Vto = this.finalAdjOne;
         }

         int m1 = Vfrom.size();
         int m2 = Vto.size();
         //
         Vector[] lab1 = new Vector[Vfrom.size()];
         Vector[] lab2 = new Vector[Vto.size()];

         for (int i = 0; i < lab1.length; i++) {
             lab1[i] = new Vector();
         }
         for (int i = 0; i < lab2.length; i++) {
             lab2[i] = new Vector();
         }

         boolean[] used1 = new boolean[m1];
         boolean[] used2 = new boolean[m2];

         //find all the neighbors in the opposite side.
         for (int i = 0; i < m1; i++) {
             pair p1 = (pair) (Vfrom.elementAt(i));
             if (p1.geneOne != emrae.BIG) {
                 for (int j = 0; j < m2; j++) {
                     pair p2 = (pair) (Vto.elementAt(j));
                     if (p2.geneOne != emrae.BIG) {
                         if (overlap(p1, p2)) {
                             lab1[i].addElement(new Integer(j));
                             lab2[j].addElement(new Integer(i));
                         }
                     } else {
                         used2[j] = true;
                     }
                 }
             } else {
                 used1[i] = true;
             }
         }

         //those pairs overlapping with less than 2 pairs are not able to form a transposition.
         for (int i = 0; i < m1; i++) {
             if (lab1[i].size() <= 1) {
                 used1[i] = true;
             }
         }
         for (int i = 0; i < m2; i++) {
             if (lab2[i].size() <= 1) {
                 used2[i] = true;
             }
         }
         //for each pair i, detect its possible chain and infer tran, then delete the chain of pairs
         for (int i = 0; i < m1; i++) {
             if (!used1[i]) {
                 Vector s = new Vector();
                 Vector t = new Vector();

                 Vector set1 = new Vector();
                 Vector set2 = new Vector();

                 set1.addElement(new Integer(i));
                 s.addElement(new Integer(i));

                 int step = 0;

                 int ob = 2;
                 int num = set1.size();
                 //all the related pairs to pair tem. s and t.
                 while (num >= 1 && step <= 2) {
                     if (ob == 2) {
                         set2 = new Vector();
                         for (int j = 0; j < set1.size(); j++) {
                             int pairNum = ((Integer) (set1.elementAt(j))).
                                           intValue();
                             Vector a = (Vector) (lab1[pairNum]);
                             for (int k = 0; k < a.size(); k++) {
                                 int real = ((Integer) (a.elementAt(k))).
                                            intValue();
                                 if (!used2[real]) {
                                     set2.addElement(new Integer(real));
                                     t.addElement(new Integer(real));
                                     used2[real] = true;
                                 }
                             }
                             used1[pairNum] = true;
                         }
                         num = set2.size();
                         ob = 1;
                         step++;
                     } else if (ob == 1) {
                         set1 = new Vector();
                         for (int j = 0; j < set2.size(); j++) {
                             int pairNum = ((Integer) (set2.elementAt(j))).
                                           intValue();
                             Vector a = (Vector) (lab2[pairNum]);
                             for (int k = 0; k < a.size(); k++) {
                                 int real = ((Integer) (a.elementAt(k))).
                                            intValue();
                                 if (!used1[real]) {
                                     set1.addElement(new Integer(real));
                                     s.addElement(new Integer(real));
                                     used1[real] = true;
                                 }
                             }
                             used2[pairNum] = true;
                         }
                         num = set1.size();
                         ob = 2;
                         step++;
                     }
                 }

                 for (int k = 0; k < s.size(); k++) {
                     int t1 = ((Integer) (s.elementAt(k))).intValue();
                     if (t1 > i) {
                         used1[t1] = false;
                     }
                 }
                 for (int k = 0; k < t.size(); k++) {
                     int t1 = ((Integer) (t.elementAt(k))).intValue();
                     used2[t1] = false;
                 }

                 //infer trans
                 if (s.size() > 2 && t.size() > 2) {
                     for (int i1 = 0; i1 < s.size(); i1++) {
                         int t1 = ((Integer) (s.elementAt(i1))).intValue();
                         pair p1 = (pair) (Vfrom.elementAt(t1));
                         for (int j = i1 + 1; j < s.size(); j++) {
                             if (p1.geneOne == emrae.BIG) {
                                 break;
                             }
                             int t2 = ((Integer) (s.elementAt(j))).intValue();
                             pair p2 = (pair) (Vfrom.elementAt(t2));
                             for (int j1 = j + 1; j1 < s.size(); j1++) {
                                 if (p2.geneOne == emrae.BIG) {
                                     break;
                                 }
                                 int t3 = ((Integer) (s.elementAt(j1))).
                                          intValue();
                                 pair p3 = (pair) (Vfrom.elementAt(t3));
                                 if (p3.geneOne != emrae.BIG) {
                                     for (int k1 = 0; k1 < t.size(); k1++) {
                                         int t_1 = ((Integer) (t.elementAt(k1))).
                                                 intValue();
                                         pair p_1 = (pair) (Vto.elementAt(t_1));
                                         for (int k2 = k1 + 1; k2 < t.size();
                                                 k2++) {
                                             if (p_1.geneOne == emrae.BIG) {
                                                 break;
                                             }
                                             int t_2 = ((Integer) (t.elementAt(
                                                     k2))).intValue();
                                             pair p_2 = (pair) (Vto.elementAt(
                                                     t_2));
                                             for (int k3 = k2 + 1;
                                                     k3 < t.size();
                                                     k3++) {
                                                 if (p_2.geneOne == emrae.BIG) {
                                                     break;
                                                 }
                                                 int t_3 = ((Integer) (t.
                                                         elementAt(k3))).
                                                         intValue();
                                                 pair p_3 = (pair) (Vto.
                                                         elementAt(
                                                         t_3));
                                                 if (p_3.geneOne != emrae.BIG) {
                                                     if (isTransp(p1, p2, p3,
                                                             p_1, p_2, p_3,
                                                             index) == 1) {
                                                         transp tt = new
                                                                 transp(
                                                                 p1, p2, p3,
                                                                 p_1, p_2,
                                                                 p_3);
                                                         if (!noZero(
                                                                 p1, p2, p3,
                                                                 p_1, p_2,
                                                                 p_3)) {
                                                             ;
                                                         } else {
                                                             p.println(
                                                                     "A transposition:");
                                                             this.trans.
                                                                     addElement(
                                                                     tt);
                                                             printTran(p, tt,
                                                                     m);
                                                             labelPairs(p1, p2,
                                                                     p3,
                                                                     p_1, p_2,
                                                                     p_3);
                                                         }
                                                     } else if (isTransp(p1,
                                                             p2, p3,
                                                             p_1, p_2, p_3,
                                                             index) == 2) {
//                                                          transp tt = new
//                                                                  transp(
//                                                                  p1, p2, p3,
//                                                                  p_1, p_2,
//                                                                  p_3);
//                                                          if (!noZero(
//                                                                  p1, p2, p3,
//                                                                  p_1, p_2,
//                                                                  p_3)) {
//                                                              ;
//                                                          } else {
//                                                              p.println(
//                                                                      "A inverted final tran:");
//                                                              this.trans.
//                                                                      addElement(
//                                                                      tt);
//                                                              printTran(p, tt,
//                                                                      m);
//                                                              labelPairs(p1, p2,
//                                                                      p3,
//                                                                      p_1, p_2,
//                                                                      p_3);
//                                                          }
                                                     }
                                                 }
                                             }
                                         }
                                     }
                                 }
                             }
                         }
                     }

                 }
                 for (int i1 = 0; i1 < s.size(); i1++) {
                     int t1 = ((Integer) (s.elementAt(i1))).intValue();
                     pair tmp = (pair) (Vfrom.elementAt(t1));
                     if (t1 > i && tmp.geneOne != emrae.BIG) {
                         used1[t1] = false;
                     }

                 }
                 for (int i1 = 0; i1 < t.size(); i1++) {
                     int t1 = ((Integer) (t.elementAt(i1))).intValue();
                     pair tmp = (pair) (Vto.elementAt(t1));
                     if (tmp.geneOne != emrae.BIG) {
                         used2[t1] = false;
                     }
                 }
             }
         }
     }

    //****************************
     void effInferRealTran(PrintWriter p) {
         Vector Vfrom;
         Vector Vto;

         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.rAdjOne;
             Vto = this.rAdjTwo;
         } else {
             Vfrom = this.rAdjTwo;
             Vto = this.rAdjOne;
         }

         int m1 = Vfrom.size();
         int m2 = Vto.size();
         //
         Vector[] lab1 = new Vector[Vfrom.size()];
         Vector[] lab2 = new Vector[Vto.size()];

         for (int i = 0; i < lab1.length; i++) {
             lab1[i] = new Vector();
         }
         for (int i = 0; i < lab2.length; i++) {
             lab2[i] = new Vector();
         }

         boolean[] used1 = new boolean[m1];
         boolean[] used2 = new boolean[m2];

         //find all the neighbors in the opposite side.
         for (int i = 0; i < m1; i++) {
             pair p1 = (pair) (Vfrom.elementAt(i));
             if (p1.geneOne != emrae.BIG) {
                 for (int j = 0; j < m2; j++) {
                     pair p2 = (pair) (Vto.elementAt(j));
                     if (p2.geneOne != emrae.BIG) {
                         if (overlap(p1, p2)) {
                             lab1[i].addElement(new Integer(j));
                             lab2[j].addElement(new Integer(i));
                         }
                     } else {
                         used2[j] = true;
                     }
                 }
             } else {
                 used1[i] = true;
             }
         }

         //those pairs overlapping with less than 2 pairs are not able to form a transposition.
         for (int i = 0; i < m1; i++) {
             if (lab1[i].size() <= 1) {
                 used1[i] = true;
             }
         }
         for (int i = 0; i < m2; i++) {
             if (lab2[i].size() <= 1) {
                 used2[i] = true;
             }
         }
         //for each pair i, detect its possible chain and infer tran, then delete the chain of pairs
         for (int i = 0; i < m1; i++) {
             if (!used1[i]) {
                 Vector s = new Vector();
                 Vector t = new Vector();

                 Vector set1 = new Vector();
                 Vector set2 = new Vector();

                 set1.addElement(new Integer(i));
                 s.addElement(new Integer(i));

                 int step = 0;

                 int ob = 2;
                 int num = set1.size();
                 //all the related pairs to pair tem. s and t.
                 while (num >= 1 && step <= 2) {
                     if (ob == 2) {
                         set2 = new Vector();
                         for (int j = 0; j < set1.size(); j++) {
                             int pairNum = ((Integer) (set1.elementAt(j))).
                                           intValue();
                             Vector a = (Vector) (lab1[pairNum]);
                             for (int k = 0; k < a.size(); k++) {
                                 int real = ((Integer) (a.elementAt(k))).
                                            intValue();
                                 if (!used2[real]) {
                                     set2.addElement(new Integer(real));
                                     t.addElement(new Integer(real));
                                     used2[real] = true;
                                 }
                             }
                             used1[pairNum] = true;
                         }
                         num = set2.size();
                         ob = 1;
                         step++;
                     } else if (ob == 1) {
                         set1 = new Vector();
                         for (int j = 0; j < set2.size(); j++) {
                             int pairNum = ((Integer) (set2.elementAt(j))).
                                           intValue();
                             Vector a = (Vector) (lab2[pairNum]);
                             for (int k = 0; k < a.size(); k++) {
                                 int real = ((Integer) (a.elementAt(k))).
                                            intValue();
                                 if (!used1[real]) {
                                     set1.addElement(new Integer(real));
                                     s.addElement(new Integer(real));
                                     used1[real] = true;
                                 }
                             }
                             used2[pairNum] = true;
                         }
                         num = set1.size();
                         ob = 2;
                         step++;
                     }
                 }

                 for (int k = 0; k < s.size(); k++) {
                     int t1 = ((Integer) (s.elementAt(k))).intValue();
                     if (t1 > i) {
                         used1[t1] = false;
                     }
                 }
                 for (int k = 0; k < t.size(); k++) {
                     int t1 = ((Integer) (t.elementAt(k))).intValue();
                     used2[t1] = false;
                 }

                 //infer trans
                 if (s.size() > 2 && t.size() > 2) {
                     //System.out.println("s=" + s.size() + ", t=" + t.size());
                     for (int i1 = 0; i1 < s.size(); i1++) {
                         int t1 = ((Integer) (s.elementAt(i1))).intValue();
                         pair p1 = (pair) (Vfrom.elementAt(t1));
                         for (int j = i1 + 1; j < s.size(); j++) {
                             if (p1.geneOne == emrae.BIG) {
                                 break;
                             }
                             int t2 = ((Integer) (s.elementAt(j))).intValue();
                             pair p2 = (pair) (Vfrom.elementAt(t2));
                             for (int j1 = j + 1; j1 < s.size(); j1++) {
                                 if (p2.geneOne == emrae.BIG) {
                                     break;
                                 }
                                 int t3 = ((Integer) (s.elementAt(j1))).
                                          intValue();
                                 pair p3 = (pair) (Vfrom.elementAt(t3));
                                 if (p3.geneOne != emrae.BIG) {
                                     for (int k1 = 0; k1 < t.size(); k1++) {
                                         int t_1 = ((Integer) (t.elementAt(k1))).
                                                 intValue();
                                         pair p_1 = (pair) (Vto.elementAt(t_1));
                                         for (int k2 = k1 + 1; k2 < t.size();
                                                 k2++) {
                                             if (p_1.geneOne == emrae.BIG) {
                                                 break;
                                             }
                                             int t_2 = ((Integer) (t.elementAt(
                                                     k2))).intValue();
                                             pair p_2 = (pair) (Vto.elementAt(
                                                     t_2));
                                             for (int k3 = k2 + 1;
                                                     k3 < t.size();
                                                     k3++) {
                                                 if (p_2.geneOne == emrae.BIG) {
                                                     break;
                                                 }
                                                 int t_3 = ((Integer) (t.
                                                         elementAt(k3))).
                                                         intValue();
                                                 pair p_3 = (pair) (Vto.
                                                         elementAt(
                                                         t_3));
                                                 if (p_3.geneOne != emrae.BIG) {
                                                     //*
                                                      if (isTransp(p1, p2, p3,
                                                              p_1, p_2, p_3)) {
                                                          if (!noZero(
                                                                  p1, p2, p3,
                                                                  p_1, p_2,
                                                                  p_3)) {
                                                              ;
                                                          } else {
                                                              labelPairs(p1, p2,
                                                                      p3,
                                                                      p_1, p_2,
                                                                      p_3);

                                                          }

                                                      }
                                                 }
                                             }
                                         }
                                     }
                                 }
                             }
                         }
                     }

                 }
             }
         }
     }

    //***************************************
     void effInferInvFinal(PrintWriter p, int[][] index, int[][] m,
                           Vector genomes) {
         Vector Vfrom;
         Vector Vto;
         int size1;
         int size2;
         Vector Sfrom;
         Vector Sto;

         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.finalAdjOne;
             Vto = this.finalAdjTwo;
             Sfrom = this.setOne;
             Sto = this.setTwo;
         } else {
             Vfrom = this.finalAdjTwo;
             Vto = this.finalAdjOne;
             Sfrom = this.setTwo;
             Sto = this.setOne;
         }
         size1 = Sfrom.size();
         size2 = Sto.size();
         int m1 = Vfrom.size();
         int m2 = Vto.size();

         //
         Vector[] lab1 = new Vector[Vfrom.size()];
         Vector[] lab2 = new Vector[Vto.size()];

         for (int i = 0; i < lab1.length; i++) {
             lab1[i] = new Vector();
         }
         for (int i = 0; i < lab2.length; i++) {
             lab2[i] = new Vector();
         }

         boolean[] used1 = new boolean[m1];
         boolean[] used2 = new boolean[m2];

         //find all the neighbors in the opposite side.
         for (int i = 0; i < m1; i++) {
             pair p1 = (pair) (Vfrom.elementAt(i));
             if (p1.geneOne != emrae.BIG) {
                 for (int j = 0; j < m2; j++) {
                     pair p2 = (pair) (Vto.elementAt(j));
                     if (p2.geneOne != emrae.BIG) {
                         if (overlap(p1, p2)) {
                             lab1[i].addElement(new Integer(j));
                             lab2[j].addElement(new Integer(i));
                         }
                     } else {
                         used2[j] = true;
                     }
                 }
             } else {
                 used1[i] = true;
             }
         }

         //those pairs overlapping with less than 2 pairs are not able to form a transposition.
         for (int i = 0; i < m1; i++) {
             if (lab1[i].size() <= 1) {
                 used1[i] = true;
             }
         }
         for (int i = 0; i < m2; i++) {
             if (lab2[i].size() <= 1) {
                 used2[i] = true;
             }
         }
         //for each pair i, detect its possible chain and infer tran, then delete the chain of pairs
         for (int i = 0; i < m1; i++) {
             if (!used1[i]) {
                 Vector s = new Vector();
                 Vector t = new Vector();

                 Vector set1 = new Vector();
                 Vector set2 = new Vector();

                 set1.addElement(new Integer(i));
                 s.addElement(new Integer(i));

                 int step = 0;

                 int ob = 2;
                 int num = set1.size();
                 //all the related pairs to pair tem. s and t.
                 while (num >= 1 && step <= 1) {
                     if (ob == 2) {
                         set2 = new Vector();
                         for (int j = 0; j < set1.size(); j++) {
                             int pairNum = ((Integer) (set1.elementAt(j))).
                                           intValue();
                             Vector a = (Vector) (lab1[pairNum]);
                             for (int k = 0; k < a.size(); k++) {
                                 int real = ((Integer) (a.elementAt(k))).
                                            intValue();
                                 if (!used2[real]) {
                                     set2.addElement(new Integer(real));
                                     t.addElement(new Integer(real));
                                     used2[real] = true;
                                 }
                             }
                             used1[pairNum] = true;
                         }
                         num = set2.size();
                         ob = 1;
                         step++;
                     } else if (ob == 1) {
                         set1 = new Vector();
                         for (int j = 0; j < set2.size(); j++) {
                             int pairNum = ((Integer) (set2.elementAt(j))).
                                           intValue();
                             Vector a = (Vector) (lab2[pairNum]);
                             for (int k = 0; k < a.size(); k++) {
                                 int real = ((Integer) (a.elementAt(k))).
                                            intValue();
                                 if (!used1[real]) {
                                     set1.addElement(new Integer(real));
                                     s.addElement(new Integer(real));
                                     used1[real] = true;
                                 }
                             }
                             used2[pairNum] = true;
                         }
                         num = set1.size();
                         ob = 2;
                         step++;
                     }
                 }

                 for (int k = 0; k < s.size(); k++) {
                     int t1 = ((Integer) (s.elementAt(k))).intValue();
                     if (t1 > i) {
                         used1[t1] = false;
                     }
                 }
                 for (int k = 0; k < t.size(); k++) {
                     int t1 = ((Integer) (t.elementAt(k))).intValue();
                     used2[t1] = false;
                 }

                 //infer invs
                 if (s.size() > 1 && t.size() > 1) {
                     //System.out.println("s=" + s.size() + ", t=" + t.size());
                     for (int i1 = 0; i1 < s.size(); i1++) {
                         int k1 = ((Integer) (s.elementAt(i1))).intValue();
                         pair p1 = (pair) (Vfrom.elementAt(k1));
                         for (int i2 = i1 + 1; i2 < s.size(); i2++) {
                             if (p1.geneOne == emrae.BIG) {
                                 break;
                             }
                             int k2 = ((Integer) (s.elementAt(i2))).intValue();
                             pair p2 = (pair) (Vfrom.elementAt(k2));
                             for (int j1 = 0; j1 < t.size(); j1++) {
                                 if (p2.geneOne == emrae.BIG) {
                                     break;
                                 }
                                 int kk1 = ((Integer) (t.elementAt(j1))).
                                           intValue();
                                 pair n1 = (pair) (Vto.elementAt(kk1));
                                 for (int j2 = j1 + 1; j2 < t.size(); j2++) {
                                     if (n1.geneOne == emrae.BIG) {
                                         break;
                                     }
                                     int kk2 = ((Integer) (t.elementAt(j2))).
                                               intValue();
                                     pair n2 = (pair) (Vto.elementAt(kk2));
                                     if (n2.geneOne != emrae.BIG) {
                                         if (isInv(p1, p2, n1, n2)) {

                                             int c1 = 0;
                                             int c_1 = 0;
                                             int c2 = 0;
                                             int c_2 = 0;

                                             //count c1 for m1 and m2;
                                             for (int k = 0; k < size1; k++) {
                                                 int rk = ((Integer) (Sfrom.
                                                         elementAt(k))).
                                                         intValue();
                                                 if ((index[rk][p1.index] ==
                                                         index[rk][p2.index]) &&
                                                         (index[rk][p1.index] !=
                                                         -1)) {
                                                     c1++;
                                                 }
                                                 if ((index[rk][p1.index] !=
                                                         index[rk][p2.index]) &&
                                                         (index[rk][p1.index] !=
                                                         -1) &&
                                                         (index[rk][p2.index] !=
                                                         -1)) {
                                                     c_1++;
                                                 }
                                             }
                                             //count c2 for n1 and n2;
                                             for (int k = 0; k < size2; k++) {
                                                 int rk = ((Integer) (Sto.
                                                         elementAt(k))).
                                                         intValue();
                                                 if ((index[rk][n1.index] ==
                                                         index[rk][n2.index]) &&
                                                         (index[rk][n1.index] !=
                                                         -1)) {
                                                     c2++;
                                                 }
                                                 if ((index[rk][n1.index] !=
                                                         index[rk][n2.index]) &&
                                                         (index[rk][n1.index] !=
                                                         -1) &&
                                                         (index[rk][n2.index] !=
                                                         -1)) {
                                                     c_2++;
                                                 }
                                             }
                                             //inf indicates if m1, m2, n1, n2 recover an event.
                                             if (c1 > 0 && c2 > 0) {
                                                 inversion inv = new inversion();
                                                 inv.p1 = new pair(p1.geneOne,
                                                         p1.geneTwo);
                                                 inv.p2 = new pair(p2.geneOne,
                                                         p2.geneTwo);
                                                 inv.q1 = new pair(n1.geneOne,
                                                         n1.geneTwo);
                                                 inv.q2 = new pair(n2.geneOne,
                                                         n2.geneTwo);
                                                 this.invs.addElement(inv);
                                                 p.println("A reversal:");
                                                 printReversal(p, p1, p2, n1,
                                                         n2, m);
                                                 labelPairs(p1, p2, n1, n2);
                                             } else if (c_1 > 0 && c_2 > 0 &&
                                                     (c1 == 0 || c2 == 0)) {
                                                 p.println("A translocation:");
                                                 tlc tt = new tlc(p1, p2, n1,
                                                         n2);
                                                 this.tlcs.addElement(tt);
                                                 printReversal(p, p1, p2, n1,
                                                         n2, m);
                                                 labelPairs(p1, p2, n1, n2);
                                             }
                                             //ambiguous conditions
                                             else if (((c1 == 0 && c_1 > 0) &&
                                                     (c2 > 0 && c_2 == 0)) ||
                                                     ((c1 > 0 && c_1 == 0) &&
                                                     (c2 == 0 && c_2 > 0))) {
                                                 inversion inv = new inversion();
                                                 inv.p1 = new pair(p1.geneOne,
                                                         p1.geneTwo);
                                                 inv.p2 = new pair(p2.geneOne,
                                                         p2.geneTwo);
                                                 inv.q1 = new pair(n1.geneOne,
                                                         n1.geneTwo);
                                                 inv.q2 = new pair(n2.geneOne,
                                                         n2.geneTwo);
                                                 this.invs.addElement(inv);
                                                 p.println("A reversal:");
                                                 printReversal(p, p1, p2, n1,
                                                         n2, m);
                                                 labelPairs(p1, p2, n1, n2);
                                             } else if ((c1 > 0 && c2 == 0 &&
                                                     c_2 == 0) ||
                                                     (c1 == 0 && c_1 == 0 &&
                                                     c2 > 0)) {
                                                 inversion inv = new inversion();
                                                 inv.p1 = new pair(p1.geneOne,
                                                         p1.geneTwo);
                                                 inv.p2 = new pair(p2.geneOne,
                                                         p2.geneTwo);
                                                 inv.q1 = new pair(n1.geneOne,
                                                         n1.geneTwo);
                                                 inv.q2 = new pair(n2.geneOne,
                                                         n2.geneTwo);
                                                 this.invs.addElement(inv);
                                                 p.println(
                                                         "A reversal:");
                                                 printReversal(p, p1, p2, n1,
                                                         n2, m);
                                                 labelPairs(p1, p2, n1, n2);
                                             } else if ((c1 == 0 && c_1 > 0 &&
                                                     c2 == 0 &&
                                                     c_2 == 0) ||
                                                     (c1 == 0 && c_1 == 0 &&
                                                     c_2 > 0 &&
                                                     c2 == 0)) {
                                                 tlc tt = new tlc(p1, p2, n1,
                                                         n2);
                                                 this.tlcs.addElement(tt);
                                                 p.println("A tranlocation:");
                                                 printReversal(p, p1, p2, n1,
                                                         n2, m);
                                                 labelPairs(p1, p2, n1, n2);
                                             }

                                         }
                                     }
                                 }
                             }
                         }
                     }

                 }
             }
         }
     }

    //****************************
     boolean noZero(pair p1, pair p2, pair p3, pair p_1, pair p_2, pair p_3) {
         if (p1.geneOne == 0 || p1.geneTwo == 0) {
             return false;
         } else if (p2.geneOne == 0 || p2.geneTwo == 0) {
             return false;
         } else if (p3.geneOne == 0 || p3.geneTwo == 0) {
             return false;
         } else if (p_1.geneOne == 0 || p_2.geneTwo == 0
                 ) {
             return false;
         } else if (p_2.geneOne == 0 || p_2.geneTwo == 0) {
             return false;
         } else if (p_3.geneOne == 0 || p_3.geneTwo == 0) {
             return false;
         } else {
             return true;
         }

     }


    //******************************
     void printTran(PrintWriter p, transp IN, int[][] m) {
         Vector Sfrom;
         Vector Sto;
         if (this.from == this.nodeOne.nodeID) {
             Sfrom = this.setOne;
             Sto = this.setTwo;
         } else {
             Sfrom = this.setTwo;
             Sto = this.setOne;
         }

         p.print(IN.p1.geneOne + "," + IN.p1.geneTwo + "," +
                 IN.p2.geneOne +
                 "," + IN.p2.geneTwo + "," + IN.p3.geneOne + "," +
                 IN.p3.geneTwo);
//         for (int i = 0; i < Sfrom.size(); i++) {
//             int k = ((Integer) (Sfrom.elementAt(i))).intValue();
//             if (IN.p1.index >= 0 && IN.p2.index >= 0 && IN.p3.index >= 0) {
//                 if (m[k][IN.p1.index] == 1 && m[k][IN.p2.index] == 1 &&
//                     m[k][IN.p3.index] == 1) {
//                     p.print(k + ",");
//                 }
//             }
//         }
         p.println();
         p.print(IN.q1.geneOne + "," + IN.q1.geneTwo + "," +
                 IN.q2.geneOne +
                 "," + IN.q2.geneTwo + "," + IN.q3.geneOne + "," +
                 IN.q3.geneTwo);

//         for (int i = 0; i < Sto.size(); i++) {
//             int k = ((Integer) (Sto.elementAt(i))).intValue();
//             if (IN.q1.index >= 0 && IN.q2.index >= 0 && IN.q3.index >= 0) {
//                 if (m[k][IN.q1.index] == 1 && m[k][IN.q2.index] == 1 &&
//                     m[k][IN.q3.index] == 1) {
//                     p.print(k + ",");
//                 }
//             }
//         }
         p.println();

     }

//*********************************
//judge if gene a and b are at a same chrom of genome G
     boolean atSameChrom(int a, int b, Genome G) {
         boolean same = false;
         for (int k = 0; k < G.Chroms.size(); k++) {
             int[] ch = (int[]) (G.Chroms.elementAt(k));
             boolean s1 = false;
             boolean s2 = false;
             for (int m = 0; m < ch.length; m++) {
                 if (Math.abs(ch[m]) == Math.abs(a)) {
                     s1 = true;
                 }
                 if (Math.abs(ch[m]) == Math.abs(b)) {
                     s2 = true;
                 }
             }
             if (s1 && s2) {
                 same = true;
                 break;
             }
         }
         return same;
     }

//**************************************
     void printInv(PrintWriter p, inversion in) {
         p.println("(" + in.p1.geneOne + "," + in.p1.geneTwo + "), (" +
                   in.p2.geneOne +
                   "," + in.p2.geneTwo + ")->");
         p.println("(" + in.q1.geneOne + "," + in.q1.geneTwo + "), (" +
                   in.q2.geneOne + "," + in.q2.geneTwo + ")\n");
     }

//*****************************************************
     void printFP(PrintWriter p, pair p1, pair p2, pair q1, pair q2) {
         p.println("(" + p1.geneOne + "," + p1.geneTwo + "), (" +
                   p2.geneOne +
                   "," + p2.geneTwo + ")->");
         p.println("(" + q1.geneOne + "," + q1.geneTwo + "), (" +
                   q2.geneOne + "," + q2.geneTwo + ")\n");
     }

//**************************************************
     void printReversal(PrintWriter p, pair p1, pair p2, pair q1, pair q2,
             int[][] m) {
          Vector Sfrom;
          Vector Sto;
          if (this.from == this.nodeOne.nodeID) {
              Sfrom = this.setOne;
              Sto = this.setTwo;
          } else {
              Sfrom = this.setTwo;
              Sto = this.setOne;
          }

         p.print(p1.geneOne + "," + p1.geneTwo + "," +
                p2.geneOne +
                 "," + p2.geneTwo);
         //for (int i = 0; i < Sfrom.size(); i++) {
         //  int k = ((Integer) (Sfrom.elementAt(i))).intValue();
        //  if (m[k][p1.index] == 1 && m[k][p2.index] == 1) {
         //      p.print(k + ",");
           //  }
         //}
         p.println();
         p.print(q1.geneOne + "," + q1.geneTwo + "," +
         q2.geneOne + "," + q2.geneTwo);
         //for (int i = 0; i < Sto.size(); i++) {
        //  int k = ((Integer) (Sto.elementAt(i))).intValue();
         //  if (m[k][q1.index] == 1 && m[k][q2.index] == 1) {
         //      p.print(k + ",");
         //  }
          //}
         p.println();

     }

//**********************************************************************
     void printTransp(PrintWriter p, pair p1, pair p2, pair p3, pair q1,
                      pair q2,
                      pair q3) {
         p.println("(" + p1.geneOne + "," + p1.geneTwo + "), (" +
                   p2.geneOne + "," + p2.geneTwo + "),(" + p3.geneOne + "," +
                   p3.geneTwo + ")->");
         p.println("(" + q1.geneOne + "," + q1.geneTwo + "), (" +
                   q2.geneOne + "," + q2.geneTwo + "),(" + q3.geneOne + "," +
                   q3.geneTwo + ")");
     }

//**************************************

//*******************************************
     //this method test if 3 invs corresponds to another 3 from tInvs1.
     //note that the size of tInv is times of 3.
     boolean realInvs(inversion in1, inversion in2, inversion in3,
                      Vector[] tInvs) {
         int[] b = new int[3];
         boolean B = false;
         inversion[] s = {
                         in1, in2, in3};

         for (int j = 0; j < tInvs.length; j++) {
             Vector tInv = tInvs[j];
             for (int i = 0; i < tInv.size() / 3; i++) {
                 inversion v1 = (inversion) (tInv.elementAt(3 * i));
                 inversion v2 = (inversion) (tInv.elementAt(3 * i + 1));
                 inversion v3 = (inversion) (tInv.elementAt(3 * i + 2));
                 inversion[] t = {
                                 v1, v2, v3};

                 for (int m = 0; m < 3; m++) {
                     for (int n = 0; n < 3; n++) {
                         int a = sameInversion(s[m], t[n]);
                         if ((a == 1) || (a == 2)) {
                             b[m] = a;
                             //break;
                         }
                     }
                 }
                 if ((b[0] == 1) && (b[1] == 1) && (b[2] == 1)) {
                     B = true;
                     return true;
                 } else if ((b[0] == 2) && (b[1] == 2) && (b[2] == 2)) {
                     B = true;
                     return true;
                 }
             }
         }

         return B;
     }

//**********************************
     //this condition is looser than that of sameInversion()
     boolean sameTlc(inversion real, inversion mgr) {
         int k1 = real.p1.geneOne;
         int k2 = real.p1.geneTwo;
         int k3 = real.p2.geneOne;
         int k4 = real.p2.geneTwo;

         int m1 = mgr.p1.geneOne;
         int m2 = mgr.p1.geneTwo;
         int m3 = mgr.p2.geneOne;
         int m4 = mgr.p2.geneTwo;
         boolean B = false;
         if ((k1 == m1) && (k2 == m2) && (k3 == m3) && (k4 == m4)) {
             B = true;
         } else if ((m1 == -k2) && (m2 == -k1) && (m3 == -k4) && (m4 == -k3)) {
             B = true;
         } else if ((m1 == k3) && (m2 == k4) && (m3 == k1) && (m4 == k2)) {
             B = true;
         } else if ((m1 == -k4) && (m2 == -k3) && (m3 == -k2) && (m4 == -k1)) {
             B = true;
         } else {
             ;
         }

         return B;
     }

    /*****************************************************************
     * This is only for test if the MGR inversion is the same as     *
     * the real inversion. It returns true only if the two inversions*
     * are completely the same.                                      *
     *****************************************************************/
    int sameInversion(inversion real, inversion mgr) {

        int k1 = real.p1.geneOne;
        int k2 = real.p1.geneTwo;
        int k3 = real.p2.geneOne;
        int k4 = real.p2.geneTwo;

        int m1 = mgr.p1.geneOne;
        int m2 = mgr.p1.geneTwo;
        int m3 = mgr.p2.geneOne;
        int m4 = mgr.p2.geneTwo;

        if ((k1 == m1) && (k2 == m2) && (k3 == m3) && (k4 == m4)) {
            //indicate that mgr and real have same orientation.
            return 1;
        } else if ((k1 == -m4) && (k2 == -m3) && (k3 == -m2) && (k4 == -m1)) {
            //indicate that mgr and real have opposite orientation.
            return 2;
        } else {
            //mgr and real are different inversions.
            return 3;
        }
    }

//****************
     void printInv(PrintWriter p, pair p1, pair p2, pair p_1, pair p_2) {
         p.println(p1.geneOne + "," +
                   p1.geneTwo +
                   ", " + p2.geneOne + "," +
                   p2.geneTwo + " and " +
                   p_1.geneOne + "," +
                   p_1.geneTwo +
                   ", " + p_2.geneOne + "," +
                   p_2.geneTwo +
                   ".\n");

     }

//*****************************
     boolean isTranspOriginal(pair p1, pair p2, pair p3, pair q1, pair q2,
                              pair q3) {
         boolean B = false;
         int k1 = p1.geneOne;
         int k2 = p1.geneTwo;
         int k3 = p2.geneOne;
         int k4 = p2.geneTwo;
         int k5 = p3.geneOne;
         int k6 = p3.geneTwo;
         int m1 = q1.geneOne;
         int m2 = q1.geneTwo;
         int m3 = q2.geneOne;
         int m4 = q2.geneTwo;
         int m5 = q3.geneOne;
         int m6 = q3.geneTwo;
         int[] t1 = {
                    Math.abs(k1), Math.abs(k2), Math.abs(k3), Math.abs(k4),
                    Math.abs(k5), Math.abs(k6)};
         int[] t2 = {
                    Math.abs(m1), Math.abs(m2), Math.abs(m3), Math.abs(m4),
                    Math.abs(m5), Math.abs(m6)};
         int[] a = new int[6];
         int[] b = {
                   k1, k2, k3, k4, k5, k6};
         Arrays.sort(t1);
         Arrays.sort(t2);
         if (!Arrays.equals(t1, t2)) {
             return B;
         } else {
             return true;
             /* simplify transpositions
                       for (int i1 = 0; i1 < 3; i1++) {
                           for (int i2 = 0; i2 < 2; i2++) {
                               for (int j1 = 0; j1 < 3; j1++) {
                                   for (int j2 = 0; j2 < 2; j2++) {
                                       if (j1 != i1) {
                                           int pos = left(i1, j1);
                                           setArray(a, b, i1, i2, 0);
                                           setArray(a, b, j1, j2, 1);
                                           setArray(a, b, pos, 0, 2);
                                           B = testTransp(a, q1, q2, q3);
                                           if (B) {
                                               return B;
                                           }
                                           setArray(a, b, pos, 1, 2);
                                           B = testTransp(a, q1, q2, q3);
                                           if (B) {
                                               return B;
                                           }
                                       }
                                   }
                               }
                           }
                       }
              */
         }
         //return B;
     }

//*************
     //in this method, test if in[]a and q1, q2, q3 form a transp.
     boolean testTransp(int[] a, pair q1, pair q2, pair q3) {
         boolean B = false;
         for (int i = 0; i < 6; i++) {
             int tmp = Math.abs(a[i]);
             for (int j = i + 1; j < 6; j++) {
                 int tmp2 = Math.abs(a[j]);
                 if (tmp2 == tmp) {
                     if ((j / 2 - i / 2) != 1) {
                         return false;
                     }
                 }
             }
         }
         int[] b = new int[6];

         //performs a forward transp.
         b[0] = a[0];
         b[1] = a[3];
         b[2] = a[4];
         b[3] = a[1];
         b[4] = a[2];
         b[5] = a[5];

         if (b[1] == -b[3] && b[2] == -b[4]) {
             return false;
         }

         pair p1 = new pair(b[0], b[1]);
         pair p2 = new pair(b[2], b[3]);
         pair p3 = new pair(b[4], b[5]);
         boolean b1 = false;
         boolean b2 = false;
         boolean b3 = false;
         if (samePair(q1, p1) || samePair(q1, p2) || samePair(q1, p3)) {
             b1 = true;
         }
         if (samePair(q2, p1) || samePair(q2, p2) || samePair(q2, p3)) {
             b2 = true;
         }
         if (samePair(q3, p1) || samePair(q3, p2) || samePair(q3, p3)) {
             b3 = true;
         }

         if (b1 && b2 && b3 && (b[0] != b[5])) {
             return true;
         }

//         b[0] = a[0];
//         b[1] = a[3];
//         b[2] = a[4];
//         b[3] = -a[2];
//         b[4] = -a[1];
//         b[5] = a[5];
//         p1 = new pair(b[0], b[1]);
//         p2 = new pair(b[2], b[3]);
//         p3 = new pair(b[4], b[5]);
//         b1 = false;
//         b2 = false;
//         b3 = false;
//         if (samePair(q1, p1) || samePair(q1, p2) || samePair(q1, p3)) {
//             b1 = true;
//         }
//         if (samePair(q2, p1) || samePair(q2, p2) || samePair(q2, p3)) {
//             b2 = true;
//         }
//         if (samePair(q3, p1) || samePair(q3, p2) || samePair(q3, p3)) {
//             b3 = true;
//         }
//         if (b1 && b2 && b3 && (b[0] != b[5])) {
//             return true;
//         }
//
//         b[0] = a[0];
//         b[1] = -a[4];
//         b[2] = a[3];
//         b[3] = a[1];
//         b[4] = a[2];
//         b[5] = a[5];
//         p1 = new pair(b[0], b[1]);
//         p2 = new pair(b[2], b[3]);
//         p3 = new pair(b[4], b[5]);
//         b1 = false;
//         b2 = false;
//         b3 = false;
//         if (samePair(q1, p1) || samePair(q1, p2) || samePair(q1, p3)) {
//             b1 = true;
//         }
//         if (samePair(q2, p1) || samePair(q2, p2) || samePair(q2, p3)) {
//             b2 = true;
//         }
//         if (samePair(q3, p1) || samePair(q3, p2) || samePair(q3, p3)) {
//             b3 = true;
//         }
//         if (b1 && b2 && b3 && (b[0] != b[5])) {
//             return true;
//         }
         return B;
//         else {
//             return false;
//         }
     }

    //*************
     //in this method, test if in[]a and q1, q2, q3 form a transp.
     public boolean testInvertedTransp(int[] a, pair q1, pair q2, pair q3) {
         for (int i = 0; i < 6; i++) {
             int tmp = Math.abs(a[i]);
             for (int j = i + 1; j < 6; j++) {
                 int tmp2 = Math.abs(a[j]);
                 if (tmp2 == tmp) {
                     if (j != i + 1) {
                         return false;
                     } else {
                         if (a[j] != a[i]) {
                             return false;
                         }
                     }
                 }
             }
         }

         boolean B = false;
         int[] b = new int[6];
         //performs a forward inverted transp.
         b[0] = a[0];
         b[1] = a[3];
         b[2] = a[4];
         b[3] = -a[2];
         b[4] = -a[1];
         b[5] = a[5];
         pair p1 = new pair(b[0], b[1]);
         pair p2 = new pair(b[2], b[3]);
         pair p3 = new pair(b[4], b[5]);
         boolean b1 = false;
         boolean b2 = false;
         boolean b3 = false;
         if (samePair(q1, p1) || samePair(q1, p2) || samePair(q1, p3)) {
             b1 = true;
         }
         if (samePair(q2, p1) || samePair(q2, p2) || samePair(q2, p3)) {
             b2 = true;
         }
         if (samePair(q3, p1) || samePair(q3, p2) || samePair(q3, p3)) {
             b3 = true;
         }
         if (b1 && b2 && b3 && (b[0] != b[5])) {
             B = true;
             return B;
         } else {
             ;
         }

         //performs a backward inverted transp.
         b[0] = a[0];
         b[1] = -a[4];
         b[2] = -a[3];
         b[3] = a[1];
         b[4] = a[2];
         b[5] = a[5];
         p1 = new pair(b[0], b[1]);
         p2 = new pair(b[2], b[3]);
         p3 = new pair(b[4], b[5]);
         b1 = false;
         b2 = false;
         b3 = false;
         if (samePair(q1, p1) || samePair(q1, p2) || samePair(q1, p3)) {
             b1 = true;
         }
         if (samePair(q2, p1) || samePair(q2, p2) || samePair(q2, p3)) {
             b2 = true;
         }
         if (samePair(q3, p1) || samePair(q3, p2) || samePair(q3, p3)) {
             b3 = true;
         }
         if (b1 && b2 && b3 && (b[0] != b[5])) {
             B = true;
             return B;
         } else {
             ;
         }
         return B;
     }

    //****
     //if 1, 2 are used then return 0;
     int left(int i, int j) {
         for (int k = 0; k < 3; k++) {
             if ((i != k) && (j != k)) {
                 return k;
             }
         }
         return -1;
     }

    //*****************************
     void printArray(int[] a) {
         for (int i = 0; i < a.length; i++) {
             System.out.print(a[i] + ",");
         }
         System.out.println();
     }

    //if return1, then transp, if 2, then inverted trnasp, if 0, then not a transp or a inverted transp.
    //******
     int isTransp(pair p1, pair p2, pair p3, pair q1, pair q2, pair q3,
                  int[][] index) {

         Vector Sfrom;
         Vector Sto;
         if (this.from == this.nodeOne.nodeID) {
             Sfrom = this.setOne;
             Sto = this.setTwo;
         } else {
             Sfrom = this.setTwo;
             Sto = this.setOne;
         }

         boolean B = false;
         int s = 0;
         int k1 = p1.geneOne;
         int k2 = p1.geneTwo;
         int k3 = p2.geneOne;
         int k4 = p2.geneTwo;
         int k5 = p3.geneOne;
         int k6 = p3.geneTwo;

         int m1 = q1.geneOne;
         int m2 = q1.geneTwo;
         int m3 = q2.geneOne;
         int m4 = q2.geneTwo;
         int m5 = q3.geneOne;
         int m6 = q3.geneTwo;
         int[] t1 = {Math.abs(k1), Math.abs(k2), Math.abs(k3), Math.abs(k4),
                    Math.abs(k5), Math.abs(k6)};
         int[] t2 = {Math.abs(m1), Math.abs(m2), Math.abs(m3), Math.abs(m4),
                    Math.abs(m5), Math.abs(m6)};
         int[] a = new int[6];
         int[] b = {k1, k2, k3, k4, k5, k6};

         Arrays.sort(t1);
         Arrays.sort(t2);
         if (!Arrays.equals(t1, t2)) {
             return 0;
         } else {
             for (int i = 0; i < 2; i++) {
                 for (int j = 0; j < 2; j++) {
                     for (int k = 0; k < 2; k++) {
                         setArray(a, b, 0, i, 0);
                         setArray(a, b, 1, j, 1);
                         setArray(a, b, 2, k, 2);
                         B = testInvertedTransp(a, q1, q2, q3);

                         if (B &&
                             testInvertedPos(a, p1, p2, p3, q1, q2, q3, index,
                                     Sfrom,
                                     Sto)) {
                             s = 1;
                             return 1;
                         }

                         setArray(a, b, 0, i, 0);
                         setArray(a, b, 2, j, 1);
                         setArray(a, b, 1, k, 2);
                         B = testInvertedTransp(a, q1, q2, q3);

                         if (B &&
                             testInvertedPos(a, p1, p2, p3, q1, q2, q3, index,
                                     Sfrom,
                                     Sto)) {
                             s = 1;
                             return 1;
                         }

                         setArray(a, b, 1, i, 0);
                         setArray(a, b, 0, j, 1);
                         setArray(a, b, 2, k, 2);

                         B = testInvertedTransp(a, q1, q2, q3);

                         if (B &&
                             testInvertedPos(a, p1, p2, p3, q1, q2, q3, index,
                                     Sfrom,
                                     Sto)) {
                             s = 1;
                             return 1;
                         }

                     }
                 }
             }
         }
//     }
         return s;
     }

    //****************************
     boolean testPos(int[] a, pair p1, pair p2, pair p3, pair q1, pair q2,
                     pair q3, int[][] index, Vector Sfrom, Vector Sto) {
         boolean b = false;
         pair h1 = new pair(a[0], a[1]);
         pair h2 = new pair(a[2], a[3]);
         pair h3 = new pair(a[4], a[5]);
         pair t1 = new pair(a[0], a[3]);
         pair t2 = new pair(a[4], a[1]);
         pair t3 = new pair(a[2], a[5]);

         pair[] oriH = {p1, p2, p3};
         pair[] oriT = {q1, q2, q3};

         pair[] h = {h1, h2, h3};
         pair[] t = {t1, t2, t3};

         //realHead and realTail reflect the transp.
         pair[] realHead = new pair[3];
         pair[] realTail = new pair[3];

         for (int i = 0; i < oriH.length; i++) {
             pair tmpOri = oriH[i];
             for (int j = 0; j < h.length; j++) {
                 pair tmp = h[j];
                 if (samePair(tmpOri, tmp)) {
                     realHead[j] = tmpOri;
                     break;
                 }
             }
         }

         for (int i = 0; i < oriT.length; i++) {
             pair tmpOri = oriT[i];
             for (int j = 0; j < t.length; j++) {
                 pair tmp = t[j];
                 if (samePair(tmpOri, tmp)) {
                     realTail[j] = tmpOri;
                     break;
                 }
             }
         }

         /****
          *   c1 is the number of genomes that realHead[0] and realHead[1] are on the same chrom.
          * c_1 is the nb of genomes that realHead[0] and realHead[1] are on different chroms.
          * 1 2 3 4 5 6 -> 1 4 5 2 3 6. if it push 2 3 backward, then (1 2) and (2, 3) are on the same chrom.
          * if it pushes 4 5 forward, then (3 4) and (5, 6) are on the same chrom.
          * d1 is the nb of genomes that realHead[1] and realHead[2] are on the same chrom.
          * d_1 is the nb of genomes that realhead[1] and realHead[2] are not on the same chrom.
          ******/
         int c1 = 0;
         int c_1 = 0;

         int d1 = 0;
         int d_1 = 0;

         //check the pairs on same chrom.
         for (int k = 0; k < Sfrom.size(); k++) {
             int rk = ((Integer) (Sfrom.elementAt(k))).intValue();
             if ((index[rk][realHead[0].index] ==
                  index[rk][realHead[1].index]) &&
                 (index[rk][realHead[0].index] !=
                  -1)) {
                 c1++;
             }
             if ((index[rk][realHead[0].index] !=
                  index[rk][realHead[1].index]) &&
                 (index[rk][realHead[0].index] !=
                  -1) &&
                 (index[rk][realHead[1].index] !=
                  -1)) {
                 c_1++;
             }

             if ((index[rk][realHead[1].index] ==
                  index[rk][realHead[2].index]) &&
                 (index[rk][realHead[1].index] !=
                  -1)) {
                 d1++;
             }
             if ((index[rk][realHead[1].index] !=
                  index[rk][realHead[2].index]) &&
                 (index[rk][realHead[1].index] !=
                  -1) &&
                 (index[rk][realHead[2].index] !=
                  -1)) {
                 d_1++;
             }

         }

         int c2 = 0;
         int c_2 = 0;
         int d2 = 0;
         int d_2 = 0;
         for (int k = 0; k < Sto.size(); k++) {
             int rk = ((Integer) (Sto.elementAt(k))).intValue();
             if ((index[rk][realTail[1].index] ==
                  index[rk][realTail[2].index]) &&
                 (index[rk][realTail[1].index] !=
                  -1)) {
                 c2++;
             }
             if ((index[rk][realTail[1].index] !=
                  index[rk][realTail[2].index]) &&
                 (index[rk][realTail[1].index] !=
                  -1) &&
                 (index[rk][realTail[2].index] !=
                  -1)) {
                 c_2++;
             }

             if ((index[rk][realTail[0].index] ==
                  index[rk][realTail[1].index]) &&
                 (index[rk][realTail[0].index] !=
                  -1)) {
                 d2++;
             }
             if ((index[rk][realTail[0].index] !=
                  index[rk][realTail[1].index]) &&
                 (index[rk][realTail[0].index] !=
                  -1) &&
                 (index[rk][realTail[1].index] !=
                  -1)) {
                 d_2++;
             }

         }

         int totalFrom = c1 + c_1;
         int totalTo = c2 + c_2;
         int boundFrom;
         int boundTo;
         if (totalFrom % 2 == 0) {
             boundFrom = totalFrom / 2;
         } else {
             boundFrom = (totalFrom + 1) / 2;
         }

         if (totalTo % 2 == 0) {
             boundTo = totalTo / 2;
         } else {
             boundTo = (totalTo + 1) / 2;
         }

         if (c1 >= boundFrom && c2 >= boundTo) {
             b = true;
             return b;
         }

         int totalFrom2 = d1 + d_1;
         int totalTo2 = d2 + d_2;
         int boundFrom2;
         int boundTo2;
         if (totalFrom2 % 2 == 0) {
             boundFrom2 = totalFrom2 / 2;
         } else {
             boundFrom2 = (totalFrom2 + 1) / 2;
         }

         if (totalTo2 % 2 == 0) {
             boundTo2 = totalTo2 / 2;
         } else {
             boundTo2 = (totalTo2 + 1) / 2;
         }

         if (d1 >= boundFrom2 && d2 >= boundTo2) {
             b = true;
             return b;
         }

         return b;
     }

    //****************************
     public boolean testInvertedPos(int[] a, pair p1, pair p2, pair p3,
                                    pair q1,
                                    pair q2,
                                    pair q3, int[][] index, Vector Sfrom,
                                    Vector Sto) {
         boolean b = false;
         pair h1 = new pair(a[0], a[1]);
         pair h2 = new pair(a[2], a[3]);
         pair h3 = new pair(a[4], a[5]);

//scenario 1: 1 2 3 4 5 6 -> 1 4 5 -3 -2 6
         pair t1 = new pair(a[0], a[3]);
         pair t2 = new pair(a[4], -a[2]);
         pair t3 = new pair( -a[1], a[5]);

         pair[] oriH = {p1, p2, p3};
         pair[] oriT = {q1, q2, q3};

         pair[] h = {h1, h2, h3};
         pair[] t = {t1, t2, t3};

         //realHead and realTail reflect the transp.
         pair[] realHead = new pair[3];
         pair[] realTail = new pair[3];

         int count1 = 0;
         int count2 = 0;

         for (int i = 0; i < oriH.length; i++) {
             pair tmpOri = oriH[i];
             for (int j = 0; j < h.length; j++) {
                 pair tmp = h[j];
                 if (samePair(tmpOri, tmp)) {
                     realHead[j] = tmpOri;
                     count1++;
                     break;
                 }
             }
         }

         for (int i = 0; i < oriT.length; i++) {
             pair tmpOri = oriT[i];
             for (int j = 0; j < t.length; j++) {
                 pair tmp = t[j];
                 if (samePair(tmpOri, tmp)) {
                     realTail[j] = tmpOri;
                     count2++;
                     break;
                 }
             }
         }

         if (count1 == 3 && count2 == 3) {
             int c1 = 0;
             int c_1 = 0;

             //check the pairs on same chrom.
             for (int k = 0; k < Sfrom.size(); k++) {
                 int rk = ((Integer) (Sfrom.elementAt(k))).intValue();
                 if ((index[rk][realHead[0].index] ==
                      index[rk][realHead[1].index]) &&
                     (index[rk][realHead[0].index] !=
                      -1)) {
                     c1++;
                 }
                 if ((index[rk][realHead[0].index] !=
                      index[rk][realHead[1].index]) &&
                     (index[rk][realHead[0].index] !=
                      -1) &&
                     (index[rk][realHead[1].index] !=
                      -1)) {
                     c_1++;
                 }
             }

             int c2 = 0;
             int c_2 = 0;
             for (int k = 0; k < Sto.size(); k++) {
                 int rk = ((Integer) (Sto.elementAt(k))).intValue();
                 if ((index[rk][realTail[1].index] ==
                      index[rk][realTail[2].index]) &&
                     (index[rk][realTail[1].index] !=
                      -1)) {
                     c2++;
                 }
                 if ((index[rk][realTail[1].index] !=
                      index[rk][realTail[2].index]) &&
                     (index[rk][realTail[1].index] !=
                      -1) &&
                     (index[rk][realTail[2].index] !=
                      -1)) {
                     c_2++;
                 }
             }

             int totalFrom = c1 + c_1;
             int totalTo = c2 + c_2;
             int boundFrom;
             int boundTo;
             if (totalFrom % 2 == 0) {
                 boundFrom = totalFrom / 2;
             } else {
                 boundFrom = (totalFrom + 1) / 2;
             }

             if (totalTo % 2 == 0) {
                 boundTo = totalTo / 2;
             } else {
                 boundTo = (totalTo + 1) / 2;
             }

             if (c1 >= boundFrom && c2 >= boundTo) {
                 b = true;
                 return b;
             }
         }

//scenario 2:  1 2 3 4 5 6 -> 1 -5 -4 2 3 6
         count1 = 0;
         count2 = 0;

         t1 = new pair(a[0], -a[4]);
         t2 = new pair( -a[3], a[1]);
         t3 = new pair(a[2], a[5]);

         pair[] oriH2 = {p1, p2, p3};
         pair[] oriT2 = {q1, q2, q3};

         pair[] hh = {h1, h2, h3};
         pair[] tt = {t1, t2, t3};

         //realHead and realTail reflect the transp.
         realHead = new pair[3];
         realTail = new pair[3];

         for (int i = 0; i < oriH2.length; i++) {
             pair tmpOri = oriH2[i];
             for (int j = 0; j < hh.length; j++) {
                 pair tmp = hh[j];
                 if (samePair(tmpOri, tmp)) {
                     realHead[j] = tmpOri;
                     count1++;
                     break;
                 }
             }
         }

         for (int i = 0; i < oriT2.length; i++) {
             pair tmpOri = oriT2[i];
             for (int j = 0; j < tt.length; j++) {
                 pair tmp = tt[j];
                 if (samePair(tmpOri, tmp)) {
                     realTail[j] = tmpOri;
                     count2++;
                     break;
                 }
             }
         }

         if (count1 == 3 && count2 == 3) {
             int c1 = 0;
             int c_1 = 0;

             //check the pairs on same chrom.
             for (int k = 0; k < Sfrom.size(); k++) {
                 int rk = ((Integer) (Sfrom.elementAt(k))).intValue();
                 if ((index[rk][realHead[2].index] ==
                      index[rk][realHead[1].index]) &&
                     (index[rk][realHead[1].index] !=
                      -1)) {
                     c1++;
                 }
                 if ((index[rk][realHead[2].index] !=
                      index[rk][realHead[1].index]) &&
                     (index[rk][realHead[2].index] !=
                      -1) &&
                     (index[rk][realHead[1].index] !=
                      -1)) {
                     c_1++;
                 }
             }

             int c2 = 0;
             int c_2 = 0;
             for (int k = 0; k < Sto.size(); k++) {
                 int rk = ((Integer) (Sto.elementAt(k))).intValue();
                 if ((index[rk][realTail[1].index] ==
                      index[rk][realTail[0].index]) &&
                     (index[rk][realTail[0].index] !=
                      -1)) {
                     c2++;
                 }
                 if ((index[rk][realTail[1].index] !=
                      index[rk][realTail[0].index] &&
                      (index[rk][realTail[1].index] !=
                       -1) &&
                      (index[rk][realTail[0].index] !=
                       -1))) {
                     c_2++;
                 }
             }

             int totalFrom = c1 + c_1;
             int totalTo = c2 + c_2;
             int boundFrom;
             int boundTo;
             if (totalFrom % 2 == 0) {
                 boundFrom = totalFrom / 2;
             } else {
                 boundFrom = (totalFrom + 1) / 2;
             }

             if (totalTo % 2 == 0) {
                 boundTo = totalTo / 2;
             } else {
                 boundTo = (totalTo + 1) / 2;
             }

             if (c1 >= boundFrom && c2 >= boundTo) {
                 b = true;
                 return b;
             }
         }

         return b;
     }

//******************************
     boolean isTransp(pair p1, pair p2, pair p3, pair q1, pair q2, pair q3) {
         boolean B = false;
         int k1 = p1.geneOne;
         int k2 = p1.geneTwo;
         int k3 = p2.geneOne;
         int k4 = p2.geneTwo;
         int k5 = p3.geneOne;
         int k6 = p3.geneTwo;

         int m1 = q1.geneOne;
         int m2 = q1.geneTwo;
         int m3 = q2.geneOne;
         int m4 = q2.geneTwo;
         int m5 = q3.geneOne;
         int m6 = q3.geneTwo;

         int[] t1 = {Math.abs(k1), Math.abs(k2), Math.abs(k3), Math.abs(k4),
                    Math.abs(k5), Math.abs(k6)};
         int[] t2 = {Math.abs(m1), Math.abs(m2), Math.abs(m3), Math.abs(m4),
                    Math.abs(m5), Math.abs(m6)};
         int[] a = new int[6];
         int[] b = {k1, k2, k3, k4, k5, k6};
         Arrays.sort(t1);
         Arrays.sort(t2);
         if (!Arrays.equals(t1, t2)) {
             return B;
         } else {
             //return true;
             //*
              for (int i = 0; i < 2; i++) {
                  for (int j = 0; j < 2; j++) {
                      for (int k = 0; k < 2; k++) {

                          setArray(a, b, 0, i, 0);
                          setArray(a, b, 1, j, 1);
                          setArray(a, b, 2, k, 2);
                          B = testTransp(a, q1, q2, q3);
                          if (B) {
                              return B;
                          }

                          setArray(a, b, 0, i, 0);
                          setArray(a, b, 2, j, 1);
                          setArray(a, b, 1, k, 2);
                          B = testTransp(a, q1, q2, q3);
                          if (B) {
                              return B;
                          } else {
                              B = testInvertedTransp(a, q1, q2, q3);
                              if (B) {
                                  return B;
                              }
                          }

                          setArray(a, b, 1, i, 0);
                          setArray(a, b, 0, j, 1);
                          setArray(a, b, 2, k, 2);
                          B = testTransp(a, q1, q2, q3);
                          if (B) {
                              return B;
                          } else {
                              B = testInvertedTransp(a, q1, q2, q3);
                              if (B) {
                                  return B;
                              }
                          }

                      }
                  }
              } //*/
         }
         return B;
     }

//**************
     //to set a based on i and j, b is k1,k2,..,k6
     //set pair k to position i depending on j. j is the orientation of the pair.
     void setArray(int[] a, int[] b, int i, int j, int k) {
         if (k == 0) {
             if (i == 0) {
                 if (j == 0) {
                     a[0] = b[0];
                     a[1] = b[1];
                 } else if (j == 1) {
                     a[0] = -b[1];
                     a[1] = -b[0];
                 }
             } else if (i == 1) {
                 if (j == 0) {
                     a[2] = b[0];
                     a[3] = b[1];
                 } else if (j == 1) {
                     a[2] = -b[1];
                     a[3] = -b[0];
                 }
             } else if (i == 2) {
                 if (j == 0) {
                     a[4] = b[0];
                     a[5] = b[1];
                 } else if (j == 1) {
                     a[4] = -b[1];
                     a[5] = -b[0];
                 }
             }
         } else if (k == 1) {
             if (i == 0) {
                 if (j == 0) {
                     a[0] = b[2];
                     a[1] = b[3];
                 } else if (j == 1) {
                     a[0] = -b[3];
                     a[1] = -b[2];
                 }
             } else if (i == 1) {
                 if (j == 0) {
                     a[2] = b[2];
                     a[3] = b[3];
                 } else if (j == 1) {
                     a[2] = -b[3];
                     a[3] = -b[2];
                 }
             } else if (i == 2) {
                 if (j == 0) {
                     a[4] = b[2];
                     a[5] = b[3];
                 } else if (j == 1) {
                     a[4] = -b[3];
                     a[5] = -b[2];
                 }
             }
         } else if (k == 2) {
             if (i == 0) {
                 if (j == 0) {
                     a[0] = b[4];
                     a[1] = b[5];
                 } else if (j == 1) {
                     a[0] = -b[5];
                     a[1] = -b[4];
                 }
             } else if (i == 1) {
                 if (j == 0) {
                     a[2] = b[4];
                     a[3] = b[5];
                 } else if (j == 1) {
                     a[2] = -b[5];
                     a[3] = -b[4];
                 }
             } else if (i == 2) {
                 if (j == 0) {
                     a[4] = b[4];
                     a[5] = b[5];
                 } else if (j == 1) {
                     a[4] = -b[5];
                     a[5] = -b[4];
                 }
             }
         }
     }

    //**************************************
     void computeFinalFF(PrintWriter p, Vector genomes) {
         //Vfrom and Vto are the adjacencies at side "from" and "to" respectively.
         Vector Vfrom;
         Vector Vto;

         Vfrom = this.finalAdjOne;
         Vto = this.finalAdjTwo;

         if (this.from == this.nodeOne.nodeID) {
             Vfrom = this.finalAdjOne;
             Vto = this.finalAdjTwo;
         } else {
             Vfrom = this.finalAdjTwo;
             Vto = this.finalAdjOne;
         }

         Vector Sfrom;
         Vector Sto;

         Vector left = new Vector(); //at the "from" side
         Vector right = new Vector();

         Vector lt = new Vector();
         Vector rt = new Vector();

         if (this.from == this.nodeOne.nodeID) {
             Sfrom = this.setOne;
             Sto = this.setTwo;
             if (this.setOne.size() > 1) {
                 left = this.leftSub2;
                 right = this.rightSub2;
                 lt = this.leftSub1;
                 rt = this.rightSub1;
             }
         } else {
             Sfrom = this.setTwo;
             Sto = this.setOne;
             if (this.setTwo.size() > 1) {
                 left = this.leftSub1;
                 right = this.rightSub1;
                 lt = this.leftSub2;
                 rt = this.rightSub2;
             }
         }

         for (int i = 0; i < Vfrom.size(); i++) {
             pair P = (pair) (Vfrom.elementAt(i));
             if (P.geneOne != emrae.BIG && Math.abs(P.geneOne) != 0 &&
                 Math.abs(P.geneTwo) != 0) {
                 //total is the nb of genomes that has two boundary genes P.geneOne and P.geneTwo.
                 int total = 0;

                 for (int k = 0; k < Sto.size(); k++) {
                     int count = 0;
                     int m = ((Integer) (Sto.elementAt(k))).intValue();
                     Genome g = (Genome) (genomes.elementAt(m));

                     for (int j = 0; j < g.tail.length; j++) {
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneOne) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneOne)) {
                             count++;
                         }
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneTwo) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneTwo)) {
                             count++;
                         }
                     }

                     if (count >= 2 && matchBound(P, g)) {
                         total++;
                     }
                 }
                 //left and right branches.
                 int left_total = 0;
                 int right_total = 0;
                 for (int k = 0; k < left.size(); k++) {
                     int count = 0;
                     int m = ((Integer) (left.elementAt(k))).intValue();
                     Genome g = (Genome) (genomes.elementAt(m));

                     for (int j = 0; j < g.tail.length; j++) {
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneOne) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneOne)) {
                             count++;
                         }
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneTwo) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneTwo)) {
                             count++;
                         }
                     }

                     if (count >= 2 && matchBound(P, g)) {
                         left_total++;
                     }
                 }

                 for (int k = 0; k < right.size(); k++) {
                     int count = 0;
                     int m = ((Integer) (right.elementAt(k))).intValue();
                     Genome g = (Genome) (genomes.elementAt(m));

                     for (int j = 0; j < g.tail.length; j++) {
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneOne) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneOne)) {
                             count++;
                         }
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneTwo) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneTwo)) {
                             count++;
                         }
                     }

                     if (count >= 2 && matchBound(P, g)) {
                         right_total++;
                     }
                 }

                 //*               //2_versus_(m-1)
                  int s = 0;
                 if (Sto.size() % 2 == 0) {
                     s = Sto.size() / 2;
                 } else {
                     s = (Sto.size() + 1) / 2;
                 }

                 boolean left_right = false;
                 if (left.size() > 0 && right.size() > 0 && left_total > 0 &&
                     right_total > 0) {
                     left_right = true;
                 } else if (left.size() == 0 && right.size() == 0) {
                     left_right = true;
                 }
                 //if ((total >= Sto.size() - 1 && Sto.size() > 1) ||
                 //(total == 1 && Sto.size() == 1)) {
                 if (total >= s && left_right) {
                     p.println("A fission: (" + P.geneOne + "," +
                               P.geneTwo + ")");
                     pair temp = new pair(P.geneOne, P.geneTwo);
                     this.fis.addElement(temp);
                     P.geneOne = emrae.BIG;
                 }
             }
         }
//fusions
         for (int i = 0; i < Vto.size(); i++) {
             pair P = (pair) (Vto.elementAt(i));
             if (P.geneOne != emrae.BIG && Math.abs(P.geneOne) != 0 &&
                 Math.abs(P.geneTwo) != 0) {
                 int total = 0;
                 for (int k = 0; k < Sfrom.size(); k++) {
                     int count = 0;
                     int m = ((Integer) (Sfrom.elementAt(k))).intValue();
                     Genome g = (Genome) (genomes.elementAt(m));
                     for (int j = 0; j < g.tail.length; j++) {
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneOne) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneOne)) {
                             count++;
                         }
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneTwo) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneTwo)) {
                             count++;
                         }
                     }
                     if (count >= 2 && matchBound(P, g)) {
                         total++;
                     }
                 }
                 //left and right branches.
                 int left_total = 0;
                 int right_total = 0;
                 for (int k = 0; k < lt.size(); k++) {
                     int count = 0;
                     int m = ((Integer) (lt.elementAt(k))).intValue();
                     Genome g = (Genome) (genomes.elementAt(m));

                     for (int j = 0; j < g.tail.length; j++) {
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneOne) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneOne)) {
                             count++;
                         }
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneTwo) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneTwo)) {
                             count++;
                         }
                     }

                     if (count >= 2 && matchBound(P, g)) {
                         left_total++;
                     }
                 }

                 for (int k = 0; k < rt.size(); k++) {
                     int count = 0;
                     int m = ((Integer) (rt.elementAt(k))).intValue();
                     Genome g = (Genome) (genomes.elementAt(m));

                     for (int j = 0; j < g.tail.length; j++) {
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneOne) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneOne)) {
                             count++;
                         }
                         if (Math.abs(g.tail[j]) == Math.abs(P.geneTwo) ||
                             Math.abs(g.head[j]) == Math.abs(P.geneTwo)) {
                             count++;
                         }
                     }

                     if (count >= 2 && matchBound(P, g)) {
                         right_total++;
                     }
                 }

                 //*2-vs-(m-1)
                  int s = 0;
                 if (Sfrom.size() % 2 == 0) {
                     s = Sfrom.size() / 2;
                 } else {
                     s = (Sfrom.size() + 1) / 2;
                 }

                 boolean left_right = false;
                 if (lt.size() > 0 && rt.size() > 0 && left_total > 0 &&
                     right_total > 0) {
                     left_right = true;
                 } else if (lt.size() == 0 && rt.size() == 0) {
                     left_right = true;
                 }

                 //if ((total >= Sfrom.size() - 1 && Sfrom.size() > 1) ||
                 //(total == 1 && Sfrom.size() == 1)) {
                 if (total >= s && left_right) {

                     pair temp = new pair(P.geneOne, P.geneTwo);

                     boolean has_same_fusion_already = false;
                     for (int k = 0; k < this.fus.size(); k++) {
                         pair f = (pair) (this.fus.elementAt(k));
                         if (samePair(f, temp)) {
                             has_same_fusion_already = true;
                             break;
                         }
                     }
                     if (!has_same_fusion_already) {
                         this.fus.addElement(temp);
                         p.println("A fusion: (" + P.geneOne + "," +
                                   P.geneTwo + ")");
                         P.geneOne = emrae.BIG;
                     }
                 }
             }
         }
     }

    //************
     boolean matchBound(pair P, Genome G) {

         boolean B = false;

         int m1 = P.geneOne;
         int m2 = P.geneTwo;

         int ch1 = -1;
         int ch2 = -1;

         boolean head1 = false;
         boolean tail1 = false;
         boolean head2 = false;
         boolean tail2 = false;

         boolean sameSign1 = false;
         boolean sameSign2 = false;

         for (int i = 0; i < G.head.length; i++) {
             if (m1 == G.head[i]) {
                 head1 = true;
                 sameSign1 = true;
                 ch1 = i;
                 int[] Chrom1 = (int[]) (G.Chroms.elementAt(ch1));
                 if (Chrom1.length == 1) {
                     tail1 = true;
                 }
                 break;
             } else if (m1 == -G.head[i]) {
                 head1 = true;
                 ch1 = i;

                 int[] Chrom1 = (int[]) (G.Chroms.elementAt(ch1));
                 if (Chrom1.length == 1) {
                     tail1 = true;
                 }

                 break;
             } else if (m1 == G.tail[i]) {
                 tail1 = true;
                 sameSign1 = true;
                 ch1 = i;
             } else if (m1 == -G.tail[i]) {
                 tail1 = true;
                 ch1 = i;
                 break;
             }
         }

         for (int i = 0; i < G.head.length; i++) {
             if (m2 == G.head[i]) {
                 head2 = true;
                 sameSign2 = true;
                 ch2 = i;
                 int[] Chrom2 = (int[]) (G.Chroms.elementAt(ch2));
                 if (Chrom2.length == 1) {
                     tail2 = true;
                 }

                 break;
             } else if (m2 == -G.head[i]) {
                 head2 = true;
                 ch2 = i;
                 int[] Chrom2 = (int[]) (G.Chroms.elementAt(ch2));
                 if (Chrom2.length == 1) {
                     tail2 = true;
                 }

                 break;
             } else if (m2 == G.tail[i]) {
                 tail2 = true;
                 sameSign2 = true;
                 ch2 = i;
                 break;
             } else if (m2 == -G.tail[i]) {
                 tail2 = true;
                 ch2 = i;
                 break;
             }
         }

         if (ch1 == ch2 && ch1 != -1) {
             if (head1 && sameSign1 && tail2 && sameSign2) {
                 B = true;
                 return B;
             } else if (tail1 && !sameSign1 && head2 && !sameSign2) {
                 B = true;
                 return B;
             }
         } else if (ch1 != ch2 && ch1 != -1 && ch2 != -1) {
             if (head1 && head2 && !sameSign1 && sameSign2) {
                 B = true;
                 return B;
             } else if (head1 && tail2 && !sameSign1 && !sameSign2) {
                 B = true;
                 return B;
             } else if (tail1 && head2 && sameSign1 && sameSign2) {
                 B = true;
                 return B;
             } else if (tail1 && tail2 && sameSign1 && !sameSign2) {
                 B = true;
                 return B;
             } else if (head1 && tail1 && head2 && sameSign2 && !tail2) {
                 B = true;
                 return B;
             } else if (head1 && tail1 && tail2 && !sameSign2 && !head2) {
                 B = true;
                 return B;
             } else if (head2 && tail2 && head1 && !tail1 && !sameSign1) {
                 B = true;
                 return B;
             } else if (head2 && tail2 && tail1 && !head1 && sameSign1) {
                 B = true;
                 return B;
             } else if (head1 && tail1 && head2 && tail2) {
                 B = true;
                 return B;
             }
         }

         return B;

     }

//***********************************************
     void addToList(int n, Vector V) {
         boolean b = false;
         for (int i = 0; i < V.size(); i++) {
             int k = ((Integer) (V.elementAt(i))).intValue();
             if (Math.abs(n) == k) {
                 b = true;
             }
         }
         if (b == false) {
             V.addElement(new Integer(Math.abs(n)));
         }
     }

//**************************************
     boolean sameVector(Vector V1, Vector V2) {
         boolean b = false;
         int total = 0;
         if (V1.size() != V2.size()) {
             return b;
         } else {
             for (int i = 0; i < V1.size(); i++) {
                 int s1 = ((Integer) (V1.elementAt(i))).
                          intValue();
                 int counter = 0;
                 for (int j = 0; j < V2.size(); j++) {
                     int s2 = ((Integer) (V2.elementAt(j))).
                              intValue();
                     if (s1 == s2) {
                         counter++;
                     }
                 }
                 if (counter == 1) {
                     total++;
                 }
             }
             if (total == V1.size()) {
                 b = true;
             } else {
                 b = false;
             }
             return b;
         }
     }
}
