//package emrae;

import java.io.*;
import java.util.*;
import java.lang.*;

public class unrootedTree {
  String content;
  int commonScore;
  Vector nodeList;
  Vector edgeList;
  int score;

  double invs;
  double tlcs;
  double fis;
  double fus;

  double mgrInvs;
  double mgrTlcs;
  double mgrFis;
  double mgrFus;

  //cInvs means the common inversions shared by MGR and EMR
  Vector cInvs;
  Vector cTlcs;
  Vector cFis;
  Vector cFus;

  //the node nb in MGR newick tree;
  Vector mgrNodes;

  unrootedTree() {
    content = "";
    nodeList = new Vector();
    edgeList = new Vector();
    //twoCuts = new Vector();
    score = 0;
    mgrNodes = new Vector();

    cInvs = new Vector();
    cTlcs = new Vector();
    cFis = new Vector();
    cFus = new Vector();
  }

  //**********************************
   boolean samePair(pair p1, pair p2) {
     boolean same = false;
     if ( (p1.geneOne == p2.geneOne) && (p1.geneTwo == p2.geneTwo)) {
       same = true;
     }
     else if ( (p1.geneOne == - (p2.geneTwo)) &&
              (p1.geneTwo == - (p2.geneOne))) {
       same = true;
     }
     return same;
   }

  //*****************************************************************

//******************************

//********************************
     int numOf(String S, char c) {
       int a = 0;
       for (int i = 0; i < S.length(); i++) {
         if (S.charAt(i) == c) {
           a++;
         }
       }
       return a;
     }

//****************************************
   void getNodeID_MGR(String S) {
     if (S.length() > 3) {
       //System.out.println("now process:" + S);
       int totalBrackets = 0;
       int k = S.length() - 1;
       while (S.charAt(k) != ')') {
         k--;
       }
       int A = Integer.parseInt(S.substring(k + 1));

       for (int i = 0; i < S.length(); i++) {
         if (S.charAt(i) == '(') {
           totalBrackets++;
         }
       }
       if (totalBrackets > 1) {
         while ( ( (Integer) (this.mgrNodes.elementAt(A))).intValue() ==
                -1) {
           for (int i = 0; i < S.length(); i++) {
             if (S.charAt(i) == '(') { //b is the nb of "," in the interval (...)
               int b = 0;
               //s is the position of the first ")" right of "("
               int s = i + index(S.substring(i), ')');
               //end is the position of the first "," right of ")";
               int end = s + 1;
               while ( (S.charAt(end) != ',') &&
                      (S.charAt(end) != ')')) {
                 end++;
               }
               for (int j = i + 1; j < s; j++) {
                 if ( (S.charAt(j) == ',') ||
                     (S.charAt(j) == ')') ||
                     (S.charAt(j) == '(')) {
                   b++;
                 }
               }
               if (b == 1) {
                 //System.out.println("get:" + S.substring(i, end));
                 processUnit(S.substring(i, end));
                 String temp = "";
                 temp += S.substring(0, i);
                 temp += S.substring(s + 1);
                 //System.out.println("new seg:" + temp);
                 getNodeID_MGR(temp);
                 break;
               }
             }
           }
         }
       }
       else {
         processUnit(S);
       }
     }
   }

//****************************************
   //in this method, only process (a,b)A
   void processUnit(String S) {
     //System.out.println("Now process:" + S);
     int p = index(S, ',');
     int p2 = index(S, ')');
     //s1 is nodeID of one node.
     int s1 = Integer.parseInt(S.substring(1, p));
     //if s1 is an internal node, then real_s1 is its real value.
     int real_s1 = ( (Integer) (this.mgrNodes.elementAt(s1))).intValue();
     //System.out.println("s=" + s1 + ", real_s=" + real_s1);
     //s2 is the nodeID of the other node.
     int s2 = Integer.parseInt(S.substring(p + 1, p2));
     int real_s2 = ( (Integer) (this.mgrNodes.elementAt(s2))).intValue();
     //System.out.println("s=" + s2 + ", real_s=" + real_s2);
     //A is the nodeID of the ancestor of s1 and s2.
     int A = Integer.parseInt(S.substring(p2 + 1));

     //use e1 and e2 to find the common ancestor of real_s1 and real_s2.
     int e1 = -1;
     int e2 = -1;
     for (int i = 0; i < this.edgeList.size(); i++) {
       Edge e = (Edge) (this.edgeList.elementAt(i));
       if (e.nodeOne.nodeID == real_s1) {
         e1 = e.nodeTwo.nodeID;
         for (int j = 0; j < this.edgeList.size(); j++) {
           Edge ee = (Edge) (this.edgeList.elementAt(j));
           if (ee.nodeOne.nodeID == real_s2) {
             e2 = ee.nodeTwo.nodeID;
             if ( (e1 == e2) && (e1 != -1)) {
               this.mgrNodes.setElementAt(new Integer(e1), A);
               //this.mgrNodes.setElementAt(new Integer(A), e1);
               //System.out.println("A= " + A + ",realA= :" + e1);
               break;
             }
             else if (ee.nodeTwo.nodeID == real_s2) {
               e2 = ee.nodeOne.nodeID;
               if ( (e1 == e2) && (e1 != -1)) {
                 this.mgrNodes.setElementAt(new Integer(e1), A);
                 //this.mgrNodes.setElementAt(new Integer(A), e1);
                 //System.out.println("A = " + A + ", realA=" +
                 //e1);
               }
               break;
             }
           }
         }

       }
       else if (e.nodeTwo.nodeID == real_s1) {
         e1 = e.nodeOne.nodeID;
         for (int j = 0; j < this.edgeList.size(); j++) {
           Edge ee = (Edge) (this.edgeList.elementAt(j));
           if (ee.nodeOne.nodeID == real_s2) {
             e2 = ee.nodeTwo.nodeID;
             if ( (e1 == e2) && (e1 != -1)) {
               this.mgrNodes.setElementAt(new Integer(e1), A);
               //this.mgrNodes.setElementAt(new Integer(e1), A);
               //System.out.println("set " + e1 + " to :" + A);
               break;
             }
             else if (ee.nodeTwo.nodeID == real_s2) {
               e2 = ee.nodeOne.nodeID;
               if ( (e1 == e2) && (e1 != -1)) {
                 this.mgrNodes.setElementAt(new Integer(e1), A);
                 //System.out.println("A = " + A + ", realA=" +
                 //e1);
                 //System.out.println("set " + e1 + " to :" + A);
               }
               break;
             }
           }
         }
       }
     }
   }

//*******************************************
   void extractGenes(String tmp, String[] pmt) {
     int s = 0;
     int e = 0;
     int index = 0;
     while (e != tmp.length()) {
       while (tmp.charAt(s) == ' ') {
         s++;
       }

       while (tmp.charAt(e) != ' ') {
         if (e < tmp.length()) {
           e++;
         }
         if (e == tmp.length()) {
           break;
         }
       }

       pmt[index] = tmp.substring(s, e);
       index++;
       if (e < tmp.length()) {
         while (tmp.charAt(e) == ' ') {
           e++;
         }
         s = e;
       }
     }
   }

//****************************************
   //to give the first position of c in S
   int index(String S, char c) {
     int n = 0;
     while (S.charAt(n) != c) {
       n++;
     }
     return n;
   }

//*************************************************
   //to choose an edge, set it as internal or not, then add it into the list.
   void addAnEdge(Node A, Node B) {
     Edge e = new Edge();
     e.setNodeOne(A);
     e.setNodeTwo(B);
     e.setEdgeInternalOrNot();
     edgeList.add(e);
   }

//****************************************
   //print the pairs of adjOne or adjTwo
   void printSet(PrintWriter p, Vector V, int[][] index) {
     for (int j = 0; j < V.size(); j++) {
       pair P = (pair) (V.elementAt(j));
       p.print(P.geneOne + "," + P.geneTwo + ",");
       //index[0][P.index] + "," + index[1][P.index] + "," +
       //index[2][P.index] + "," + index[3][P.index] + "," +
       //index[4][P.index] + "," + index[5][P.index] + "," +
       //index[6][P.index] + ",");
       if ( ( (j + 1) % 6) == 0) {
         p.println();
       }
     }
     p.println();
   }

  //***********************
   void findEvents(PrintWriter p) {
     p.println("Find events:");
     for (int i = 0; i < this.edgeList.size(); i++) {
       Edge e = (Edge) (this.edgeList.elementAt(i));
       for (int j1 = 0; j1 < e.finalAdjOne.size(); j1++) {
         pair p1 = (pair) (e.finalAdjOne.elementAt(j1));
         for (int j2 = j1 + 1; j2 < e.finalAdjOne.size(); j2++) {
           pair p2 = (pair) (e.finalAdjOne.elementAt(j2));
           for (int j3 = j2 + 1; j3 < e.finalAdjOne.size(); j3++) {
             pair p3 = (pair) (e.finalAdjOne.elementAt(j3));
             for (int j4 = j3 + 1; j4 < e.finalAdjOne.size(); j4++) {
               pair p4 = (pair) (e.finalAdjOne.elementAt(j4));
               for (int k1 = 0; k1 < e.finalAdjTwo.size(); k1++) {
                 pair q1 = (pair) (e.finalAdjTwo.elementAt(
                     k1));
                 for (int k2 = k1 + 1;
                      k2 < e.finalAdjTwo.size(); k2++) {
                   pair q2 = (pair) (e.finalAdjTwo.
                                     elementAt(k2));
                   for (int k3 = k2 + 1;
                        k3 < e.finalAdjTwo.size(); k3++) {
                     pair q3 = (pair) (e.finalAdjTwo.
                                       elementAt(k3));
                     for (int k4 = k3 + 1;
                          k4 < e.finalAdjTwo.size();
                          k4++) {
                       pair q4 = (pair) (e.
                                         finalAdjTwo.elementAt(
                                             k4));
                       if (sameContent(p1, p2, p3, p4, q1,
                                       q2, q3, q4)) {
                         p.println("On edge " +
                                   e.nodeOne.nodeID +
                                   "->" +
                                   e.nodeTwo.nodeID);
                         p.println("(" + p1.geneOne +
                                   "," + p1.geneTwo +
                                   "),(" + p2.geneOne +
                                   "," + p2.geneTwo +
                                   "),("
                                   + p3.geneOne + "," +
                                   p3.geneTwo + "),(" +
                                   p4.geneOne + "," +
                                   p4.geneTwo + ")");
                       }

                     }

                   }

                 }
               }

             }

           }

         }

       }
     }

   }

//**************************************
   boolean sameContent(pair p1, pair p2, pair p3, pair p4, pair q1, pair q2,
                       pair q3, pair q4) {
     int[] a = new int[8];
     int[] b = new int[8];
     boolean B = false;
     a[0] = Math.abs(p1.geneOne);
     a[1] = Math.abs(p1.geneTwo);
     a[2] = Math.abs(p2.geneOne);
     a[3] = Math.abs(p2.geneTwo);
     a[4] = Math.abs(p3.geneOne);
     a[5] = Math.abs(p3.geneTwo);
     a[6] = Math.abs(p4.geneOne);
     a[7] = Math.abs(p4.geneTwo);
     b[0] = Math.abs(q1.geneOne);
     b[1] = Math.abs(q1.geneTwo);
     b[2] = Math.abs(q2.geneOne);
     b[3] = Math.abs(q2.geneTwo);
     b[4] = Math.abs(q3.geneOne);
     b[5] = Math.abs(q3.geneTwo);
     b[6] = Math.abs(q4.geneOne);
     b[7] = Math.abs(q4.geneTwo);

     Arrays.sort(a);
     Arrays.sort(b);
     if (Arrays.equals(a, b)) {
       B = true;
     }
     return B;
   }

//******************************************
   void getTotalScore(Vector pairList, int[][] matrix, PrintWriter p,
                      int[][] index, Vector genomes) {
     int edgeNum = edgeList.size();
     //print finalAdjs
     for (int i = 0; i < edgeNum; i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
            p.println("finalAdjOne:" + e.finalAdjOne.size());
            printSet(p, e.finalAdjOne, index);
            p.println("finalAdjTwo:" + e.finalAdjTwo.size());
            printSet(p, e.finalAdjTwo, index);
     }
     p.println("The detailed predictions:");
     p.println();
     for (int i = 0; i < edgeNum; i++) {
       Edge edge = (Edge) (edgeList.elementAt(i));
       p.println("Edge " + edge.nodeOne.nodeID + "->" +
                 edge.nodeTwo.nodeID +
                 ":");
       edge.effInferInvFinal(p, index, matrix, genomes);
       edge.effInferTranFinal(p, index, matrix);
       edge.computeFinalFF(p, genomes);
       int r = edge.invs.size();
       int t = edge.tlcs.size();
       int tr = edge.trans.size();
       int fi = edge.fis.size();
       int fu = edge.fus.size();
       int f =fi + fu;
       int total = r + t + tr + f;
       p.println("invs" + ":" + r + ", " +"tlcs" + ":" + t + ", " + "trans" + ":"
       + tr + ", " +"ff" + ":" + f + ", " +"total" + ":" + total);
       p.println();
     }

     int total = 0;
     int rev = 0;
     int tlc = 0;
     int tran = 0;
     int ff = 0;
     for (int i = 0; i < edgeNum; i++) {
       Edge edge = (Edge) (edgeList.elementAt(i));
       total += edge.invs.size() + edge.tlcs.size() + edge.trans.size() +
           edge.fis.size() + edge.fus.size();
       rev += edge.invs.size();
       tlc += edge.tlcs.size();
       tran += edge.trans.size();
       ff += edge.fis.size();
       ff += edge.fus.size();
     }
     System.out.println();
     System.out.println("EMRAE predicts " + total +
                        " rearrangement events including: ");
     System.out.println(rev + " reversals, " + tlc + " translocations, " +
                        tran + " transpositions , and " + ff +
                        " fusion/fissions.");

     System.out.println("\nPlease open the output file for details.");
   }

//**************************************************
//This method is to check if Math.abs(m) is identical with any element in V, if not, then add Math.abs(m) into V.
   void addToList(int n, Vector V) {
     boolean b = false;
     for (int i = 0; i < V.size(); i++) {
       int k = ( (Integer) (V.elementAt(i))).intValue();
       if (Math.abs(n) == k) {
         b = true;
       }
     }
     if (b == false) {
       V.addElement(new Integer(Math.abs(n)));
     }
   }

//**************************************
   void overlap(Vector V1, Vector V2, Vector common) {

     for (int i = 0; i < V1.size(); i++) {
       int k1 = ( (Integer) (V1.elementAt(i))).intValue();
       for (int j = 0; j < V2.size(); j++) {
         int k2 = ( (Integer) (V2.elementAt(j))).intValue();
         if (k1 == k2) {
           common.addElement(new Integer(k1));
           break;
         }
       }
     }
   }

//****************************************
   int overLap(Vector V1, Vector V2, Vector over) {
     int sum = 0;
     for (int i = 0; i < V1.size(); i++) {
       int k1 = ( (Integer) (V1.elementAt(i))).intValue();
       boolean b = false;
       for (int j = 0; j < V2.size(); j++) {
         int k2 = ( (Integer) (V2.elementAt(j))).intValue();
         if (k1 == k2) {
           b = true;
           over.addElement(new Integer(k1));
         }
       }
       if (b == true) {
         sum++;
       }
     }
     return sum;
   }

//******************************
   void getAdjForAllEdges(int[][] m, Vector pairList, PrintWriter p) {
     int size = edgeList.size();

     for (int i = 0; i < size; i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
       getAdjForEdges(m, e, pairList);
       getAdjForEdgesRelax(m, e, pairList);

     }
     processLeafEdges();
     refineRelax(p);
     refineLeafEdges(p);
 //    refineInternal(p);
 //    refineLeaf(p);

   }

//*******************************
   boolean equalPairs(pair p1, pair p2) {
     boolean b = false;
     int s1 = Math.abs(p1.geneOne);
     int s2 = Math.abs(p1.geneTwo);
     int k1 = Math.abs(p2.geneOne);
     int k2 = Math.abs(p2.geneTwo);
     if ( (s1 == k1) && (s2 == k2)) {
       b = true;
     }
     if ( (s1 == k2) && (s2 == k1)) {
       b = true;
     }
     return b;
   }

//*********************
   void refineLeafEdgesOriginal(PrintWriter pw) {
     for (int i = 0; i < edgeList.size(); i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
       if (e.isInternalEdge == false) {
         Node N1 = e.nodeOne;
         Node N2 = e.nodeTwo;
         int n1 = N1.nodeID;
         int n2 = N2.nodeID;

         Vector V1 = new Vector();
         Vector V_1 = new Vector();
         Vector V2 = new Vector();
         Vector V_2 = new Vector();
         Vector rV1 = new Vector();
         Vector rV2 = new Vector();
         int neib1 = -1;
         int neib2 = -1;

         if (n1 > n2) { //n2 is a leaf
           //System.out.println(n2 + " is the leaf");
           if (N1.firstNeib == n2) {
             neib1 = N1.secondNeib;
             neib2 = N1.lastNeib;
           }
           if (N1.secondNeib == n2) {
             neib1 = N1.firstNeib;
             neib2 = N1.lastNeib;
           }
           if (N1.lastNeib == n2) {
             neib1 = N1.firstNeib;
             neib2 = N1.secondNeib;
           }
           Edge e1 = getEdge(n1, neib1);

           //if v1 is setone then v_1 is settwo; if v1 is settwo, then v_1 is setone;
           //process e1;
           if (e1.nodeOne.nodeID == n1) {
             V1 = e1.relaxAdjTwo;
             V_1 = e1.relaxAdjOne;
             //rV1 = e1.realFinalAdjTwo;
           }
           else if (e1.nodeTwo.nodeID == n1) {
             V1 = e1.relaxAdjOne;
             V_1 = e1.relaxAdjTwo;
             //rV1 = e1.realFinalAdjOne;
           }

           //process e2
           Edge e2 = getEdge(n1, neib2);
           if (e2.nodeOne.nodeID == n1) {
             V2 = e2.relaxAdjTwo;
             V_2 = e2.relaxAdjOne;
             //rV2 = e2.realFinalAdjTwo;
           }
           else if (e2.nodeTwo.nodeID == n1) {
             V2 = e2.relaxAdjOne;
             V_2 = e2.relaxAdjTwo;
             //rV2 = e2.realFinalAdjOne;
           }
           //put overlap genes from e1 into e.relaxAdjOne;
           for (int j = 0; j < V1.size(); j++) {
             pair p1 = (pair) (V1.elementAt(j));
             //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
             boolean B1 = false;
             for (int j2 = 0; j2 < V_1.size(); j2++) {
               pair q = (pair) (V_1.elementAt(j2));
               if (overlap(q, p1) == true) {
                 B1 = true;
               }
             }
             if (B1 == false) {
               for (int k = 0; k < V2.size(); k++) {
                 boolean B2 = false;
                 pair p2 = (pair) (V2.elementAt(k));
                 if (overlap(p1, p2) == true) {
                   for (int k2 = 0; k2 < V_2.size(); k2++) {
                     pair q = (pair) (V_2.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }
                   if (B2 == true) {
                     pair temp = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                     e.finalAdjOne.addElement(temp);
                     pair temp2 = new pair(p1.geneOne,
                                           p1.geneTwo, p1.index);
                     e.rAdjOne.addElement(temp2);

                     break;
                   }
                 }
               }
             }
           }
           //put overlap genes from e2 into finalAdjOne;
           for (int j = 0; j < V2.size(); j++) {
             pair p1 = (pair) (V2.elementAt(j));
             //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
             boolean B1 = false;
             for (int j2 = 0; j2 < V_2.size(); j2++) {
               pair q = (pair) (V_2.elementAt(j2));
               if (overlap(q, p1) == true) {
                 B1 = true;
               }
             }
             if (B1 == false) {
               for (int k = 0; k < V1.size(); k++) {
                 boolean B2 = false;
                 pair p2 = (pair) (V1.elementAt(k));
                 if (overlap(p1, p2) == true) {
                   for (int k2 = 0; k2 < V_1.size(); k2++) {
                     pair q = (pair) (V_1.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }
                   if (B2 == true) {
                     pair temp = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                     e.finalAdjOne.addElement(temp);
                     pair temp2 = new pair(p1.geneOne,
                                           p1.geneTwo, p1.index);
                     e.rAdjOne.addElement(temp2);

                     break;
                   }
                 }
               }
             }
           }
         }
         else { //if (n1 < n2) that is, n1 is a leaf
           //System.out.println(n1 + " is the leaf.");
           //now process part two.
           if (N2.firstNeib == n1) {
             neib1 = N2.secondNeib;
             neib2 = N2.lastNeib;
           }
           if (N2.secondNeib == n1) {
             neib1 = N2.firstNeib;
             neib2 = N2.lastNeib;
           }
           if (N2.lastNeib == n1) {
             neib1 = N2.firstNeib;
             neib2 = N2.secondNeib;
           }
           Edge e1 = getEdge(n2, neib1);

           if (e1.nodeOne.nodeID == n2) {
             V1 = e1.relaxAdjTwo;
             V_1 = e1.relaxAdjOne;
             //rV1 = e1.realFinalAdjTwo;
           }
           else if (e1.nodeTwo.nodeID == n2) {
             V1 = e1.relaxAdjOne;
             V_1 = e1.relaxAdjTwo;
             //rV1 = e1.realFinalAdjOne;
           }
           //process e2
           Edge e2 = getEdge(n2, neib2);
           if (e2.nodeOne.nodeID == n2) {
             V2 = e2.relaxAdjTwo;
             V_2 = e2.relaxAdjOne;
             //rV2 = e2.realFinalAdjTwo;
           }
           else if (e2.nodeTwo.nodeID == n2) {
             V2 = e2.relaxAdjOne;
             V_2 = e2.relaxAdjTwo;
             //rV2 = e2.realFinalAdjOne;
           }
           //put overlap genes from e1 into finalAdjTwo;
           for (int j = 0; j < V1.size(); j++) {
             pair p1 = (pair) (V1.elementAt(j));
             boolean B1 = false;
             for (int j2 = 0; j2 < V_1.size(); j2++) {
               pair q = (pair) (V_1.elementAt(j2));
               if (overlap(q, p1) == true) {
                 B1 = true;
               }
             }

             if (B1 == false) {
               for (int k = 0; k < V2.size(); k++) {
                 boolean B2 = false;
                 pair p2 = (pair) (V2.elementAt(k));
                 if (overlap(p1, p2) == true) {
                   for (int k2 = 0; k2 < V_2.size(); k2++) {
                     pair q = (pair) (V_2.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }
                   if (B2 == true) {
                     pair temp = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                     e.finalAdjTwo.addElement(temp);
                     pair temp2 = new pair(p1.geneOne,
                                           p1.geneTwo, p1.index);
                     e.rAdjTwo.addElement(temp2);

                     break;
                   }
                 }
               }
             }
           }
           //put overlap genes from e2 into finalAdjTwo;
           for (int j = 0; j < V2.size(); j++) {
             pair p1 = (pair) (V2.elementAt(j));
             boolean B1 = false;
             for (int j2 = 0; j2 < V_2.size(); j2++) {
               pair q = (pair) (V_2.elementAt(j2));
               if (overlap(q, p1) == true) {
                 B1 = true;
               }
             }
             if (B1 == false) {
               for (int k = 0; k < V1.size(); k++) {
                 boolean B2 = false;
                 pair p2 = (pair) (V1.elementAt(k));
                 if (overlap(p1, p2) == true) {
                   for (int k2 = 0; k2 < V_1.size(); k2++) {
                     pair q = (pair) (V_1.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }
                   if (B2 == true) {
                     pair temp = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                     e.finalAdjTwo.addElement(temp);
                     pair temp2 = new pair(p1.geneOne,
                                           p1.geneTwo, p1.index);
                     e.rAdjTwo.addElement(temp2);

                     break;
                   }
                 }
               }
             }
           }
         }
       }
     }
   }

  void refineLeafEdges(PrintWriter pw) {
    for (int i = 0; i < edgeList.size(); i++) {
      Edge e = (Edge) (edgeList.elementAt(i));
      if (e.isInternalEdge == false) {
        Node N1 = e.nodeOne;
        Node N2 = e.nodeTwo;
        int n1 = N1.nodeID;
        int n2 = N2.nodeID;

        Vector V1 = new Vector();
        Vector V_1 = new Vector();
        Vector V2 = new Vector();
        Vector V_2 = new Vector();
        Vector rV1 = new Vector();
        Vector rV2 = new Vector();

        int neib1 = -1;
        int neib2 = -1;

        if (n1 > n2) { //n2 is a leaf
          //System.out.println(n2 + " is the leaf");
          if (N1.firstNeib == n2) {
            neib1 = N1.secondNeib;
            neib2 = N1.lastNeib;
          }
          if (N1.secondNeib == n2) {
            neib1 = N1.firstNeib;
            neib2 = N1.lastNeib;
          }
          if (N1.lastNeib == n2) {
            neib1 = N1.firstNeib;
            neib2 = N1.secondNeib;
          }
          Edge e1 = getEdge(n1, neib1);

          //if v1 is setone then v_1 is settwo; if v1 is settwo, then v_1 is setone;
          //process e1;
          if (e1.nodeOne.nodeID == n1) {
            V1 = e1.relaxAdjTwo;
            V_1 = e1.relaxAdjOne;
            rV1 = e1.rAdjTwo;
          }
          else if (e1.nodeTwo.nodeID == n1) {
            V1 = e1.relaxAdjOne;
            V_1 = e1.relaxAdjTwo;
            rV1 = e1.rAdjOne;
          }

          //process e2
          Edge e2 = getEdge(n1, neib2);
          if (e2.nodeOne.nodeID == n1) {
            V2 = e2.relaxAdjTwo;
            V_2 = e2.relaxAdjOne;
            rV2 = e2.rAdjTwo;
          }
          else if (e2.nodeTwo.nodeID == n1) {
            V2 = e2.relaxAdjOne;
            V_2 = e2.relaxAdjTwo;
            rV2 = e2.rAdjOne;
          }
          //put overlap genes from e1 into e.relaxAdjOne;
          for (int j = 0; j < V1.size(); j++) {
            pair p1 = (pair) (V1.elementAt(j));
            //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
            boolean B1 = false;
            for (int j2 = 0; j2 < V_1.size(); j2++) {
              pair q = (pair) (V_1.elementAt(j2));
              if (overlap(q, p1) == true) {
                B1 = true;
              }
            }
            if (B1 == false) {
              for (int k = 0; k < V2.size(); k++) {
                boolean B2 = false;
                pair p2 = (pair) (V2.elementAt(k));
                if (overlap(p1, p2) == true) {
                  ///*
                   //original refinement
                   for (int k2 = 0; k2 < V_2.size(); k2++) {
                     pair q = (pair) (V_2.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }

                  if (B2 == true) {
                    pair temp = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                    e.finalAdjOne.addElement(temp);
                    //System.out.println("("+p1.geneOne+","+p1.geneTwo+") added to e.one." );
                    pair temp2 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                    e.rAdjOne.addElement(temp2);

                    pair temp4 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);

                    if (e2.nodeOne.nodeID == n1) {
                      e2.finalAdjOne.addElement(temp4);
                    }
                    else {
                      e2.finalAdjTwo.addElement(temp4);
                    }

                    pair p = (pair) (rV1.elementAt(j));
                    p.geneOne = 10000;
                    break;
                  }
                }
              }
            }
          }
          //put overlap genes from e2 into finalAdjOne;
          for (int j = 0; j < V2.size(); j++) {
            pair p1 = (pair) (V2.elementAt(j));
            //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
            boolean B1 = false;
            for (int j2 = 0; j2 < V_2.size(); j2++) {
              pair q = (pair) (V_2.elementAt(j2));
              if (overlap(q, p1) == true) {
                B1 = true;
              }
            }
            if (B1 == false) {
              for (int k = 0; k < V1.size(); k++) {
                boolean B2 = false;
                pair p2 = (pair) (V1.elementAt(k));
                if (overlap(p1, p2) == true) {
                  //*
                   //original refinement
                   for (int k2 = 0; k2 < V_1.size(); k2++) {
                     pair q = (pair) (V_1.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }

                  if (B2 == true) {
                    pair temp = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                    e.finalAdjOne.addElement(temp);
                    //System.out.println("("+p1.geneOne+","+p1.geneTwo+") added to e.one." );
                    pair temp2 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                    e.rAdjOne.addElement(temp2);
                    pair temp4 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);

                    if (e1.nodeOne.nodeID == n1) {
                      e1.finalAdjOne.addElement(temp4);
                    }
                    else {
                      e1.finalAdjTwo.addElement(temp4);
                    }

                    //remove the pair by labeling its geneOne as 10000;
                    pair p = (pair) (rV2.elementAt(j));
                    p.geneOne = 10000;

                    break;
                  }
                }
              }
            }
          }
        }
        else { //if (n1 < n2) that is, n1 is a leaf
          //now process part two.
          if (N2.firstNeib == n1) {
            neib1 = N2.secondNeib;
            neib2 = N2.lastNeib;
          }
          if (N2.secondNeib == n1) {
            neib1 = N2.firstNeib;
            neib2 = N2.lastNeib;
          }
          if (N2.lastNeib == n1) {
            neib1 = N2.firstNeib;
            neib2 = N2.secondNeib;
          }
          Edge e1 = getEdge(n2, neib1);

          if (e1.nodeOne.nodeID == n2) {
            V1 = e1.relaxAdjTwo;
            V_1 = e1.relaxAdjOne;
            rV1 = e1.rAdjTwo;
          }
          else if (e1.nodeTwo.nodeID == n2) {
            V1 = e1.relaxAdjOne;
            V_1 = e1.relaxAdjTwo;
            rV1 = e1.rAdjOne;
          }
          //process e2
          Edge e2 = getEdge(n2, neib2);
          if (e2.nodeOne.nodeID == n2) {
            V2 = e2.relaxAdjTwo;
            V_2 = e2.relaxAdjOne;
            rV2 = e2.rAdjTwo;
          }
          else if (e2.nodeTwo.nodeID == n2) {
            V2 = e2.relaxAdjOne;
            V_2 = e2.relaxAdjTwo;
            rV2 = e2.rAdjOne;
          }
          //put overlap genes from e1 into finalAdjTwo;
          for (int j = 0; j < V1.size(); j++) {
            pair p1 = (pair) (V1.elementAt(j));
            boolean B1 = false;
            for (int j2 = 0; j2 < V_1.size(); j2++) {
              pair q = (pair) (V_1.elementAt(j2));
              if (overlap(q, p1) == true) {
                B1 = true;
              }
            }

            if (B1 == false) {
              for (int k = 0; k < V2.size(); k++) {
                boolean B2 = false;
                pair p2 = (pair) (V2.elementAt(k));
                if (overlap(p1, p2) == true) {

                  // /*
                   //original refinement
                   for (int k2 = 0; k2 < V_2.size(); k2++) {
                     pair q = (pair) (V_2.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }

                  if (B2 == true) {
                    pair temp = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                    e.finalAdjTwo.addElement(temp);
                    //System.out.println("("+p1.geneOne+","+p1.geneTwo+") added to e.two." );

                    pair temp2 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                    e.rAdjTwo.addElement(temp2);

                    pair temp4 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);

                    if (e2.nodeOne.nodeID == n2) {
                      e2.finalAdjOne.addElement(temp4);
                    }
                    else {
                      e2.finalAdjTwo.addElement(temp4);
                    }

                    //remove p1 from rV1
                    pair p = (pair) (rV1.elementAt(j));
                    p.geneOne = 10000;
                    break;
                  }
                }
              }
            }
          }
          //put overlap genes from e2 into finalAdjTwo;
          for (int j = 0; j < V2.size(); j++) {
            pair p1 = (pair) (V2.elementAt(j));
            boolean B1 = false;
            for (int j2 = 0; j2 < V_2.size(); j2++) {
              pair q = (pair) (V_2.elementAt(j2));
              if (overlap(q, p1) == true) {
                B1 = true;
              }
            }
            if (B1 == false) {
              for (int k = 0; k < V1.size(); k++) {
                boolean B2 = false;
                pair p2 = (pair) (V1.elementAt(k));
                if (overlap(p1, p2) == true) {
                  //*
                   //original refinement
                   for (int k2 = 0; k2 < V_1.size(); k2++) {
                     pair q = (pair) (V_1.elementAt(k2));
                     if (overlap(q, p2) == true) {
                       B2 = true;
                     }
                   }

                  if (B2 == true) {
                    pair temp = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                    e.finalAdjTwo.addElement(temp);
                    //System.out.println("("+p1.geneOne+","+p1.geneTwo+") added to e.two." );

                    pair temp2 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);
                    e.rAdjTwo.addElement(temp2);

                    pair temp4 = new pair(p1.geneOne,
                                          p1.geneTwo, p1.index);

                    if (e1.nodeOne.nodeID == n2) {
                      e1.finalAdjOne.addElement(temp4);
                    }
                    else {
                      e1.finalAdjTwo.addElement(temp4);
                    }

                    //remove p1 from rV2
                    pair p = (pair) (rV2.elementAt(j));
                    p.geneOne = 10000;

                    break;
                  }
                }
              }
            }
          }
        }
      }
    }
  }

//***************************************
//this method aims to get rid of the repeated pairs in finalAdjs
   void cleanVector(Vector V) {
     for (int i = 0; i < V.size() - 1; i++) {
       pair p = (pair) (V.elementAt(i));
       for (int j = i + 1; j < V.size(); j++) {
         pair temp = (pair) (V.elementAt(j));
         if ( (isSamePair(temp, p) == true) && (p.geneOne != 9999)) {
           temp.geneOne = 9999;
           temp.geneTwo = 9999;
         }
       }
     }
     int s = 0;
     while (s != V.size()) {
       pair p = (pair) (V.elementAt(s));
       if (p.geneOne == 9999) {
         V.removeElementAt(s);
       }
       else {
         s++;
       }
     }
   }

 //***************************************
   //refine the internal edges.
   void refineInternal(PrintWriter pw) {
     //pw.println("Refine internal edges:");
     for (int i = 0; i < edgeList.size(); i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
       if (e.isInternalEdge == true) {

         //pw.println("internal");
         Node N1 = e.nodeOne;
         Node N2 = e.nodeTwo;
         int n1 = N1.nodeID;
         int n2 = N2.nodeID;
         //System.out.println("processing " + n1 + "-->" + n2);
         int neib1 = -1;
         int neib2 = -1;
         if (N1.firstNeib == n2) {
           neib1 = N1.secondNeib;
           neib2 = N1.lastNeib;
         }
         if (N1.secondNeib == n2) {
           neib1 = N1.firstNeib;
           neib2 = N1.lastNeib;
         }
         if (N1.lastNeib == n2) {
           neib1 = N1.firstNeib;
           neib2 = N1.secondNeib;
         }
         //System.out.println(neib1+","+neib2);
         Edge e1 = getEdge(n1, neib1);

         //if v1 is setone then v_1 is settwo; if v1 is settwo, then v_1 is setone;
         Vector V1 = new Vector();
         Vector V_1 = new Vector();
         Vector V2 = new Vector();
         Vector V_2 = new Vector();
         Vector rV1 = new Vector();
         Vector rV2 = new Vector();
		 Vector S1 = new Vector();
		 Vector S2 = new Vector();

         //process e1;
         if (e1.nodeOne.nodeID == n1) {
           V1 = e1.relaxAdjTwo;
           V_1 = e1.relaxAdjOne;
           rV1 = e1.rAdjTwo;
         }
         else if (e1.nodeTwo.nodeID == n1) {
           V1 = e1.relaxAdjOne;
           V_1 = e1.relaxAdjTwo;
           rV1 = e1.rAdjOne;
         }

         //process e2
         Edge e2 = getEdge(n1, neib2);
         if (e2.nodeOne.nodeID == n1) {
           V2 = e2.relaxAdjTwo;
           V_2 = e2.relaxAdjOne;
           rV2 = e2.rAdjTwo;
         }
         else if (e2.nodeTwo.nodeID == n1) {
           V2 = e2.relaxAdjOne;
           V_2 = e2.relaxAdjTwo;
           rV2 = e2.rAdjOne;
         }
         //put good pairs from e1 into finalAdjOne;
         for (int j = 0; j < V1.size(); j++) {
           pair p1 = (pair) (V1.elementAt(j));
           //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
           for (int k = 0; k < V2.size(); k++) {
			   pair p2 = (pair) (V2.elementAt(k));
             if (overlap(p1, p2) == true) {
                 pair temp = new pair(p1.geneOne, p1.geneTwo, p1.index);
				 S1.addElement(temp);
                 e.finalAdjOne.addElement(temp);
                 pair temp2 = new pair(p2.geneOne, p2.geneTwo, p2.index);
				 S1.addElement(temp2);
                 e.finalAdjOne.addElement(temp2);
             }
           }
         }

        /*         if (e1.nodeOne.nodeID == n1) {
                	 for(i = 0; i < S1.size(); i++) {
                         e1.finalAdjTwo.addElement(S1.elementAt(i));
                       }
                    }
                     else {
                    	 for(i = 0; i < S1.size(); i++) {
                             e1.finalAdjOne.addElement(S1.elementAt(i));
                           }
                        }
                     if (e2.nodeOne.nodeID == n1) {
                    	 for(i = 0; i < S1.size(); i++) {
                             e2.finalAdjTwo.addElement(S1.elementAt(i));
                           }
                     }
                     else {
                    	 for(i = 0; i < S1.size(); i++) {
                             e2.finalAdjOne.addElement(S1.elementAt(i));
                           }
                     }
            //       e.rAdjOne.addElement(temp);
                   //remove p1 from rV1
            //       pair p = (pair) (rV1.elementAt(j));
            //       p.geneOne = 10000;

            //       break;*/

         //now process part two.
         if (N2.firstNeib == n1) {
           neib1 = N2.secondNeib;
           neib2 = N2.lastNeib;
         }
         if (N2.secondNeib == n1) {
           neib1 = N2.firstNeib;
           neib2 = N2.lastNeib;
         }
         if (N2.lastNeib == n1) {
           neib1 = N2.firstNeib;
           neib2 = N2.secondNeib;
         }
         e1 = getEdge(n2, neib1);

         if (e1.nodeOne.nodeID == n2) {
           V1 = e1.relaxAdjTwo;
           V_1 = e1.relaxAdjOne;
           rV1 = e1.rAdjTwo;
         }
         else if (e1.nodeTwo.nodeID == n2) {
           V1 = e1.relaxAdjOne;
           V_1 = e1.relaxAdjTwo;
           rV1 = e1.rAdjOne;
         }
         //process e2
         e2 = getEdge(n2, neib2);
         if (e2.nodeOne.nodeID == n2) {
           V2 = e2.relaxAdjTwo;
           V_2 = e2.relaxAdjOne;
           rV2 = e2.rAdjTwo;
         }
         else if (e2.nodeTwo.nodeID == n2) {
           V2 = e2.relaxAdjOne;
           V_2 = e2.relaxAdjTwo;
           rV2 = e2.rAdjOne;
         }

         //put overlap genes from e1 into finalAdjTwo;
         for (int j = 0; j < V1.size(); j++) {
           pair p1 = (pair) (V1.elementAt(j));
             for (int k = 0; k < V2.size(); k++) {
               pair p2 = (pair) (V2.elementAt(k));
               if (overlap(p1, p2) == true) {
                   pair temp = new pair(p1.geneOne, p1.geneTwo, p1.index);
				   S2.addElement(temp);
                   e.finalAdjTwo.addElement(temp);
                   pair temp2 = new pair(p2.geneOne, p2.geneTwo, p2.index);
				   S2.addElement(temp2);
				   e.finalAdjTwo.addElement(temp2);	
               }
             }
           }

          /*        if (e1.nodeOne.nodeID == n2) {
                	  for(i = 0; i < S2.size(); i++) {
                      e1.finalAdjTwo.addElement(S2.elementAt(i));
                    }
                  }
                   else {
                	   for(i = 0; i < S2.size(); i++) {
                           e1.finalAdjOne.addElement(S2.elementAt(i));
                         }
                   }
                   if (e2.nodeOne.nodeID == n2) {
                	   for(i = 0; i < S2.size(); i++) {
                           e1.finalAdjTwo.addElement(S2.elementAt(i));
                         }
                     }
                    else {
                    	for(i = 0; i < S2.size(); i++) {
                            e1.finalAdjOne.addElement(S2.elementAt(i));
                          }
                    }
			//	   e.rAdjTwo.addElement(temp);
                   //remove p1 from rV1
             //      pair p = (pair) (rV1.elementAt(j));
            //       p.geneOne = 10000;

           //        break;*/
          }
       }
    }  
 //***************************************  
   void refineLeaf(PrintWriter pw) {
	    for (int i = 0; i < edgeList.size(); i++) {
	      Edge e = (Edge) (edgeList.elementAt(i));
	      if (e.isInternalEdge == false) {
	        Node N1 = e.nodeOne;
	        Node N2 = e.nodeTwo;
	        int n1 = N1.nodeID;
	        int n2 = N2.nodeID;

	        Vector V1 = new Vector();
	        Vector V_1 = new Vector();
	        Vector V2 = new Vector();
	        Vector V_2 = new Vector();
	        Vector rV1 = new Vector();
	        Vector rV2 = new Vector();
	        Vector S1 = new Vector();
	        Vector S2 = new Vector();

	        int neib1 = -1;
	        int neib2 = -1;

	        if (n1 > n2) { //n2 is a leaf
	          //System.out.println(n2 + " is the leaf");
	          if (N1.firstNeib == n2) {
	            neib1 = N1.secondNeib;
	            neib2 = N1.lastNeib;
	          }
	          if (N1.secondNeib == n2) {
	            neib1 = N1.firstNeib;
	            neib2 = N1.lastNeib;
	          }
	          if (N1.lastNeib == n2) {
	            neib1 = N1.firstNeib;
	            neib2 = N1.secondNeib;
	          }
	          Edge e1 = getEdge(n1, neib1);

	          //if v1 is setone then v_1 is settwo; if v1 is settwo, then v_1 is setone;
	          //process e1;
	          if (e1.nodeOne.nodeID == n1) {
	            V1 = e1.finalAdjTwo;
	            V_1 = e1.finalAdjOne;
	            rV1 = e1.rAdjTwo;
	          }
	          else if (e1.nodeTwo.nodeID == n1) {
	            V1 = e1.finalAdjOne;
	            V_1 = e1.finalAdjTwo;
	            rV1 = e1.rAdjOne;
	          }

	          //process e2
	          Edge e2 = getEdge(n1, neib2);
	          if (e2.nodeOne.nodeID == n1) {
	            V2 = e2.finalAdjTwo;
	            V_2 = e2.finalAdjOne;
	            rV2 = e2.rAdjTwo;
	          }
	          else if (e2.nodeTwo.nodeID == n1) {
	            V2 = e2.finalAdjOne;
	            V_2 = e2.finalAdjTwo;
	            rV2 = e2.rAdjOne;
	          }
	          //put overlap genes from e1 into e.relaxAdjOne;
	          for (int j = 0; j < V1.size(); j++) {
	            pair p1 = (pair) (V1.elementAt(j));
	            //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
	            for (int k = 0; k < V2.size(); k++) {
	                pair p2 = (pair) (V2.elementAt(k));
	                if (overlap(p1, p2) == true) {
	                    pair temp = new pair(p1.geneOne, p1.geneTwo, p1.index);
						S1.addElement(temp);
	                    e.finalAdjOne.addElement(temp);
	                    pair temp2 = new pair(p1.geneOne, p1.geneTwo, p1.index);
						S2.addElement(temp2);
						e.finalAdjOne.addElement(temp2);
					  }
				   }
			    }
	          getNoSamePairsForEdges(e.finalAdjOne);
	              /*       if (e1.nodeOne.nodeID == n1) {
	                	 for(i = 0; i < S2.size(); i++) {
	                         e1.finalAdjTwo.addElement(S2.elementAt(i));
	                       }
	                    }
	                     else {
	                    	 for(i = 0; i < S2.size(); i++) {
	                             e1.finalAdjOne.addElement(S2.elementAt(i));
	                           }
	                        }
	                     if (e2.nodeOne.nodeID == n1) {
	                    	 for(i = 0; i < S2.size(); i++) {
	                             e2.finalAdjTwo.addElement(S2.elementAt(i));
	                           }
	                     }
	                     else {
	                    	 for(i = 0; i < S2.size(); i++) {
	                             e2.finalAdjOne.addElement(S2.elementAt(i));
	                           }
	                     }
	             //       e.rAdjOne.addElement(temp2);
	             //       pair p = (pair) (rV1.elementAt(j));
	             //       p.geneOne = 10000;
	            //        break;*/
			}

	        else { //if (n1 < n2) that is, n1 is a leaf
	          //now process part two.
	          if (N2.firstNeib == n1) {
	            neib1 = N2.secondNeib;
	            neib2 = N2.lastNeib;
	          }
	          if (N2.secondNeib == n1) {
	            neib1 = N2.firstNeib;
	            neib2 = N2.lastNeib;
	          }
	          if (N2.lastNeib == n1) {
	            neib1 = N2.firstNeib;
	            neib2 = N2.secondNeib;
	          }
	          Edge e1 = getEdge(n2, neib1);

	          if (e1.nodeOne.nodeID == n2) {
	            V1 = e1.finalAdjTwo;
	            V_1 = e1.finalAdjOne;
	            rV1 = e1.rAdjTwo;
	          }
	          else if (e1.nodeTwo.nodeID == n2) {
	            V1 = e1.finalAdjOne;
	            V_1 = e1.finalAdjTwo;
	            rV1 = e1.rAdjOne;
	          }
	          //process e2
	          Edge e2 = getEdge(n2, neib2);
	          if (e2.nodeOne.nodeID == n2) {
	            V2 = e2.finalAdjTwo;
	            V_2 = e2.finalAdjOne;
	            rV2 = e2.rAdjTwo;
	          }
	          else if (e2.nodeTwo.nodeID == n2) {
	            V2 = e2.finalAdjOne;
	            V_2 = e2.finalAdjTwo;
	            rV2 = e2.rAdjOne;
	          }
	          //put overlap genes from e1,e2 into finalAdjTwo;
	          for (int j = 0; j < V1.size(); j++) {
	            pair p1 = (pair) (V1.elementAt(j));
	            for (int k = 0; k < V2.size(); k++) {
	                pair p2 = (pair) (V2.elementAt(k));
	                if (overlap(p1, p2) == true) {
	                    pair temp = new pair(p1.geneOne, p1.geneTwo, p1.index);
						S2.addElement(temp);					 
	                    e.finalAdjTwo.addElement(temp);
	                    pair temp2 = new pair(p2.geneOne, p2.geneTwo, p2.index);
						S2.addElement(temp2);
	                    e.finalAdjTwo.addElement(temp2);
	                 }
	              }
	           }
		        getNoSamePairsForEdges(e.finalAdjTwo);
	        }
	      }
	    }
	  }

//***************************************
   //refine the internal edges.
   void refineRelax(PrintWriter pw) {
     //pw.println("Refine internal edges:");
     for (int i = 0; i < edgeList.size(); i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
       if (e.isInternalEdge == true) {

         //pw.println("internal");
         Node N1 = e.nodeOne;
         Node N2 = e.nodeTwo;
         int n1 = N1.nodeID;
         int n2 = N2.nodeID;
         //System.out.println("processing " + n1 + "-->" + n2);
         int neib1 = -1;
         int neib2 = -1;
         if (N1.firstNeib == n2) {
           neib1 = N1.secondNeib;
           neib2 = N1.lastNeib;
         }
         if (N1.secondNeib == n2) {
           neib1 = N1.firstNeib;
           neib2 = N1.lastNeib;
         }
         if (N1.lastNeib == n2) {
           neib1 = N1.firstNeib;
           neib2 = N1.secondNeib;
         }
         //System.out.println(neib1+","+neib2);
         Edge e1 = getEdge(n1, neib1);

         //if v1 is setone then v_1 is settwo; if v1 is settwo, then v_1 is setone;
         Vector V1 = new Vector();
         Vector V_1 = new Vector();
         Vector V2 = new Vector();
         Vector V_2 = new Vector();
         Vector rV1 = new Vector();
         Vector rV2 = new Vector();

         //process e1;
         if (e1.nodeOne.nodeID == n1) {
           V1 = e1.relaxAdjTwo;
           V_1 = e1.relaxAdjOne;
           rV1 = e1.rAdjTwo;
         }
         else if (e1.nodeTwo.nodeID == n1) {
           V1 = e1.relaxAdjOne;
           V_1 = e1.relaxAdjTwo;
           rV1 = e1.rAdjOne;
         }

         //process e2
         Edge e2 = getEdge(n1, neib2);
         if (e2.nodeOne.nodeID == n1) {
           V2 = e2.relaxAdjTwo;
           V_2 = e2.relaxAdjOne;
           rV2 = e2.rAdjTwo;
         }
         else if (e2.nodeTwo.nodeID == n1) {
           V2 = e2.relaxAdjOne;
           V_2 = e2.relaxAdjTwo;
           rV2 = e2.rAdjOne;
         }
         //put good pairs from e1 into finalAdjOne;
         for (int j = 0; j < V1.size(); j++) {
           pair p1 = (pair) (V1.elementAt(j));
           //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
           boolean B1 = false;
           for (int j2 = 0; j2 < V_1.size(); j2++) {
             pair q = (pair) (V_1.elementAt(j2));
             if (overlap(q, p1) == true) {
               B1 = true;
             }
           }
           if (B1 == false) {
             for (int k = 0; k < V2.size(); k++) {
               boolean B2 = false;
               pair p2 = (pair) (V2.elementAt(k));
               if (overlap(p1, p2) == true) {
                 for (int k2 = 0; k2 < V_2.size(); k2++) {
                   pair q = (pair) (V_2.elementAt(k2));
                   if (overlap(q, p2) == true) {
                     B2 = true;
                   }
                 }

                 if (B2 == true) {
                   pair temp = new pair(p1.geneOne,
                                        p1.geneTwo, p1.index);
                   e.finalAdjOne.addElement(temp);

                   pair temp2 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                   e.rAdjOne.addElement(temp2);

                   pair temp4 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);

                   if (e2.nodeOne.nodeID == n1) {
                     e2.finalAdjOne.addElement(temp4);
                   }
                   else {
                     e2.finalAdjTwo.addElement(temp4);
                   }

                   //remove p1 from rV1
                   pair p = (pair) (rV1.elementAt(j));
                   p.geneOne = 10000;

                   break;
                 }
               }
             }
           }
         }

         //put good pairs from e2 into finalAdjOne;
         for (int j = 0; j < V2.size(); j++) {
           pair p1 = (pair) (V2.elementAt(j));
           //if B1 is false, then p1 does not overlap with any pair at the other side of the same edge.
           boolean B1 = false;
           for (int j2 = 0; j2 < V_2.size(); j2++) {
             pair q = (pair) (V_2.elementAt(j2));
             if (overlap(q, p1) == true) {
               B1 = true;
             }
           }
           if (B1 == false) {
             for (int k = 0; k < V1.size(); k++) {
               boolean B2 = false;
               pair p2 = (pair) (V1.elementAt(k));
               if (overlap(p1, p2) == true) {
                 ///*
                  //original refinement
                  for (int k2 = 0; k2 < V_1.size(); k2++) {
                    pair q = (pair) (V_1.elementAt(k2));
                    if (overlap(q, p2) == true) {
                      B2 = true;
                    }
                  }

                 if (B2 == true) {
                   pair temp = new pair(p1.geneOne,
                                        p1.geneTwo, p1.index);
                   e.finalAdjOne.addElement(temp);

                   pair temp2 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                   e.rAdjOne.addElement(temp2);

                   pair temp4 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);

                   if (e1.nodeOne.nodeID == n1) {
                     e1.finalAdjOne.addElement(temp4);
                   }
                   else {
                     e1.finalAdjTwo.addElement(temp4);
                   }

                   //remove p1 from rV2
                   pair p = (pair) (rV2.elementAt(j));
                   p.geneOne = 10000;

                   break;
                 }
               }
             }
           }
         }

         //now process part two.
         if (N2.firstNeib == n1) {
           neib1 = N2.secondNeib;
           neib2 = N2.lastNeib;
         }
         if (N2.secondNeib == n1) {
           neib1 = N2.firstNeib;
           neib2 = N2.lastNeib;
         }
         if (N2.lastNeib == n1) {
           neib1 = N2.firstNeib;
           neib2 = N2.secondNeib;
         }
         e1 = getEdge(n2, neib1);

         if (e1.nodeOne.nodeID == n2) {
           V1 = e1.relaxAdjTwo;
           V_1 = e1.relaxAdjOne;
           rV1 = e1.rAdjTwo;
         }
         else if (e1.nodeTwo.nodeID == n2) {
           V1 = e1.relaxAdjOne;
           V_1 = e1.relaxAdjTwo;
           rV1 = e1.rAdjOne;
         }
         //process e2
         e2 = getEdge(n2, neib2);
         if (e2.nodeOne.nodeID == n2) {
           V2 = e2.relaxAdjTwo;
           V_2 = e2.relaxAdjOne;
           rV2 = e2.rAdjTwo;
         }
         else if (e2.nodeTwo.nodeID == n2) {
           V2 = e2.relaxAdjOne;
           V_2 = e2.relaxAdjTwo;
           rV2 = e2.rAdjOne;
         }

         //put overlap genes from e1 into finalAdjTwo;
         for (int j = 0; j < V1.size(); j++) {
           pair p1 = (pair) (V1.elementAt(j));
           boolean B1 = false;
           for (int j2 = 0; j2 < V_1.size(); j2++) {
             pair q = (pair) (V_1.elementAt(j2));
             if (overlap(q, p1) == true) {
               B1 = true;
             }
           }
           if (B1 == false) {
             for (int k = 0; k < V2.size(); k++) {
               boolean B2 = false;
               pair p2 = (pair) (V2.elementAt(k));
               if (overlap(p1, p2) == true) {
                 ///*
                  //original refinement
                  for (int k2 = 0; k2 < V_2.size(); k2++) {
                    pair q = (pair) (V_2.elementAt(k2));
                    if (overlap(q, p2) == true) {
                      B2 = true;
                    }
                  }

                 if (B2 == true) {
                   pair temp = new pair(p1.geneOne,
                                        p1.geneTwo, p1.index);
                   e.finalAdjTwo.addElement(temp);

                   pair temp2 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                   e.rAdjTwo.addElement(temp2);

                   pair temp4 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);

                   if (e2.nodeOne.nodeID == n2) {
                     e2.finalAdjOne.addElement(temp4);
                   }
                   else {
                     e2.finalAdjTwo.addElement(temp4);
                   }
                   //remove p1 from rV1
                   pair p = (pair) (rV1.elementAt(j));
                   p.geneOne = 10000;

                   break;
                 }
               }
             }
           }
         }
         //put overlap genes from e2 into finalAdjTwo;
         for (int j = 0; j < V2.size(); j++) {
           pair p1 = (pair) (V2.elementAt(j));
           boolean B1 = false;
           for (int j2 = 0; j2 < V_2.size(); j2++) {
             pair q = (pair) (V_2.elementAt(j2));
             if (overlap(q, p1) == true) {
               B1 = true;
             }
           }
           if (B1 == false) {
             for (int k = 0; k < V1.size(); k++) {
               boolean B2 = false;
               pair p2 = (pair) (V1.elementAt(k));
               if (overlap(p1, p2) == true) {

                 ///*
                  //original refinement
                  for (int k2 = 0; k2 < V_1.size(); k2++) {
                    pair q = (pair) (V_1.elementAt(k2));
                    if (overlap(q, p2) == true) {
                      B2 = true;
                    }
                  }

                 if (B2 == true) {
                   pair temp = new pair(p1.geneOne,
                                        p1.geneTwo, p1.index);
                   e.finalAdjTwo.addElement(temp);

                   pair temp2 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);
                   e.rAdjTwo.addElement(temp2);

                   pair temp4 = new pair(p1.geneOne,
                                         p1.geneTwo, p1.index);

                   if (e1.nodeOne.nodeID == n2) {
                     e1.finalAdjOne.addElement(temp4);
                   }
                   else {
                     e1.finalAdjTwo.addElement(temp4);
                   }

                   //remove p1 from rV2
                   pair p = (pair) (rV2.elementAt(j));
                   p.geneOne = 10000;

                   break;
                 }
               }
             }
           }
         }
       }
     }
   }

  /**************************************/
//in this method, we process each leaf edge. for e=(n1,n2)
//if n1 is a leaf, then put relaxAdjOne as adjOne;
  void processLeafEdges() {
    for (int i = 0; i < edgeList.size(); i++) {
      Edge e = (Edge) (edgeList.elementAt(i));
      if (e.isInternalEdge == false) {
        if (e.setOne.size() == 1) {
          for (int j = 0; j < e.adjOne.size(); j++) {
            pair p = (pair) (e.adjOne.elementAt(j));
            pair pp = new pair(p.geneOne, p.geneTwo, p.index);
            e.relaxAdjOne.addElement(pp);
            pair temp = new pair(p.geneOne, p.geneTwo, p.index);
            e.finalAdjOne.addElement(temp);

            pair temp2 = new pair(p.geneOne, p.geneTwo, p.index);
            e.rAdjOne.addElement(temp2);
          }
        }
        if (e.setTwo.size() == 1) {
          for (int j = 0; j < e.adjTwo.size(); j++) {
            pair p = (pair) (e.adjTwo.elementAt(j));
            pair pp = new pair(p.geneOne, p.geneTwo, p.index);
            e.relaxAdjTwo.addElement(pp);
            pair temp = new pair(p.geneOne, p.geneTwo, p.index);
            e.finalAdjTwo.addElement(temp);
            pair temp2 = new pair(p.geneOne, p.geneTwo, p.index);
            e.rAdjTwo.addElement(temp2);
          }
        }
      }
    }
  }

//******************************
   boolean overlap(pair p1, pair p2) {
     int s1 = Math.abs(p1.geneOne);
     int s2 = Math.abs(p1.geneTwo);

     int t1 = Math.abs(p2.geneOne);
     int t2 = Math.abs(p2.geneTwo);
     boolean B = false;
     if ( (s1 == t1) || (s1 == t2) || (s2 == t1) || (s2 == t2)) {
       B = true;
     }
     return B;
   }

//****************************
//Note that in this method, we only refine INTERNAL edges.
   void refineRelax() {
     for (int i = 0; i < edgeList.size(); i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
       if (e.isInternalEdge == true) {
         Node N1 = e.nodeOne;
         Node N2 = e.nodeTwo;
         int n1 = N1.nodeID;
         int n2 = N2.nodeID;
         int neib1 = -1;
         int neib2 = -1;
         if (N1.firstNeib == n2) {
           neib1 = N1.secondNeib;
           neib2 = N1.lastNeib;
         }
         if (N1.secondNeib == n2) {
           neib1 = N1.firstNeib;
           neib2 = N1.lastNeib;
         }
         if (N1.lastNeib == n2) {
           neib1 = N1.firstNeib;
           neib2 = N1.secondNeib;
         }
         Edge e1 = getEdge(n1, neib1);

         //if v1 is setone then v_1 is settwo; if v1 is settwo, then v_1 is setone;
         Vector V1 = new Vector();
         Vector V_1 = new Vector();
         Vector V2 = new Vector();
         Vector V_2 = new Vector();

         //process e1;
         if (e1.nodeOne.nodeID == n1) {
           V1 = e1.relaxAdjTwo;
           V_1 = e1.relaxAdjOne;
         }
         else if (e1.nodeTwo.nodeID == n1) {
           V1 = e1.relaxAdjOne;
           V_1 = e1.relaxAdjTwo;
         }

         //process e2
         Edge e2 = getEdge(n1, neib2);
         if (e2.nodeOne.nodeID == n1) {
           V2 = e2.relaxAdjTwo;
           V_2 = e2.relaxAdjOne;
         }
         else if (e2.nodeTwo.nodeID == n1) {
           V2 = e2.relaxAdjOne;
           V_2 = e2.relaxAdjTwo;
         }
         //put overlap genes into finalAdjOne;
         //if (e.setOne.size() > 2)
         //{
         for (int j = 0; j < V1.size(); j++) {
           pair p1 = (pair) (V1.elementAt(j));
           boolean B1 = false;
           for (int j2 = 0; j2 < V_1.size(); j2++) {
             pair q = (pair) (V_1.elementAt(j2));
             if (overlap(q, p1) == true) {
               B1 = true;
             }
           }
           if (B1 == false) {
             for (int k = 0; k < V2.size(); k++) {
               boolean B2 = false;
               pair p2 = (pair) (V2.elementAt(k));
               for (int k2 = 0; k2 < V_2.size(); k2++) {
                 pair q = (pair) (V_2.elementAt(k2));
                 if (overlap(q, p2) == true) {
                   B2 = true;
                 }
               }
               if (B2 == true) {
                 pair temp = new pair(p1.geneOne, p1.geneTwo,
                                      p1.index);
                 e.finalAdjOne.addElement(temp);
                 //pair p = new pair();
                 //p.geneOne = p1.geneOne;
                 //p.geneTwo = p1.geneTwo;
                 //e.realFinalAdjOne.addElement(p);
               }
             }
           }
         }
         //}

         //now process part two.
         if (N2.firstNeib == n1) {
           neib1 = N2.secondNeib;
           neib2 = N2.lastNeib;
         }
         if (N2.secondNeib == n1) {
           neib1 = N2.firstNeib;
           neib2 = N2.lastNeib;
         }
         if (N2.lastNeib == n1) {
           neib1 = N2.firstNeib;
           neib2 = N2.secondNeib;
         }
         e1 = getEdge(n2, neib1);

         if (e1.nodeOne.nodeID == n2) {
           V1 = e1.relaxAdjTwo;
           V_1 = e1.relaxAdjOne;
         }
         else if (e1.nodeTwo.nodeID == n2) {
           V1 = e1.relaxAdjOne;
           V_1 = e1.relaxAdjTwo;
         }
         //process e2
         e2 = getEdge(n2, neib2);
         if (e2.nodeOne.nodeID == n2) {
           V2 = e2.relaxAdjTwo;
           V_2 = e2.relaxAdjOne;
         }
         else if (e2.nodeTwo.nodeID == n2) {
           V2 = e2.relaxAdjOne;
           V_2 = e2.relaxAdjTwo;
         }
         //put overlap genes into finalAdjTwo;
         //if (e.setTwo.size() > 2)
         //{
         for (int j = 0; j < V1.size(); j++) {
           pair p1 = (pair) (V1.elementAt(j));
           boolean B1 = false;
           for (int j2 = 0; j2 < V_1.size(); j2++) {
             pair q = (pair) (V_1.elementAt(j2));
             if (overlap(q, p1) == true) {
               B1 = true;
             }
           }
           if (B1 == false) {
             for (int k = 0; k < V2.size(); k++) {
               boolean B2 = false;
               pair p2 = (pair) (V2.elementAt(k));
               for (int k2 = 0; k2 < V_2.size(); k2++) {
                 pair q = (pair) (V_2.elementAt(k2));
                 if (overlap(q, p2) == true) {
                   B2 = true;
                 }
               }
               if (B2 == true) {
                 pair temp = new pair(p1.geneOne, p1.geneTwo,
                                      p1.index);

                 e.finalAdjTwo.addElement(temp);
                 //pair p = new pair();
                 //p.geneOne = p1.geneOne;
                 //p.geneTwo = p1.geneTwo;
                 //e.realFinalAdjTwo.addElement(p);
               }
             }
           }
         }
       }
     }
   }
   
   //**************************
 //this method aims to remove the same pairs in finalAdjs
   void getNoSamePairsForEdges(Vector V) {
       for (int i = 0; i < V.size() - 1; i++) {
           pair p = (pair) (V.elementAt(i));
           for (int j = i + 1; j < V.size(); j++) {
               pair temp = (pair) (V.elementAt(j));
               if ( (isSamePair2(temp, p) == true) && (p.geneOne != 9999)) {
                   temp.geneOne = 9999;
                   temp.geneTwo = 9999;
               }
          } 
      }
      int s = 0;
      while (s != V.size()) {
          pair p = (pair) (V.elementAt(s));
          if (p.geneOne == 9999) {
              V.removeElementAt(s);
          } else {
             s++;
           }
       }
   } 
   
   //**************************
/*   void getNoSamePairsForEdges(Vector vector) {
       Vector tempVector = new Vector();
       for (int i=0;i<vector.size();i++){
           Object obj = vector.get(i);
    	   if(!tempVector.contains(obj)) {
    		   tempVector.add(obj);
           }
       }
	 //  HashSet set = new HashSet(vector);
	 //  tempVector.addAll(set);
       vector.removeAllElements();
	   for (int i = 0; i < tempVector.size(); i++) {
	       vector.addElement(tempVector.elementAt(i));
	   }
    }*/
  

   //**************************
     void getSomePairsForEdges(Edge e, Vector genomeList) {
       int s = e.setOne.size();
	   int t = e.setTwo.size();
       Vector tempV = new Vector();
	   Vector tempV1 = new Vector();
	   Vector S1 = new Vector();
	   Vector S2 = new Vector();

	  //put all the pairs of e.setOne into the vector
       for (int i = 0; i < s; i++) {
    	   int m = ((Integer)(e.setOne.elementAt(i))).intValue();
           Genome tempGenome = (Genome)(genomeList.elementAt(m));
           tempGenome.getPairs(tempV);
       }
       //put the first pair into S1 to avoid it empty
       pair p0 = new pair();
       p0.geneOne = ((pair) (tempV.elementAt(0))).geneOne;
       p0.geneTwo = ((pair) (tempV.elementAt(0))).geneTwo;
       p0.index = 0;
       S1.addElement(p0);
	   
       int tempSize = tempV.size();
       for (int i = 1; i < tempSize; i++) {
           for (int j = 1; j < tempSize; j++) {
               if (isSamePair1((pair) (tempV.elementAt(i)),
                              (pair) (tempV.elementAt(j))) == true) {
                   pair tempPair = new pair();
                   tempPair.geneOne = ((pair) (tempV.elementAt(i))).geneOne;
                   tempPair.geneTwo = ((pair) (tempV.elementAt(i))).geneTwo;
                   tempPair.index = S1.size();
                   S1.addElement(tempPair);
    		       e.finalAdjOne.addElement(tempPair);
               }
		   }
       }
       getNoSamePairsForEdges(e.finalAdjOne);

	  //put all the pairs of e.setTwo into the vector
       for (int i = 0; i < t; i++) {
    	   int n = ((Integer)(e.setTwo.elementAt(i))).intValue();
           Genome tempGenome = (Genome)(genomeList.elementAt(n));
           tempGenome.getPairs(tempV1);
       }
       //put the first pair into S2 to avoid it empty
       pair q0 = new pair();
       q0.geneOne = ((pair) (tempV1.elementAt(0))).geneOne;
       q0.geneTwo = ((pair) (tempV1.elementAt(0))).geneTwo;
       q0.index = 0;
       S2.addElement(q0);

	   int tempSize1 = tempV1.size();
       for (int i = 1; i < tempSize1; i++) {
           for (int j = 1; j < tempSize1; j++) {
               if (isSamePair1((pair) (tempV1.elementAt(i)),
                              (pair) (tempV1.elementAt(j))) == true) {
                   pair tempPair2 = new pair();
                   tempPair2.geneOne = ((pair) (tempV1.elementAt(i))).geneOne;
                   tempPair2.geneTwo = ((pair) (tempV1.elementAt(i))).geneTwo;
                   tempPair2.index = S2.size();
                   S2.addElement(tempPair2);
    		       e.finalAdjTwo.addElement(tempPair2);
               }
		   }
       }
       getNoSamePairsForEdges(e.finalAdjTwo);
   }

   /*********************************************************************************/
   boolean isSamePair2(pair p1, pair p2) {
       boolean same;
       if ((p1.geneOne == p2.geneOne) && (p1.geneTwo == p2.geneTwo)) {
           same = true;
       } else {
           same = false;
       }
       return same;
   }

   /*********************************************************************************/
   boolean isSamePair1(pair p1, pair p2) {
       boolean same;
       if ((p1.geneOne == -(p2.geneTwo)) && (p1.geneTwo == -(p2.geneOne))) {
           same = true;
       } else {
           same = false;
       }
       return same;
   }
  
   //**************************
   void getAllPairsForEdges(Edge e, Vector genomeList) {
	   int s = e.setOne.size();
	   int t = e.setTwo.size();
       Vector tempV = new Vector();
	   Vector tempV1 = new Vector();
	   Vector V1 = new Vector();
	   Vector V2 = new Vector();
	   if (e.isInternalEdge == false) {
		          
	  //put all the pairs of e.setOne into the vector
       for (int i = 0; i < s; i++) {
           int m = ((Integer)(e.setOne.elementAt(i))).intValue();
           Genome tempGenome = (Genome)(genomeList.elementAt(m));
           tempGenome.getPairs(tempV);
       }
       //put the first pair into S1 to avoid it empty
       pair p0 = new pair();
       p0.geneOne = ((pair) (tempV.elementAt(0))).geneOne;
       p0.geneTwo = ((pair) (tempV.elementAt(0))).geneTwo;
       p0.index = 0;
       V1.addElement(p0);
	   
       int tempSize = tempV.size();
       for (int i = 1; i < tempSize; i++) {
		   int pointer = 0;
           for (int j = 0; j < V1.size(); j++) {
               if (isSamePair2((pair) (tempV.elementAt(i)),
                              (pair) (V1.elementAt(j))) == true) {
				   pointer++;
                   break;
               }
		   }
	       if (pointer == 0) {
               pair tempPair = new pair();
               tempPair.geneOne = ((pair) (tempV.elementAt(i))).geneOne;
               tempPair.geneTwo = ((pair) (tempV.elementAt(i))).geneTwo;
               tempPair.index = V1.size();
               V1.addElement(tempPair); 
           }
       }
   //  e.finalAdjOne.removeAllElements();  
   //     for (int i1 = 0; i1 < V1.size();i1++){
  //     e.finalAdjOne.addElement(V1.elementAt(i1)); 
  //  }
     
	  //put all the pairs of e.setTwo into the vector
       for (int i = 0; i < t; i++) {
           int n = ((Integer)(e.setTwo.elementAt(i))).intValue();
           Genome tempGenome = (Genome)(genomeList.elementAt(n));
           tempGenome.getPairs(tempV1);
       }
       //put the first pair into S2 to avoid it empty
       pair q0 = new pair();
       q0.geneOne = ((pair) (tempV1.elementAt(0))).geneOne;
       q0.geneTwo = ((pair) (tempV1.elementAt(0))).geneTwo;
       q0.index = 0;
       V2.addElement(q0);

	   int tempSize1 = tempV1.size();
       for (int i = 1; i < tempSize1; i++) {
		   int pointer = 0;
           for (int j = 0; j < V2.size(); j++) {
               if (isSamePair2((pair) (tempV1.elementAt(i)),
                              (pair) (V2.elementAt(j))) == true) {
				   pointer++;
                   break;
               }
		   }
	      if (pointer == 0) {
               pair tempPair2 = new pair();
               tempPair2.geneOne = ((pair) (tempV1.elementAt(i))).geneOne;
               tempPair2.geneTwo = ((pair) (tempV1.elementAt(i))).geneTwo;
               tempPair2.index = V2.size();
               V2.addElement(tempPair2);
       		   }
		   }
      e.finalAdjTwo.removeAllElements();
      for (int i2 = 0; i2 < V2.size();i2++){
	      e.finalAdjTwo.addElement(V2.elementAt(i2)); 
      }
   }
 }
   
//**************************
//This is the original one. i.e. conserved by one group and does not appear in another.
   void getAdjForEdges(int[][] m, Edge e, Vector pairList) {
     //int row = m.length;
     int col = m[0].length;

     for (int i = 0; i < col; i++) {
       int p1 = 0;
       int p2 = 0;
       for (int j = 0; j < e.setOne.size(); j++) {
         int n1 = ( (Integer) (e.setOne.elementAt(j))).intValue();
         if (m[n1][i] == 0) {
           p1++;
         }
       }

       for (int k = 0; k < e.setTwo.size(); k++) {
         int n2 = ( (Integer) (e.setTwo.elementAt(k))).intValue();
         if (m[n2][i] == 1) {
           p2++;
         }
       }
       if ( (p1 == 0) && (p2 == 0)) {
         pair currentPair = new pair();
         currentPair = (pair) (pairList.elementAt(i));
         e.adjOne.addElement(currentPair);
       }
     }

     //process adjTwo;
     for (int i = 0; i < col; i++) {
       int pointer1 = 0;
       int pointer2 = 0;
       for (int j = 0; j < e.setOne.size(); j++) {
         int n1 = ( (Integer) (e.setOne.elementAt(j))).intValue();
         if (m[n1][i] == 1) {
           pointer1++;
         }
       }

       for (int k = 0; k < e.setTwo.size(); k++) {
         int n2 = ( (Integer) (e.setTwo.elementAt(k))).intValue();
         if (m[n2][i] == 0) {
           pointer2++;
         }
       }
       if ( (pointer1 == 0) && (pointer2 == 0)) {
         pair currentPair2 = new pair();
         currentPair2 = (pair) (pairList.elementAt(i));
         e.adjTwo.addElement(currentPair2);
       }
     }
     //e.aNumOne = e.adjOne.size();
     //e.aNumTwo = e.adjTwo.size();
   }

//***************************
   /*
    *In this method, we get the relaxAdj for edge e. If e=(v1, v2)is a leaf edge with leaf v2, *
    *then we only get relaxAdjOne for e. relaxAdjTwo is equal to adjTwo.
    */
   void getAdjForEdgesRelax(int[][] m, Edge e, Vector pairList) {
     int col = m[0].length;
     int g1 = e.nodeOne.nodeID;
     int g2 = e.nodeTwo.nodeID;
     Node N1 = e.nodeOne;
     Node N2 = e.nodeTwo;
     int neib1 = -1;
     int neib2 = -1;

     //process the nodeOne side
     Vector V1;
     Vector V2;
     if (N1.firstNeib == g2) {
       neib1 = N1.secondNeib;
       neib2 = N1.lastNeib;
     }
     if (N1.secondNeib == g2) {
       neib1 = N1.firstNeib;
       neib2 = N1.lastNeib;
     }
     if (N1.lastNeib == g2) {
       neib1 = N1.firstNeib;
       neib2 = N1.secondNeib;
     }

     Edge e1 = new Edge();
     if (neib1 != -1) {
       e1 = getEdge(g1, neib1);
     }
     Edge e2 = new Edge();
     if (neib2 != -1) {
       e2 = getEdge(g1, neib2);
     }
     if (e1.nodeOne.nodeID == neib1) {
       V1 = e1.setOne;
     }
     else {
       V1 = e1.setTwo;
     }

     if (e2.nodeOne.nodeID == neib2) {
       V2 = e2.setOne;
     }
     else {
       V2 = e2.setTwo;
     }
     int[] indicator1 = new int[col];
     int[] indicator2 = new int[col];

     if (e.setOne.size() > 1) {
       for (int i = 0; i < col; i++) {
         for (int j = 0; j < V1.size(); j++) {
           int n_1 = ( (Integer) (V1.elementAt(j))).intValue();
           for (int j2 = 0; j2 < V2.size(); j2++) {
             int n_2 = ( (Integer) (V2.elementAt(j2))).intValue();
             if ( (m[n_1][i] == 1) && (m[n_2][i] == 1) &&
                 (indicator1[i] == 0)) {
               int p1 = 0;
               for (int k = 0; k < e.setTwo.size(); k++) {
                 int n2 = ( (Integer) (e.setTwo.elementAt(k))).
                     intValue();
                 if (m[n2][i] == 0) {
                   p1++;
                 }
               }
               if (p1 == e.setTwo.size()) {
                 pair currentPair = new pair();
                 currentPair = (pair) (pairList.elementAt(i));
                 pair pp = new pair(currentPair.geneOne,
                                    currentPair.geneTwo, i);
                 e.relaxAdjOne.addElement(pp);

                 pair temp = new pair(currentPair.geneOne,
                                      currentPair.geneTwo, i);
                 e.finalAdjOne.addElement(temp);
                 pair temp4 = new pair(currentPair.geneOne,
                                       currentPair.geneTwo, i);
                 e.rAdjOne.addElement(temp4);

                 indicator1[i] = 1;
               }
             }
           }
         }
       }
     }

     //now process side two of edge e
     if (N2.firstNeib == g1) {
       neib1 = N2.secondNeib;
       neib2 = N2.lastNeib;
     }
     if (N2.secondNeib == g1) {
       neib1 = N2.firstNeib;
       neib2 = N2.lastNeib;
     }
     if (N2.lastNeib == g1) {
       neib1 = N2.firstNeib;
       neib2 = N2.secondNeib;
     }

     if (neib1 != -1) {
       e1 = getEdge(g2, neib1);
     }
     if (neib2 != -1) {
       e2 = getEdge(g2, neib2);
     }

     if (e1.nodeOne.nodeID == neib1) {
       V1 = e1.setOne;
     }
     else {
       V1 = e1.setTwo;
     }

     if (e2.nodeOne.nodeID == neib2) {
       V2 = e2.setOne;
     }
     else {
       V2 = e2.setTwo;
     }

     if (e.setTwo.size() > 1) {
       for (int i = 0; i < col; i++) {
         for (int j = 0; j < V1.size(); j++) {
           int n_1 = ( (Integer) (V1.elementAt(j))).intValue();
           for (int j2 = 0; j2 < V2.size(); j2++) {
             int n_2 = ( (Integer) (V2.elementAt(j2))).intValue();
             if ( (m[n_1][i] == 1) && (m[n_2][i] == 1) &&
                 (indicator2[i] == 0)) {
               int p1 = 0;
               for (int k = 0; k < e.setOne.size(); k++) {
                 int n2 = ( (Integer) (e.setOne.elementAt(k))).
                     intValue();
                 if (m[n2][i] == 0) {
                   p1++;
                 }
               }
               if (p1 == e.setOne.size()) {
                 pair currentPair = new pair();
                 currentPair = (pair) (pairList.elementAt(i));
                 pair pp = new pair(currentPair.geneOne,
                                    currentPair.geneTwo, i);
                 e.relaxAdjTwo.addElement(pp);

                 pair temp = new pair(currentPair.geneOne,
                                      currentPair.geneTwo, i);
                 e.finalAdjTwo.addElement(temp);

                 pair temp2 = new pair(currentPair.geneOne,
                                       currentPair.geneTwo, i);
                 e.rAdjTwo.addElement(temp2);

                 //to imply that this pair i has been added into adjOne;
                 indicator2[i] = 1;
               }
             }
           }
         }
       }
     }
   }

//***************************
   int overlapGeneNum(Vector V1, Vector V2, int[] S1, int[] S2) {
     Vector I1 = new Vector();
     Vector I2 = new Vector();
     Vector G = new Vector();
     for (int i = 0; i < V1.size(); i++) {
       if (S1[i] != -1) {
         pair p = (pair) (V1.elementAt(i));
         int p1 = Math.abs(p.geneOne);
         int p2 = Math.abs(p.geneTwo);
         addToList(p1, I1);
         addToList(p2, I1);
       }
     }

     for (int i = 0; i < V2.size(); i++) {
       if (S2[i] != -1) {
         pair p = (pair) (V2.elementAt(i));
         int p1 = Math.abs(p.geneOne);
         int p2 = Math.abs(p.geneTwo);
         addToList(p1, I2);
         addToList(p2, I2);
       }
     }

     int k = overLap(I1, I2, G);
     return k;

   }

//************************
   boolean twoSetsIntersect(Vector v1, Vector v2) {
     int s1 = v1.size();
     int s2 = v2.size();
     boolean intersect;
     int k = 0;
     for (int i = 0; i < s1; i++) {
       int n1 = ( (Integer) (v1.elementAt(i))).intValue();
       for (int j = 0; j < s2; j++) {
         int n2 = ( (Integer) (v2.elementAt(j))).intValue();
         if (n1 == n2) {
           k++;
         }
       }
     }

     if (k == 0) {
       intersect = false;
     }
     else {
       intersect = true;
     }

     return intersect;

   }

//*************************
   String drawNewickTree(Vector genomes, int n, int m, int evNo,
                         int ex_order) throws
       Exception { //n is the index of current tree. m is the rank.

     //String name = "T";
     String exOrder = ex_order + "";
     String evNumber = evNo + "";

     for (int i = 0; i < this.nodeList.size(); i++) {
       Node N = (Node) (this.nodeList.elementAt(i));
       N.traversed = false;
       N.fstDone = false;
       N.secDone = false;
       N.lastDone = false;
     }

     int k = 0;
     while ( ( (Edge) (this.edgeList.elementAt(k))).isInternalEdge == false) {
       k++;

     }
     Edge e = (Edge) (this.edgeList.elementAt(k));
     Node N1 = e.nodeOne;
     Node N2 = e.nodeTwo;
     if (N1.firstNeib == N2.nodeID) {
       N1.fstDone = true;
     }
     if (N1.secondNeib == N2.nodeID) {
       N1.secDone = true;
     }
     if (N1.lastNeib == N2.nodeID) {
       N1.lastDone = true;
     }
     if (N2.lastNeib == N1.nodeID) {
       N2.lastDone = true;
     }
     if (N2.firstNeib == N1.nodeID) {
       N2.fstDone = true;
     }
     if (N2.secondNeib == N1.nodeID) {
       N2.secDone = true;
     }
     if (N2.lastNeib == N1.nodeID) {
       N2.lastDone = true;
     }

     String S1 = drawNode(N1, e, genomes);
     String S2 = drawNode(N2, e, genomes);
     String S = "(";
     S = S + S1 + "," + S2 + ")";
     return S;
   }

//******************************

   String drawTree(Vector genomes) {
     for (int i = 0; i < this.nodeList.size(); i++) {
       Node N = (Node) (this.nodeList.elementAt(i));
       N.traversed = false;
       N.fstDone = false;
       N.secDone = false;
       N.lastDone = false;
     }

     int k = 0;
     while ( ( (Edge) (this.edgeList.elementAt(k))).isInternalEdge == false) {
       k++;

     }
     Edge e = (Edge) (this.edgeList.elementAt(k));
     Node N1 = e.nodeOne;
     Node N2 = e.nodeTwo;
     if (N1.firstNeib == N2.nodeID) {
       N1.fstDone = true;
     }
     if (N1.secondNeib == N2.nodeID) {
       N1.secDone = true;
     }
     if (N1.lastNeib == N2.nodeID) {
       N1.lastDone = true;
     }
     if (N2.lastNeib == N1.nodeID) {
       N2.lastDone = true;
     }
     if (N2.firstNeib == N1.nodeID) {
       N2.fstDone = true;
     }
     if (N2.secondNeib == N1.nodeID) {
       N2.secDone = true;
     }
     if (N2.lastNeib == N1.nodeID) {
       N2.lastDone = true;
     }

     String S1 = drawNode(N1, e, genomes);
     String S2 = drawNode(N2, e, genomes);
     String S = "(";
     S = S + S1 + "," + S2 + ")";
     return S;
   }

//*******************************
   String drawNode(Node N, Edge e, Vector genomes) {
     String S = "(";
     if (N.isLeaf == true) {
       ;
     }
     else {
       //************************if N.fstDone == true********//
       Node lChild;
       Node rChild;
       if (N.fstDone == true) {
         if ( (N.secDone == true) || (N.lastDone == true)) {
           S = "wrong!";
           System.out.println("wrong1.N = " + N.nodeID);
           return S;
         }
         lChild = (Node) (nodeList.elementAt(N.secondNeib)); // left child
         rChild = (Node) (nodeList.elementAt(N.lastNeib)); //right child
       }
       else if (N.secDone == true) {
         if ( (N.fstDone == true) || (N.lastDone == true)) {
           S = "wrong!";
           System.out.println("wrong2.N = " + N.nodeID);
           return S;
         }
         lChild = (Node) (nodeList.elementAt(N.firstNeib)); // left child
         rChild = (Node) (nodeList.elementAt(N.lastNeib)); //right child
       }
       else { //if (N.lastDone == true)
         if ( (N.fstDone == true) || (N.secDone == true)) {
           S = "wrong!";
           System.out.println("wrong3.N = " + N.nodeID);
           return S;
         }
         lChild = (Node) (nodeList.elementAt(N.firstNeib)); // left child
         rChild = (Node) (nodeList.elementAt(N.secondNeib)); //right child
       }

       //draw left child
       if (lChild.isLeaf == true) {
         //S = S  + ((Genome)(genomes.elementAt(lChild.nodeID))).name + ",";
         S = S + lChild.nodeID + ",";
         lChild.fstDone = true;
         lChild.traversed = true;
         if (N.firstNeib == lChild.nodeID) {
           N.fstDone = true;
         }
         if (N.secondNeib == lChild.nodeID) {
           N.secDone = true;
         }
         if (N.lastNeib == lChild.nodeID) {
           N.lastDone = true;
         }
       }
       else if (lChild.isLeaf == false) {
         if (lChild.firstNeib == N.nodeID) {
           lChild.fstDone = true;
         }
         if (lChild.secondNeib == N.nodeID) {
           lChild.secDone = true;
         }
         if (lChild.lastNeib == N.nodeID) {
           lChild.lastDone = true;
         }
         //System.out.println("leftBranch="+N.nodeID+", "+lChild.nodeID);
         Edge leftBranch = getEdge(N.nodeID, lChild.nodeID);
         S = S + drawNode(lChild, leftBranch, genomes) + ",";
         if (N.firstNeib == lChild.nodeID) {
           N.fstDone = true;
         }
         if (N.secondNeib == lChild.nodeID) {
           N.secDone = true;
         }
         if (N.lastNeib == lChild.nodeID) {
           N.lastDone = true;
         }
       }
       //draw right child
       if (rChild.isLeaf == true) {
         rChild.fstDone = true;
         rChild.traversed = true;
         int sum = e.adjOne.size() + e.adjTwo.size();
         if (sum > 0) {
           if (sum < 20) {
             //S = S  + ((Genome)(genomes.elementAt(rChild.nodeID))).name+")";
             S = S + rChild.nodeID + ")";
           }
           else {
             S = S + rChild.nodeID + ")";
           }

         }
         if (sum == 0) {
           //S = S  + ((Genome)(genomes.elementAt(rChild.nodeID))).name + ")";
           S = S + rChild.nodeID + ")";
         }
         if (N.firstNeib == rChild.nodeID) {
           N.fstDone = true;
         }
         if (N.secondNeib == rChild.nodeID) {
           N.secDone = true;
         }
         if (N.lastNeib == rChild.nodeID) {
           N.lastDone = true;
         }
         N.traversed = true;
       }
       else if (rChild.isLeaf == false) {
         if (rChild.firstNeib == N.nodeID) {
           rChild.fstDone = true;
         }
         if (rChild.secondNeib == N.nodeID) {
           rChild.secDone = true;
         }
         if (rChild.lastNeib == N.nodeID) {
           rChild.lastDone = true;
         }
         int sum = e.adjOne.size() + e.adjTwo.size();
         Edge rBranch = getEdge(N.nodeID, rChild.nodeID);
         if (sum > 0) {
           if (sum < 20) {
             S = S + drawNode(rChild, rBranch, genomes) + ")";
           }
           else {
             S = S + drawNode(rChild, rBranch, genomes) + ")";
           }

         }
         if (sum == 0) {
           S = S + drawNode(rChild, rBranch, genomes) + ")";
         }
         if (N.firstNeib == rChild.nodeID) {
           N.fstDone = true;
         }
         if (N.secondNeib == rChild.nodeID) {
           N.secDone = true;
         }
         if (N.lastNeib == rChild.nodeID) {
           N.lastDone = true;
         }
         N.traversed = true;
       }
     } //end else in line 455
     return S;

   }

//*******************************
   Edge getEdge(int v1, int v2) {
     int edgeNum = -1;
     for (int i = 0; i < this.edgeList.size(); i++) {
       Edge e = (Edge) (edgeList.elementAt(i));
       int n1 = e.nodeOne.nodeID;
       int n2 = e.nodeTwo.nodeID;
       if ( (v1 == n1) && (v2 == n2)) {
         edgeNum = i;
       }
       else if ( (v1 == n2) && (v2 == n1)) {
         edgeNum = i;
       }
     }
     //System.out.println("edgeNum = "+edgeNum);
     return (Edge) (edgeList.elementAt(edgeNum));
   }

//****************************

   void traverseNode(Node v, Vector list) {
     //System.out.println("Now traversing node "+v.nodeID);
     if (v.isLeaf == true) {
       //System.out.println("No need to traverse a leaf node!");
     }
     else {
       if (v.fstDone == false) {
         list.addElement(new Integer(v.firstNeib));
         //System.out.println(v.firstNeib + "is added.");
         v.fstDone = true;

         int neibID1 = v.firstNeib;
         // for v's neib, change one of its state done or not
         if ( ( (Node) (nodeList.elementAt(neibID1))).isLeaf == true) {
           ( (Node) (nodeList.elementAt(neibID1))).traversed = true;
           //System.out.println(neibID"+is a new added leaf.");
         }
         else {
           if ( ( (Node) (nodeList.elementAt(neibID1))).firstNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID1))).fstDone = true;
           }

           if ( ( (Node) (nodeList.elementAt(neibID1))).secondNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID1))).secDone = true;
           }
           if ( ( (Node) (nodeList.elementAt(neibID1))).lastNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID1))).lastDone = true;
           }
         }

       }
       if (v.secDone == false) {
         list.addElement(new Integer(v.secondNeib));
         //System.out.println(v.secondNeib + "is added.");
         v.secDone = true;
         int neibID2 = v.secondNeib;
         // for v's neib, change one of its state done or not
         if ( ( (Node) (nodeList.elementAt(neibID2))).isLeaf == true) {
           ( (Node) (nodeList.elementAt(neibID2))).traversed = true;
         }
         else {
           if ( ( (Node) (nodeList.elementAt(neibID2))).firstNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID2))).fstDone = true;
           }

           if ( ( (Node) (nodeList.elementAt(neibID2))).secondNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID2))).secDone = true;
           }
           if ( ( (Node) (nodeList.elementAt(neibID2))).lastNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID2))).lastDone = true;
           }
         } //end else
       }
       if (v.lastDone == false) {
         list.addElement(new Integer(v.lastNeib));
         //System.out.println(v.lastNeib + "is added.");
         v.lastDone = true;
         int neibID3 = v.lastNeib;
         // for v's neib, change one of its state done or not
         if ( ( (Node) (nodeList.elementAt(neibID3))).isLeaf == true) {
           ( (Node) (nodeList.elementAt(neibID3))).traversed = true;
         }
         else {
           if ( ( (Node) (nodeList.elementAt(neibID3))).firstNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID3))).fstDone = true;
           }
           if ( ( (Node) (nodeList.elementAt(neibID3))).secondNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID3))).secDone = true;
           }
           if ( ( (Node) (nodeList.elementAt(neibID3))).lastNeib ==
               v.nodeID) {
             ( (Node) (nodeList.elementAt(neibID3))).lastDone = true;
           }
         } //end else
       }

       //change the state of v's neib.
       v.traversed = true;
       //System.out.println(v.nodeID+"has been traversed!");
     }
   }

//*******************************
   boolean needAdd(Vector V) {
     int s = V.size();
     int counter = 0;
     boolean need;
     for (int i = 0; i < s; i++) {
       int index = ( (Integer) (V.elementAt(i))).intValue();
       if ( ( (Node) (nodeList.elementAt(index))).traversed == true) {
         counter = counter + 1;
       }
     }
     //System.out.println("s = "+s);
     //System.out.println("counter = "+counter);
     if (counter != s) {
       need = true;
     }
     else {
       need = false;
     }
     return need;
   }

//******************************
   void getSetsForAllEdges() {
     int s = edgeList.size();
     for (int i = 0; i < s; i++) {
       Edge e = (Edge) (this.edgeList.elementAt(i));
       if (e.isInternalEdge == false) {
         if (e.nodeOne.nodeID < e.nodeTwo.nodeID) {
           Vector V = new Vector();
           V.addElement(new Integer(e.nodeOne.nodeID));
           e.setOne = V;
           int leafNum = (edgeList.size() + 3) / 2;
           for (int k = 0; k < leafNum; k++) {
             if (k != e.nodeOne.nodeID) {
               e.setTwo.addElement(new Integer(k));
             }
           }
         }
         else {
           Vector V = new Vector();
           V.addElement(new Integer(e.nodeTwo.nodeID));
           e.setTwo = V;
           int leafNum = (edgeList.size() + 3) / 2;
           for (int k = 0; k < leafNum; k++) {
             if (k != e.nodeTwo.nodeID) {
               e.setOne.addElement(new Integer(k));
             }
           }
         }
       }
       if (e.isInternalEdge == true) {
         getSetOneAndTwo(e);
       }

     }

     for (int i = 0; i < s; i++) {
       Edge e = (Edge) (this.edgeList.elementAt(i));
       if (e.setOne.size() > 1) {
         int n = e.nodeOne.nodeID;
         int n1 = -1;
         int n2 = -1;
         if (e.nodeOne.firstNeib == e.nodeTwo.nodeID) {
           n1 = e.nodeOne.secondNeib;
           n2 = e.nodeOne.lastNeib;
         }
         else if (e.nodeOne.secondNeib == e.nodeTwo.nodeID) {
           n1 = e.nodeOne.firstNeib;
           n2 = e.nodeOne.lastNeib;
         }
         else if (e.nodeOne.lastNeib == e.nodeTwo.nodeID) {
           n1 = e.nodeOne.firstNeib;
           n2 = e.nodeOne.lastNeib;
         }
         Edge e1 = getEdge(n, n1);
         Edge e2 = getEdge(n, n2);

         if (e1.nodeOne.nodeID == n) {
           e.leftSub1 = e1.setTwo;
         }
         else if (e1.nodeTwo.nodeID == n) {
           e.leftSub1 = e1.setOne;
         }

         if (e2.nodeOne.nodeID == n) {
           e.rightSub1 = e2.setTwo;
         }
         else if (e2.nodeTwo.nodeID == n) {
           e.rightSub1 = e2.setOne;
         }
       }

       if (e.setTwo.size() > 1) {
         int n = e.nodeTwo.nodeID;
         int n1 = -1;
         int n2 = -1;
         if (e.nodeTwo.firstNeib == e.nodeOne.nodeID) {
           n1 = e.nodeTwo.secondNeib;
           n2 = e.nodeTwo.lastNeib;
         }
         else if (e.nodeTwo.secondNeib == e.nodeOne.nodeID) {
           n1 = e.nodeTwo.firstNeib;
           n2 = e.nodeTwo.lastNeib;
         }
         else if (e.nodeTwo.lastNeib == e.nodeOne.nodeID) {
           n1 = e.nodeTwo.firstNeib;
           n2 = e.nodeTwo.lastNeib;
         }
         Edge e1 = getEdge(n, n1);
         Edge e2 = getEdge(n, n2);

         if (e1.nodeOne.nodeID == n) {
           e.leftSub2 = e1.setTwo;
         }
         else if (e1.nodeTwo.nodeID == n) {
           e.leftSub2 = e1.setOne;
         }

         if (e2.nodeOne.nodeID == n) {
           e.rightSub2 = e2.setTwo;
         }
         else if (e2.nodeTwo.nodeID == n) {
           e.rightSub2 = e2.setOne;
         }
       }

     }
     for (int i = 0; i < s; i++) {
       Edge e = (Edge) (this.edgeList.elementAt(i));

       System.out.println("e.leftSub1");
       for (int k = 0; k < e.leftSub1.size(); k++) {
         int a = ( (Integer) (e.leftSub1.elementAt(k))).intValue();
         System.out.print(a + ", ");
       }
       System.out.println();

       System.out.println("e.leftSub2");
       for (int k = 0; k < e.leftSub2.size(); k++) {
         int a = ( (Integer) (e.leftSub2.elementAt(k))).intValue();
         System.out.print(a + ", ");
       }
       System.out.println();

       System.out.println("e.rightSub1");
       for (int k = 0; k < e.rightSub1.size(); k++) {
         int a = ( (Integer) (e.rightSub1.elementAt(k))).intValue();
         System.out.print(a + ", ");
       }
       System.out.println();

       System.out.println("e.rightSub2");
       for (int k = 0; k < e.rightSub2.size(); k++) {
         int a = ( (Integer) (e.rightSub2.elementAt(k))).intValue();
         System.out.print(a + ", ");
       }
       System.out.println();
     }

   }

//**********************

   void getSetOneAndTwo(Edge e) {
     int v1 = e.nodeOne.nodeID;
     int v2 = e.nodeTwo.nodeID;

     if (e.isInternalEdge == false) {
       ;
     }
     else {
       if (e.nodeOne.firstNeib == v2) {
         e.nodeOne.fstDone = true;
       }

       if (e.nodeOne.secondNeib == v2) {
         e.nodeOne.secDone = true;
       }

       if (e.nodeOne.lastNeib == v2) {
         e.nodeOne.lastDone = true;
       }

       Vector temp = e.setOne;
       temp.addElement(new Integer(e.nodeOne.nodeID));

       while (needAdd(temp) == true) {
         int ss = temp.size();
         for (int i = 0; i < ss; i++) {
           int index = ( (Integer) (temp).elementAt(i)).intValue();
           traverseNode( (Node) (nodeList.elementAt(index)), temp);
         }
       }

       for (int kkk = 0; kkk < temp.size(); kkk++) {
         int I = ( (Integer) (temp).elementAt(kkk)).intValue();
       }
       int point = 0;
       while (point < temp.size()) {
         int tempPoint = ( (Integer) (temp.elementAt(point))).intValue();
         if ( ( (Node) (nodeList.elementAt(tempPoint))).isLeaf == false) {
           temp.removeElementAt(point);
         }
         else {
           point++;
         }
       }

       getSetTwo(nodeList, e.setOne, e.setTwo);

       for (int i = 0; i < nodeList.size(); i++) {
         ( (Node) (nodeList.elementAt(i))).fstDone = false;
         ( (Node) (nodeList.elementAt(i))).secDone = false;
         ( (Node) (nodeList.elementAt(i))).lastDone = false;
         ( (Node) (nodeList.elementAt(i))).traversed = false;
       }

     } //end else

   }

//******************************

//add a node into the nodeList. Node A has been set to be internal or not.
   void addNode(Node A) {
     A.setNodeInternalOrNot();
     nodeList.addElement(A);
   }

//*******************************
   void transmitValue(Vector from, Vector To) {
     int i = from.size();
     for (int k = 0; k < i; k++) {
       To.addElement(from.elementAt(k));
     }
   }

//*****************************
   void getSetTwo(Vector ndList, Vector set_1, Vector set_2) {
     //Vector SetTwo = new Vector();
     int size1 = ndList.size();
     int size2 = set_1.size();
     int pointer = 0;

     for (int k1 = 0; k1 < size1; k1++) {
       pointer = 0;
       for (int k2 = 0; k2 < size2; k2++) {
         if ( ( (Node) (ndList.elementAt(k1))).nodeID ==
             ( (Integer) (set_1.elementAt(k2))).intValue()) {
           pointer++;

         }
       }
       if ( (pointer == 0) && ( ( (Node) (ndList.elementAt(k1))).isLeaf == true)) {
         set_2.addElement(new Integer( ( (Node) (ndList.elementAt(k1))).
                                      nodeID));
       }

     }
   }

//************************
   boolean isSamePair(pair p1, pair p2) {
     int s1 = p1.geneOne;
     int s2 = p1.geneTwo;
     int k1 = p2.geneOne;
     int k2 = p2.geneTwo;
     boolean B = false;
     if ( ( (s1 == k1) && (s2 == k2)) || ( (s1 == -k2) && (s2 == -k1))) {
       B = true;
     }
     return B;
   }

//************************
   boolean isSameSet(int[] A1, int[] A2) {
     boolean same = true;
     int len = A1.length;
     boolean[] s = new boolean[len];
     for (int i = 0; i < len; i++) {
       s[i] = false;
       int a1 = A1[i];
       int p = 0;
       for (int j = 0; j < len; j++) {
         int a2 = A2[j];
         if (a1 == a2) {
           p++;
         }
       }
       if (p == 1) {
         s[i] = true;
       }
     }

     for (int i = 0; i < len; i++) {
       if (s[i] == false) {
         same = false;
       }
     }
     return same;
   }

//**********************
   void addLeaf(int i, int j) { //add node i to the j-th edge of the current tree
     ( (Edge) (edgeList.elementAt(j))).setEdgeInternalOrNot();
     if ( ( (Edge) (edgeList.elementAt(j))).isInternalEdge == false) {
       //The nodeID of the two ends of the edge edList.elementAt(j).
       int v_1 = ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
           nodeID;
       int v_2 = ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
           nodeID;

       //generate a new interanl node
       Node newNode = new Node();

       //step 1.set neibs for the new internal node
       int newNodeID = nodeList.size();
       newNode.getNodeID(newNodeID);
       newNode.setFirstNeib(i);
       newNode.setSecondNeib(v_1);
       newNode.setLastNeib(v_2);

       //step 2. add newNode to nodeList
       nodeList.addElement(newNode);

       //step 3. set neib for the new added leaf
       ( (Node) (nodeList.elementAt(i))).setFirstNeib(newNode.nodeID);

       //step 4. set new neibs for the leaf v_1
       ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).setFirstNeib(
           newNode.nodeID);

       //set new neibs for the v_2
       if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).firstNeib ==
           v_1) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
             setFirstNeib(
                 newNode.nodeID);
       }
       else if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
                secondNeib == v_1) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
             setSecondNeib(
                 newNode.nodeID);
       }
       else if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
                lastNeib ==
                v_1) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
             setLastNeib(
                 newNode.nodeID);
       }
       else {
         ;
       }

       //step 5. add the new leaf edge including the node ndList.elementAt(i)
       Edge e_leaf = new Edge();
       e_leaf.setNodeOne( (Node) (nodeList.elementAt(i)));
       e_leaf.setNodeTwo(newNode);
       e_leaf.setEdgeInternalOrNot();
       edgeList.addElement(e_leaf);

       //step 6. generate an internal edge,
       Edge e = new Edge(); //the new  edge
       e.setNodeOne(newNode);
       e.setNodeTwo( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo));
       e.setEdgeInternalOrNot();
       edgeList.addElement(e);

       //step 7. change e = (v_1, v_2) into e = (v_1, newNode)
       ( (Edge) (edgeList.elementAt(j))).setNodeTwo(newNode);
       //System.out.println();
     } //end if

     //add a new leaf onto an internal edge
     else {
       // System.out.println("else!!");
       //The nodeID of the two ends of the edge edList.elementAt(j).
       int v_1 = ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
           nodeID;
       int v_2 = ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
           nodeID;

       //generate a new interanl node
       Node newNode = new Node();

       //step 1.set neibs for the new internal node
       int newNodeID = nodeList.size();
       newNode.getNodeID(newNodeID);
       newNode.setFirstNeib(i);
       newNode.setSecondNeib(v_1);
       newNode.setLastNeib(v_2);

       //step 2. add newNode to nodeList
       nodeList.addElement(newNode);

       //step 3. set neib for the new added leaf
       ( (Node) (nodeList.elementAt(i))).setFirstNeib(newNode.nodeID);

       //step 4. set new neibs for the internal node v_1
       if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).firstNeib ==
           v_2) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
             setFirstNeib(
                 newNode.nodeID);
       }
       else if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
                secondNeib == v_2) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
             setSecondNeib(
                 newNode.nodeID);
       }
       else if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
                lastNeib ==
                v_2) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeOne)).
             setLastNeib(
                 newNode.nodeID);
       }

       //set new neibs for the v_2
       if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).firstNeib ==
           v_1) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
             setFirstNeib(
                 newNode.nodeID);
       }
       else if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
                secondNeib == v_1) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
             setSecondNeib(
                 newNode.nodeID);
       }
       else if ( ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
                lastNeib ==
                v_1) {
         ( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo)).
             setLastNeib(
                 newNode.nodeID);
       }
       //step 5. add the new leaf edge includ the node ndList.elementAt(i)
       Edge e_leaf = new Edge();
       e_leaf.setNodeOne( (Node) (nodeList.elementAt(i)));
       e_leaf.setNodeTwo(newNode);
       e_leaf.setEdgeInternalOrNot();
       edgeList.addElement(e_leaf);

       //step 6. generate an edge, and partite the node set
       Edge e = new Edge(); //the new  edge
       e.setNodeOne(newNode);
       e.setNodeTwo( (Node) ( ( (Edge) (edgeList.elementAt(j))).nodeTwo));
       transmitValue( ( (Edge) (edgeList.elementAt(j))).setTwo, e.setTwo);
       transmitValue( ( (Edge) (edgeList.elementAt(j))).setOne, e.setOne);
       e.setOne.addElement(new Integer(newNode.nodeID));
       e.setEdgeInternalOrNot();
       edgeList.addElement(e);

       //step 7. change e = (v_1, v_2) into e = (v_1, newNode)
       ( (Edge) (edgeList.elementAt(j))).setNodeTwo(newNode);
     }
   }
}
