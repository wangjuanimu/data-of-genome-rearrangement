//package emrae;
public class tlc {

    //the 2 possible inversions mimicking a translocation.
    inversion inv;
    pair p1;
    pair p2;
    pair q1;
    pair q2;

    public tlc(int type, int g1, int g2, int g3, int g4) {
        if (type == 1) {

            p1 = new pair(g1, g2);
            p2 = new pair(g3, g4);
            q1 = new pair(g1, g4);
            q2 = new pair(g3, g2);

            inv = new inversion();
            inv.p1 = new pair(g1, g2);
            inv.p2 = new pair( -g4, -g3);
            inv.q1 = new pair(g1, g4);
            inv.q2 = new pair( -g2, -g3);
        } else if (type == 2) {
            p1 = new pair(g1, g2);
            p2 = new pair(g3, g4);
            q1 = new pair(g1, -g3);
            q2 = new pair( -g2, g4);

            inv = new inversion();
            inv.p1 = new pair(g1, g2);
            inv.p2 = new pair(g3, g4);
            inv.q1 = new pair(g1, -g3);
            inv.q2 = new pair( -g2, g4);
        }
    }

    public tlc(pair m1, pair m2, pair n1, pair n2) {
        this.p1 = new pair(m1.geneOne, m1.geneTwo);
        this.p2 = new pair(m2.geneOne, m2.geneTwo);
        this.q1 = new pair(n1.geneOne, n1.geneTwo);
        this.q2 = new pair(n2.geneOne, n2.geneTwo);
        this.inv = new inversion();
        this.inv.p1 = new pair(m1.geneOne, m1.geneTwo);
        this.inv.p2 = new pair(m2.geneOne, m2.geneTwo);
        this.inv.q1 = new pair(n1.geneOne, n1.geneTwo);
        this.inv.q2 = new pair(n2.geneOne, n2.geneTwo);
    }

}
