//package emrae;

import java.io.*;
import java.util.*;

class Input {
    Vector genomeList; //the list of all genomes.
    //String fileName;
    Vector leafListToAdd;
    Vector Pairs;
    Input() {
        genomeList = new Vector();
        leafListToAdd = new Vector();
        Pairs = new Vector();
    }


//*************************
     void processCurrentTree(unrootedTree T, int[][] matrix,
                             PrintWriter p, int[][] index, Vector genomes) throws
             Exception {
         T.getAdjForAllEdges(matrix, this.Pairs, p);
         for(int i = 0; i < T.edgeList.size(); i++)  {
             Edge e = (Edge)(T.edgeList.elementAt(i));
        //     T.getSomePairsForEdges(e, genomeList);
        //     T.getAllPairsForEdges(e, genomeList);
             
        //  System.out.println(e.finalAdjOne.size()+","+e.finalAdjTwo.size());
         }
         T.getTotalScore(this.Pairs, matrix, p, index, genomes);
     }

//*************************
     int[][] generateMatrix(Vector genomes, Vector pairs, int[][] index) {
         /*initializing*/
         for (int i = 0; i < index.length; i++) {
             for (int j = 0; j < index[i].length; j++) {
                 index[i][j] = -1;
             }
         }

         int row = genomes.size();
         int col = pairs.size();
         int[][] matrix = new int[row][col];
         for (int i = 0; i < row; i++) {
             Genome g = (Genome) (genomes.elementAt(i)); // the i-th genome
             int chromNum = g.Chroms.size(); //num of chroms in this genome
             for (int j = 0; j < chromNum; j++) { //j-th chrom
                 int length = ((int[]) (g.Chroms.elementAt(j))).length;
                 int[] tempChrom = (int[]) (g.Chroms.elementAt(j));
                 for (int k = 0; k < length - 1; k++) {
                     int gene1 = tempChrom[k];
                     int gene2 = tempChrom[k + 1];
                     for (int m = 0; m < col; m++) { //pairs
                         if ((gene1 == ((pair) (pairs.elementAt(m))).geneOne) &&
                             (gene2 == ((pair) (pairs.elementAt(m))).geneTwo)) {
                             matrix[i][m] = 1;
                             index[i][m] = j;
                         } else if ((gene1 ==
                                     -(((pair) (pairs.elementAt(m))).geneTwo)) &&
                                    (gene2 ==
                                     -(((pair) (pairs.elementAt(m))).geneOne))) {
                             matrix[i][m] = 1;
                             index[i][m] = j;
                         }
                     }
                 }
                 pair p_head = new pair(0, tempChrom[0]);
                 int gene1 = 0;
                 int gene2 = tempChrom[0];
             	 for (int m = 0; m < col; m++) { //pairs
                     if ((gene1 == ((pair) (pairs.elementAt(m))).geneOne) &&
                       (gene2 == ((pair) (pairs.elementAt(m))).geneTwo)) {
                         matrix[i][m] = 1;
                         index[i][m] = j;
             		}
             	}
             	pair p_tail = new pair(tempChrom[length-1], 0);
             	int gene3 = tempChrom[length-1];
                 int gene4 = 0;
                 for (int m = 0; m < col; m++) { //pairs
                     if ((gene3 == ((pair) (pairs.elementAt(m))).geneOne) &&
                       (gene4 == ((pair) (pairs.elementAt(m))).geneTwo)) {
                         matrix[i][m] = 1;
                         index[i][m] = j;
             		 }
             	 }
             }
         }
         return matrix;
     }

    //***************************
     void getAllValidPairs() {
         int s = genomeList.size();
         //put all the pairs into the vector
         Vector tempV = new Vector();
         for (int i = 0; i < s; i++) {
             Genome tempGenome = (Genome) (genomeList.elementAt(i));
             tempGenome.getPairs(tempV);
         }

         //put the first pair into Pairs to avoid it empty
         pair p0 = new pair();
         p0.geneOne = ((pair) (tempV.elementAt(0))).geneOne;
         p0.geneTwo = ((pair) (tempV.elementAt(0))).geneTwo;
         p0.index = 0;
         Pairs.addElement(p0);

         int tempSize = tempV.size();
         for (int i = 1; i < tempSize; i++) {
             int realSize = Pairs.size();
             int pointer = 0;
             for (int j = 0; j < realSize; j++) {
                 if (isSamePair((pair) (tempV.elementAt(i)),
                                (pair) (Pairs.elementAt(j))) == true) {
                     pointer++;
                     break;
                 }
             }
             if (pointer == 0) {
                 pair tempPair = new pair();
                 tempPair.geneOne = ((pair) (tempV.elementAt(i))).geneOne;
                 tempPair.geneTwo = ((pair) (tempV.elementAt(i))).geneTwo;
                 tempPair.index = Pairs.size();
                 Pairs.addElement(tempPair);
             }
         }
     }

    /*********************************************************************************/
    boolean isSamePair(pair p1, pair p2) {
        boolean same;
        if ((p1.geneOne == p2.geneOne) && (p1.geneTwo == p2.geneTwo)) {
            same = true;
        } else if ((p1.geneOne == -(p2.geneTwo)) && (p1.geneTwo == -(p2.geneOne))) {
            same = true;
        } else {
            same = false;
        }
        return same;
    }

    /*********************************************************************************/

    /*generate a list of leaves, each with a same ID with its corresponding genome.
      and each node's isLeaf = true;*/
    void generateLeafList() {
        int k = genomeList.size();
        for (int i = 0; i < k; i++) {
            Node N = new Node();
            //Note the constructor of class Node. It needs modification.
            N.isLeaf = true;
            N.getNodeID(i);
            leafListToAdd.add(N);
        }
    }

    /************************************************************************************/
    //read newick tree from topo1.txt, then generate the tree T, initialize the values or
    //all edges and node of T.

    void processRealTrees(String tree_file, int[][] matrix, int[][] ind,
                          PrintWriter p) throws
            Exception {
        try {
            int genomeNb = genomeList.size();
            File topo = new File(tree_file);
            FileReader fr = new FileReader(topo);
            BufferedReader in = new BufferedReader(fr);

            unrootedTree T = new unrootedTree();

            //read the info of the tree T from the file "rev1.txt"
            String line="";
            while ((line = in.readLine()) != null) {
                if (line.startsWith("Node")) {
                    Node N = new Node();
                    //get node ID;
                    int m1 = index(line, ' ') + 1;
                    int m2 = index(line, ':');
                    int n = Integer.parseInt(line.substring(m1, m2));
                    N.getNodeID(n);
                    //get neibs for N.
                    m1 = index(line, '=');
                    String[] neib = (line.substring(m2 + 1, m1 - 1)).split(",");
                    N.firstNeib = Integer.parseInt(neib[0]);
                    N.secondNeib = Integer.parseInt(neib[1]);
                    N.lastNeib = Integer.parseInt(neib[2]);
                    //get isLeaf
                    if (line.substring(m1 + 1).startsWith("t")) {
                        N.isLeaf = true;
                    } else {
                        N.isLeaf = false;
                    }
                    T.nodeList.addElement(N);
                } else if (line.startsWith("Edge")) {
                    Edge e = new Edge();
                    String[] ends = line.substring(index(line, ':') +
                            1).split(",");
                    int s1 = Integer.parseInt(ends[0]);
                    int s2 = Integer.parseInt(ends[1]);
                    Node N1 = (Node) (T.nodeList.elementAt(s1));
                    Node N2 = (Node) (T.nodeList.elementAt(s2));
                    e.setNodeOne(N1);
                    e.setNodeTwo(N2);
                    //set e.from equals to e.finalAdjOne
                    //set e.to equals to e.finalAdjTwo
                    e.from = e.nodeOne.nodeID;
                    e.to = e.nodeTwo.nodeID;
                    //get set one.
                    line = in.readLine();
                    String[] set1 = line.substring(index(line, ':') +
                            1).split(",");
                    for (int i = 0; i < set1.length; i++) {
                        int a = Integer.parseInt(set1[i]);
                        e.setOne.addElement(new Integer(a));
                    }
                    line = in.readLine();
                    String[] set2 = line.substring(index(line, ':') +
                            1).split(",");
                    for (int i = 0; i < set2.length; i++) {
                        int a = Integer.parseInt(set2[i]);
                        e.setTwo.addElement(new Integer(a));
                    }
                    if ((e.nodeOne.nodeID > (genomeNb - 1)) &&
                        (e.nodeTwo.nodeID > (genomeNb - 1))) {
                        e.isInternalEdge = true;
                    }
                    T.edgeList.addElement(e);
                }
            }
            for (int i = 0; i < T.edgeList.size(); i++) { 
                Edge e = (Edge) (T.edgeList.elementAt(i));
                if (e.setOne.size() > 1) {
                    int n = e.nodeOne.nodeID;
                    int n1 = -1;
                    int n2 = -1;
                    if (e.nodeOne.firstNeib == e.nodeTwo.nodeID) {
                        n1 = e.nodeOne.secondNeib;
                        n2 = e.nodeOne.lastNeib;
                    } else if (e.nodeOne.secondNeib == e.nodeTwo.nodeID) {
                        n1 = e.nodeOne.firstNeib;
                        n2 = e.nodeOne.lastNeib;
                    } else if (e.nodeOne.lastNeib == e.nodeTwo.nodeID) {
                        n1 = e.nodeOne.firstNeib;
                        n2 = e.nodeOne.secondNeib;
                    }
                    Edge e1 = T.getEdge(n, n1);
                    Edge e2 = T.getEdge(n, n2);

                    if (e1.nodeOne.nodeID == n) {
                        e.leftSub1 = e1.setTwo;
                    } else if (e1.nodeTwo.nodeID == n) {
                        e.leftSub1 = e1.setOne;
                    }

                    if (e2.nodeOne.nodeID == n) {
                        e.rightSub1 = e2.setTwo;
                    } else if (e2.nodeTwo.nodeID == n) {
                        e.rightSub1 = e2.setOne;
                    }
                }

                if (e.setTwo.size() > 1) {
                    int n = e.nodeTwo.nodeID;
                    int n1 = -1;
                    int n2 = -1;
                    if (e.nodeTwo.firstNeib == e.nodeOne.nodeID) {
                        n1 = e.nodeTwo.secondNeib;
                        n2 = e.nodeTwo.lastNeib;
                    } else if (e.nodeTwo.secondNeib == e.nodeOne.nodeID) {
                        n1 = e.nodeTwo.firstNeib;
                        n2 = e.nodeTwo.lastNeib;
                    } else if (e.nodeTwo.lastNeib == e.nodeOne.nodeID) {
                        n1 = e.nodeTwo.firstNeib;
                        n2 = e.nodeTwo.secondNeib;
                    }
                    Edge e1 = T.getEdge(n, n1);
                    Edge e2 = T.getEdge(n, n2);

                    if (e1.nodeOne.nodeID == n) {
                        e.leftSub2 = e1.setTwo;
                    } else if (e1.nodeTwo.nodeID == n) {
                        e.leftSub2 = e1.setOne;
                    }

                    if (e2.nodeOne.nodeID == n) {
                        e.rightSub2 = e2.setTwo;
                    } else if (e2.nodeTwo.nodeID == n) {
                        e.rightSub2 = e2.setOne;
                    }
                }
            }
            processCurrentTree(T, matrix, p, ind, this.genomeList);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            System.out.println(ex.toString());
            System.exit(0);
        }
    }

    //****************************************
     //to give the first position of c in S
     int index(String S, char c) {
         int n = 0;
         while (S.charAt(n) != c) {
             n++;
         }
         return n;
     }

    /************************************************************************************/
    void copyTree(unrootedTree from, unrootedTree to) {
        int nSize = from.nodeList.size();
        int eSize = from.edgeList.size();

        for (int i = 0; i < nSize; i++) {
            Node N = new Node();
            N.nodeID = ((Node) (from.nodeList.elementAt(i))).nodeID;
            N.firstNeib = ((Node) (from.nodeList.elementAt(i))).firstNeib;
            N.secondNeib = ((Node) (from.nodeList.elementAt(i))).secondNeib;
            N.lastNeib = ((Node) (from.nodeList.elementAt(i))).lastNeib;
            N.isLeaf = ((Node) (from.nodeList.elementAt(i))).isLeaf;
            to.nodeList.addElement(N);
        }

        for (int i = 0; i < eSize; i++) {
            Edge e = new Edge();
            int v1 = ((Edge) (from.edgeList.elementAt(i))).nodeOne.nodeID;
            int v2 = ((Edge) (from.edgeList.elementAt(i))).nodeTwo.nodeID;
            Node N1 = ((Node) (to.nodeList.elementAt(v1)));
            Node N2 = ((Node) (to.nodeList.elementAt(v2)));
            e.setNodeOne(N1);
            e.setNodeTwo(N2);
            e.setEdgeInternalOrNot();
            to.edgeList.addElement(e);
        }

    }

    /************************************************************************************/
    //read from the output of GRAPPA (fileName1), then extract the NJ trees into files fileName2.
    void getNJtrees(String fileName1, String fileName2) throws Exception {
        File file1 = new File(fileName1);
        File file2 = new File(fileName2);

        try {
            FileReader fr = new FileReader(file1);
            BufferedReader in = new BufferedReader(fr);
            FileWriter fw = new FileWriter(file2);
            PrintWriter pw = new PrintWriter(fw);
            String line;
            boolean b = false;
            while (b == false) {
                line = in.readLine();
                //
                if (line.startsWith("Neighbor-Joining")) {
                    b = true;
                    int start = 0;
                    while (line.charAt(start) != '(') {
                        start++;
                    }
                    line = line.substring(start);
                    //System.out.println("new line: "+ line);
                    int s = 0;
                    while (s != line.length()) {
                        if ((line.charAt(s) == '(') || (line.charAt(s) == ')') ||
                            (line.charAt(s) == ',')) {
                            pw.print(line.charAt(s));
                            //System.out.print(line.charAt(s));
                            s++;
                        } else {
                            int k = 1;
                            while ((line.charAt(s + k) != ')') &&
                                   (line.charAt(s + k) != ',')) {
                                k++;
                            }

                            String t = line.substring(s, s + k);
                            int e = Integer.parseInt(t);
                            t = (e - 1) + "";
                            pw.print(t);
                            s = s + k;
                        }
                    }
                }
            }
            fw.close();
        } catch (FileNotFoundException e) {
            System.out.println("File Disappeared!");
        }
    }

//*************************
     void printBoundry() {
         for (int i = 0; i < this.genomeList.size(); i++) {
             Genome G = (Genome) (genomeList.elementAt(i));
             System.out.println("G" + i + " has " + G.Chroms.size() +
                                " chromosoms.");
             for (int j = 0; j < G.Chroms.size(); j++) {
                 int[] a = (int[]) (G.Chroms.elementAt(j));
                 System.out.println("Chrom " + (j + 1) + ": " + "*" + a[0] +
                                    "*" + ", " + "*" + a[a.length - 1] + "*");
             }
         }
     }

    //**************************************************
     void generateGenomeList(String fileName) throws Exception {
         File file = new File(fileName);
         try {
             FileReader fr = new FileReader(file);
             BufferedReader in = new BufferedReader(fr);

             // this is the line read each time
             String line;
             //put this value to Genome.ID
             int tempID = 0;

             while ((line = in.readLine()) != null) {
                 if (line.startsWith(">")) {
                     Genome tempGenome = new Genome();
                     // input the name of a genome
                     genomeList.addElement(tempGenome);
                     ((Genome) (genomeList.lastElement())).setName(line.
                             substring(1));
                     ((Genome) (genomeList.lastElement())).ID = tempID;
                     tempID++;
                 } else {
                     if (line.startsWith("#")) {
                     } else if (line.endsWith("$") == true) {
                         //add a chromosome
                         String[] tempStringArray = line.substring(0,
                                 line.length() - 1).
                                 split(" ");
                         //int[] tempIntArray = new int[emrae.geneNUM];
                         int[] tempIntArray = new int[tempStringArray.length];
                         for (int i = 0; i < tempStringArray.length; i++) {
                             tempIntArray[i] = Integer.parseInt(tempStringArray[
                                     i]);
                         }
                         ((Genome) (genomeList.lastElement())).Chroms.add(
                                 tempIntArray);
                     }
                 }
             }

             for(int i = 0; i < genomeList.size(); i++){
                 ((Genome)(genomeList.elementAt(i))).getBoundry();

             }

             boolean multi_chrom = false;
             for (int i = 0; i < genomeList.size(); i++) {
                 Genome G = (Genome) (genomeList.elementAt(i));
                 if (G.Chroms.size() > 1) {
                     multi_chrom = true;
                     break;
                 }
             }
             if (multi_chrom) {
                 System.out.println("There " + genomeList.size() +
                                    " multi-chromosomal genomes in this data set.");
             } else {
                 System.out.println("There are " +
                                    genomeList.size() +
                                    " uni-chromosomal genomes.");
             }

         } catch (Exception e) {
             System.out.println(e.getMessage());
             System.exit(0);
         }
     }
}
