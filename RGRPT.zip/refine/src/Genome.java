//package emrae;
import java.util.*;
import java.lang.*;
public class Genome {
  int ID;
  // it denotes a set of Array objects. All the genomes are putinto such a vector. each element is a chrom.
  Vector Chroms;
  String name;
  int chromNum;
  int[]tail;
  int[]head;
  Genome() {
    name = "Internal";
    ID = -1;
    Chroms = new Vector();
    head = new int[Chroms.size()];
    tail = new int[Chroms.size()];
  }
//************************
   void getPairs(Vector V) {
     int s = Chroms.size();
     for (int i = 0; i < s; i++) {
       int[] temp = (int[]) (Chroms.elementAt(i)); //the current Chromosome
       int length = temp.length;
       pair p_head = new pair(0, temp[0]);
       V.addElement(p_head);
       for (int j = 0; j < length - 1; j++) {
         pair P = new pair();
         P.geneOne = temp[j];
         P.geneTwo = temp[j + 1];
         V.addElement(P);
       }
       pair p_tail = new pair(temp[length-1], 0);
       V.addElement(p_tail);
     }

   }

   //************
   void getTail(){
       tail = new int[2*Chroms.size()];
       for(int i = 0; i < Chroms.size(); i++){
           int[]temp = (int[])(Chroms.elementAt(i));
           tail[2*i] = temp[0];
           tail[2*i+1] = temp[temp.length-1];
       }

   }
  void getBoundry(){
       head = new int[Chroms.size()];
       tail = new int[Chroms.size()];
       for(int i= 0; i < Chroms.size(); i++){
           int[]temp = (int[])(Chroms.elementAt(i));
           head[i] = temp[0];
           tail[i] = temp[temp.length -1];
       }
  }
//*************************
   void setName(String input) {
     name = input;
   }
//*************************
   int getChromsNum() {
     return Chroms.size();
   }
//***************************
   void getTails(){
       for(int i = 0; i < Chroms.size(); i++){
               int[]a = (int[])(Chroms.elementAt(i));
               tail[2*i] = a[0];
               tail[2*i+1] = a[a.length-1];
           }
   }
}

