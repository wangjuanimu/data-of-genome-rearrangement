//package emrae;
public class Node {
  int nodeID;
  int firstNeib;
  int secondNeib;
  int lastNeib;
  boolean isLeaf;

  boolean fstDone;
  boolean secDone;
  boolean lastDone;
  boolean traversed;
  Node() {
    nodeID = -1;
    firstNeib = -1;
    secondNeib = -1;
    lastNeib = -1;
    isLeaf = false;
    //the following are some variables indicating if the node has been tranversed.
    fstDone = false;
    secDone = false;
    lastDone = false;
    traversed = false;

  }

  void getNodeID(int i) {
    this.nodeID = i;
  }

  void setFirstNeib(int k) {
    firstNeib = k;
  }

  void setSecondNeib(int k) {
    secondNeib = k;
  }

  void setNodeInternalOrNot() {
    if ( (secondNeib == -1) && (lastNeib == -1)) {
      isLeaf = true;
    }
  }

  void setLastNeib(int k) {
    lastNeib = k;
  }

  void setTraversed() {
    if ( (fstDone == true) && (secDone == true) && (lastDone == true)) {
      traversed = true;
    }
  }

  boolean isTraversed() {
    return traversed;
  }
  void setNeibs(int a, int b, int c){
      this.firstNeib = a;
      this.secondNeib = b;
      this.lastNeib = c;
  }

}
