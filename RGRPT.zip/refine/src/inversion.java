//package emrae;
public class inversion
{
   pair p1;
   pair p2;
   pair q1;
   pair q2;
   inversion()
   {
      p1 = new pair();
      p2 = new pair();
      q1 = new pair();
      q2 = new pair();
   }
}
