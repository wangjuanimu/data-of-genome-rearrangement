//package emrae;
public class transp {
  pair p1;
  pair p2;
  pair p3;
  pair q1;
  pair q2;
  pair q3;
  public transp() {
    p1 = new pair();
    p2 = new pair();
    p3 = new pair();

    q1 = new pair();
    q2 = new pair();
    q3 = new pair();
  }
  public transp(pair m1, pair m2, pair m3, pair n1, pair n2, pair n3){
      p1 = new pair(m1.geneOne, m1.geneTwo, m1.index);
      p2 = new pair(m2.geneOne, m2.geneTwo, m2.index);
      p3 = new pair(m3.geneOne, m3.geneTwo, m3.index);
      q1 = new pair(n1.geneOne, n1.geneTwo, n1.index);
      q2 = new pair(n2.geneOne, n2.geneTwo, n2.index);
      q3 = new pair(n3.geneOne, n3.geneTwo, n3.index);
  }
}
