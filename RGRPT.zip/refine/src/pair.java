//package emrae;
class pair
{
	int geneOne;
    int geneTwo;
	int index; // to indicate the order of this pair in the whole list of pairs.

        pair(){
          geneOne = -1;
          geneTwo = -1;
          index = -1;
        }
        pair(int g1, int g2){
          this.geneOne = g1;
          this.geneTwo = g2;
          index = -1;
        }
        pair(int g1, int g2, int index){
          this.geneOne = g1;
          this.geneTwo = g2;
          this.index = index;
        }

}

